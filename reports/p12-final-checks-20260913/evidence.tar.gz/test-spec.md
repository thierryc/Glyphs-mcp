# Remaining P12 qualification

Continue in the currently running Glyphs4 process after the completed scoped source/evidence checkpoint. Keep autosaving at its normal eight-second value. No new pause, restart, runtime installation or v1 changes. Fresh disposable Report12 font copies; preserve the original clean control and all previous reports.

Run the independent 10,001-unique-name limit refusal, cubic native Edit-menu Undo/Redo/discard, dedicated dependent-component bounds across three masters, and bounded callback/dispatch/native-chunk/main-queue profiling including two seconds after mutation. Use existing public tools and the same separate native oracle. Computed geometry tolerance 1e-9; unchanged data/object/hint restoration exact. Bounds and dirty flags reported separately. Stop on any new process exit or crash before issuing further writes. Close temporary fonts and stop hooks, then observe at least130 seconds after final close.

Primary paired benchmark timings and historical v1 findings are not rerun or pooled. P13 stays unstarted until the resulting P12 disposition is reviewed.
