# Report 07: bounded latency investigation

**Keep native kerning reads and bridge scheduling unchanged.** The measured native callbacks meet the 50 ms p95 / 200 ms maximum budgets. HTTP tails still occur outside those spans. One concrete inefficiency is verified: the configured `/mcp/` request redirects to `/mcp`, adding a second HTTP request per tool call. A small route correction is worth a separate patch; it does not explain the largest stalls.

The [documentation candidate](../skill-improvements-20260911/report.md) remains installed. No production performance optimization was implemented. Sidecar `2.0.0-beta.1+088345dc5c45`, bridge `2.0.0-beta.1+f66da5d06dbe`, private Beta 1 / installer 43, Glyphs **4.1 (4107)**. Full initialization-time fingerprints and restored runtime state are in [final status](final-status.json) and the candidate manifest. V1 is historical and unchanged. Report 08 remains paused.

## Method, bounds and evidence

The initial matrix used two reversed-order 30-sample blocks per 12/100-pair size and each helper-poll/native-wrapper combination: **480 timed reads**, plus first attempt and warm-up per block. Each block used a fresh disposable target and unrelated font, exactly two documents, a public-discovered ID retained for reads, and the same explicit selectors. A temporary one-shot timer stopped the 100 ms setup poll completely during off windows; the historical 10 ms scheduling probe stayed off.

The investigation then added explicit dirty controls, stage attribution and a counterbalanced redirected/direct-path comparison. Including retained unsuccessful harness attempts, the audit counts **1,170 timed reads, 1,248 total reads, 1,310 script-logged public calls and 64,200 exact timed values**. No value mismatch or public transport error occurred. Sampling occupied **322.06 seconds of bounded native windows**, with 48.25 seconds summed read latency, below both caps (1,500 timed reads / 900 seconds sampling). Setup, proof, coding, recovery and reporting are outside this sampling bound. The initial matrix is not relabelled as an agent task trial; the separate installed report retains first/warm-up/five-copy task measurements.

[Matrix facts](facts.json), [timestamped calls](calls.jsonl), [retained first stage run](facts-stages.json), [captured stage run](facts-stages-retry.json), [correlated spans](correlated-stages.json), [redirect facts](facts-redirect.json), [summary](summary.json), [audit](audit.json). The summary includes minima/ranges and sample counts; tables below show **median / p95 / maximum milliseconds**. Native assertions and full target/unrelated before/after proofs are retained in native acknowledgments and each facts file.

Client samples and native spans were buffered; proofs, hashing and JSON trace flushing occurred outside sampling. The ordinary transport's existing Uvicorn access logging continued, including in the temporary runner. This is a remaining disk-I/O source; these are not guaranteed disk-silent server windows. Temporary sidecar wrappers used existing `create_server`/service/bridge-client functions and the same endpoint. An out-of-window signal flushed the buffer without adding a public field or tool. The normal managed process was restored through existing stop/start control, with unchanged port and auto-start settings. [Lifecycle evidence](sidecar-lifecycle.json).

## Poll and wrapper matrix

Each row combines two blocks, **n=60 timed reads**. Native columns are unavailable when wrappers were off; absence is not zero.

| Size | 100 ms poll | Native wrappers | HTTP median / p95 / max | Native callback median / p95 / max |
|---|---|---|---|---|
| core | off | off | 30.05 / 49.10 / 110.18 | unmeasured |
| core | on | off | 30.86 / 42.70 / 46.85 | unmeasured |
| core | on | on | 27.93 / 48.23 / 164.73 | 8.67 / 17.26 / 23.36 |
| core | off | on | 30.99 / 47.68 / 57.28 | 6.04 / 18.24 / 28.40 |
| batch | off | off | 48.21 / 60.05 / 70.94 | unmeasured |
| batch | on | off | 50.33 / 67.50 / 68.30 | unmeasured |
| batch | on | on | 48.88 / 63.91 / 72.16 | 22.23 / 33.78 / 40.19 |
| batch | off | on | 50.06 / 66.84 / 162.73 | 21.22 / 33.19 / 38.93 |

All measured callback distributions pass. Batch HTTP p95 exceeds 50 ms with polling both on and off. The core 164.73 ms outlier and batch 162.73 ms outlier remain in their samples. Nothing here demonstrates that the 2 ms fairness yield or native kerning getter is defective.

Host load changed substantially: one-minute load across matrix boundaries ranged **6.25–34.90** on ten logical CPUs. The largest drift occurred around the core poll-on/wrapper-on block. Reversed order helps, but does not make these conditions equally loaded. Differences between aggregated medians are **inconclusive as causal poll/wrapper overhead**. Do not treat a faster instrumented window as a product improvement.

## Captured request stages

These are **60 timed samples per size**, two fresh-copy blocks each, with poll off and native/handler/sidecar wrappers on. A preceding five-block batch confirmation is retained separately; its sidecar buffer was lost and is explicitly unavailable. New buffers contain 128 read records including first/warm-ups and match public/native records by serial ordinal, document ID and selector count. No cross-process absolute timestamps were subtracted.

| Stage | 12 pairs | 100 pairs |
|---|---|---|
| Public MCP HTTP | 17.11 / 31.25 / 42.35 | 29.83 / 43.96 / 47.55 |
| Sidecar service method | 9.96 / 24.43 / 34.92 | 20.48 / 34.76 / 37.75 |
| Bridge client round trip | 9.96 / 24.43 / 34.91 | 20.48 / 34.76 / 37.75 |
| Bridge connection through response headers | 9.80 / 24.28 / 34.79 | 20.24 / 34.00 / 37.49 |
| Bridge HTTP handler | 8.13 / 22.54 / 33.33 | 19.48 / 33.21 / 36.29 |
| Native dispatch wait | 2.89 / 3.66 / 8.82 | 2.64 / 3.53 / 5.72 |
| Native callback | 4.08 / 15.40 / 29.14 | 16.06 / 28.31 / 32.89 |
| Bridge response encode/write | 0.42 / 2.03 / 7.67 | 0.35 / 0.64 / 1.46 |
| Bridge request JSON encoding | 0.02 / 0.03 / 0.03 | 0.07 / 0.09 / 0.20 |
| Bridge response JSON decoding | 0.03 / 0.03 / 0.06 | 0.10 / 0.14 / 0.48 |
| Bridge response body read | 0.05 / 0.12 / 0.40 | 0.04 / 0.10 / 0.54 |
| Public HTTP minus service duration | 7.09 / 8.31 / 11.08 | 9.21 / 10.72 / 12.22 |

These spans are nested, so **do not sum the table**. The sidecar service method is almost entirely the bridge call; request encoding and response decoding are small in these captured samples. The final row is a calculated remainder, not directly measured sidecar assembly time. It includes MCP/client transport and scheduling around the service method. Stage instrumentation narrows the location of ordinary costs; it does not establish the source of every historical outlier.

The temporary runner used the installed runtime (Python 3.14.7, FastMCP 2.12.0, HTTPX 0.28.1) and installed component source. Its wrappers are independently fingerprinted in `summary.json`; component fingerprints do not attest dynamically attached wrappers. Current helper revisions are retained, including their startup request-state change. The matrix and first attribution buffers had different instrumentation coverage, clearly indicated in their facts.

## Dirty state, exact preservation and retained harness failures

Three preliminary dirty windows preserved every font-data value and native object identity but failed the exact transient `undo.groupingLevel` assertion: **1 before, 0 after**. `canUndo` and `canRedo` were unchanged. Waiting 0.5 seconds, then a 2-second poll-off settling window, was insufficient. The complete failed attempts remain in their original facts and call logs; they are not passes or silent retries of an editing operation.

The final control used an 8-second poll-off settling interval and **required groupingLevel 0 before measuring**. It then passed exact before/after proofs, including Undo state. This changes only the harness window, not native Undo or font behavior. Its first read began **8.38 seconds after mutation acknowledgment**; the measured sequence lasted **4.38 seconds**. It does not measure immediate post-mutation responsiveness.

- Dirty HTTP, n=30 timed: **42.87 / 156.35 / 289.49 ms**.
- Native callback: **10.49 / 25.04 / 26.59 ms**.
- Dispatch wait: **2.73 / 6.70 / 7.12 ms**.

The **289.49 ms** request contained **7.12 ms dispatch + 6.35 ms native callback**, leaving approximately **276.02 ms outside those native spans**. The ordinary sidecar was running here, so the remainder cannot be assigned to one non-native substage. Host load increased from 16.82 to 27.57 across this block. The HTTP proxy fails both targets while the observed native timings pass. Neither load nor redirects alone are proven causes of the tail.

A temporary runner first failed before serving due to an incorrect launch-argument assumption; existing control restored the ordinary sidecar. The next run completed native/HTTP samples but its termination bypassed the final Python buffer write. Both failures are preserved under `stage-launch-first-attempt/` and `stage-buffer-unavailable/`. The captured rerun used an explicit out-of-window signal. No production source fix was hidden in these harness corrections.

## Redirect experiment

Only the test client's URL varied; server configuration and endpoint settings remained unchanged. Both forms used the same installed ordinary process, new disposable copies, public discovery and native verification. First/warm-up/30 samples per block, two reversed-order blocks per size/form; **n=60 timed per table row**. HTTPX event hooks were present in both arms and recorded each response status and time to headers.

| Size | Test URL | HTTP median / p95 / max | HTTP requests per tool call |
|---|---|---|---:|
| core | configured /mcp/ | 34.14 / 48.00 / 83.23 | 2 |
| core | diagnostic /mcp | 32.58 / 50.25 / 75.19 | 1 |
| batch | configured /mcp/ | 61.14 / 86.37 / 98.32 | 2 |
| batch | diagnostic /mcp | 52.49 / 66.66 / 88.00 | 1 |

Every configured-path timed read had **307 then 200**; every direct-path read had **one 200**. There were **120 measured extra redirects** across configured-path samples. Median redirect-to-headers duration was **2.32 ms core / 2.63 ms batch**, with p95 **4.12 / 7.87 ms**. The batch redirect maximum was 34.33 ms. These are directly observed redirect spans, not the entire causal speed difference.

Direct-path medians were lower in both repeated blocks: core **35.08→33.36** and **33.32→30.92 ms**; batch **63.32→54.69** and **57.96→52.06 ms**. Load remained high and varied from 21.23 to 27.57, and core p95 did not uniformly improve. Therefore the deterministic benefit is **one fewer HTTP exchange**; latency savings are suggestive and require patch qualification under matched load. Removing the redirect cannot be claimed to eliminate the 289 ms outlier.

The MCP tool schemas and JSON values are identical across URL forms, so removing this transport redirect has **zero expected model-payload token change** using Report 06's tiktoken/o200k_base method. Headers and redirect bodies are network overhead, not an additional MCP tool response shown to the agent. The installed report separately measures catalog, skill and complete task payload costs; no billed or hidden reasoning-token measurement is available.

## Decision, limits and environment restoration

**Recommended next patch:** serve the already configured `/mcp/` path directly using FastMCP's existing `path` option. Preserve seven tools, current schema, streaming/stateless lifecycle, control routes, default endpoint and all native editing/Undo behavior. Validate one HTTP request with no redirect on fresh installed `/mcp/` handshakes/tool calls, exact response equivalence, errors/cancellation, first/warm-up/five-copy task trials, native budgets, and replicated HTTP timing under comparable load. Do not change client configuration as a substitute for fixing the served route. [Concrete next-action plan](next-actions.md).

**Keep the larger-tail investigation separate.** The bridge scheduler/native callbacks do not account for the measured dirty outlier. If it reproduces under stable load, add bounded ASGI/client transport span coverage to that specific window before proposing another runtime patch. No cache, watcher, additional thread, kerning engine or custom recovery system is justified.

Agent judgment: the new skills make the stored-read workflow direct and verifiable (assessment in the installed report). The investigation itself required substantial harness corrections; it should not be described as smooth. These difficulties are separated from the exact public read results. Visual/typographic quality is not being evaluated by stored numbers.

The post-A **Glyphs EXC_BAD_ACCESS crash** remains an independent unresolved finding, with [crash evidence](../skill-improvements-20260911/host-crash.ips). It occurred after that test's cleanup, during the interval before subsequent UI access; the stack does not prove a bridge cause. Relaunch restored only two verified disposable paths, which were closed. No additional crash was observed during B, which is not proof the failure is fixed. A bounded disposable open/read/close/idle reproduction should precede a broader stability claim.

All **78 B disposable source files**, the 40 A copies, baseline fixtures and prior reports retain exact hashes. All 730 v1 runtime files and its skills remain unchanged; no new v1 implementation finding was made. The ordinary sidecar is running on 9680 with its tested fingerprint, the bridge is ready, no jobs are active, zero fonts remain open, both temporary scripts and menu entries were removed, and measurement hooks/timers are stopped. Native startup UI is restored. Disposable source copies remain only in their dedicated temporary directories for evidence. [Cleanup/audit](audit.json), [post-test CPU snapshot](host-processes-after.txt), [final runtime](final-status.json).

The last UI observations confirm Glyphs foreground/start window and no temporary menu entries. Foreground visibility was not continuously monitored during sampling; desktop-monitor visibility was not independently established. The CPU snapshot is post-test, not per-request load attribution. Companions remained loaded and no jobs ran. Those limits, dynamic host load, fixed v2-first historical ordering and agent familiarity prevent a universal speed claim. **Stop here for review; do not start Report 08.**
