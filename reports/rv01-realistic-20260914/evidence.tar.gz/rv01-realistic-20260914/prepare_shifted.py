from pathlib import Path
import sys,json
O=Path(__file__).resolve().parent;sys.path.insert(0,str(O));from native_oracle import load,target
f=load(O/'font-source/RobotoSlab.glyphs');g=f.glyphs['o'];before=target(f,'o');mids=[m.id for m in f.masters]
for mi,ni in ((1,6),(2,9)):
 p=g.layers[mids[mi]].paths[0];n=p.nodes[ni];assert n.type!='offcurve';n.makeNodeFirst()
p=Path('/private/tmp/rv01-20260914/RobotoSlab-shifted.glyphs');assert not p.exists();f.save(str(p));(O/'shifted-fixture.json').write_text(json.dumps(dict(path=str(p),before=before,after=target(f,'o')),indent=2))
print(str(p))
