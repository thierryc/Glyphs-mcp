"""Read-only transport checks; no font edits, jobs, saves or application restart."""
from pathlib import Path
from datetime import datetime,timezone
import copy,hashlib,json,math,os,statistics,sys,time
import httpx
O=Path(__file__).resolve().parent
BASE='http://127.0.0.1:9680'
HEADERS={'Accept':'application/json, text/event-stream','MCP-Protocol-Version':'2025-03-26'}
EXPECTED={'get_status','list_documents','read_entities','start_job','get_job','apply_job','discard_job'}
def decode(response):
 if response.headers.get('content-type','').startswith('text/event-stream'):
  records=[json.loads(s[6:]) for s in response.text.splitlines() if s.startswith('data: ')]
  return next(r for r in records if 'result' in r or 'error' in r)
 return response.json()
def body(value):
 result=value['result']
 return result.get('structuredContent') or json.loads(next(c['text'] for c in result['content'] if c['type']=='text'))
def stats(values):
 v=sorted(values)
 return dict(n=len(v),median=statistics.median(v),minimum=min(v),maximum=max(v),p95=v[math.ceil(len(v)*.95)-1])
def run(label):
 assert label in ('baseline','candidate')
 directory=O/label;directory.mkdir(exist_ok=False)
 rows=[];counter=0
 def request(client,method,params,phase,path='/mcp/',follow=True):
  nonlocal counter
  counter+=1;packet=dict(jsonrpc='2.0',id=counter,method=method,params=params)
  start=time.perf_counter();at=datetime.now(timezone.utc).isoformat()
  response=client.post(path,json=packet,follow_redirects=follow)
  ms=(time.perf_counter()-start)*1000
  value=None if response.is_redirect else decode(response)
  rows.append(dict(at=at,phase=phase,method=method,params=params,path=path,followRedirects=follow,ms=ms,statuses=[r.status_code for r in response.history]+[response.status_code],location=response.headers.get('location'),contentType=response.headers.get('content-type'),body=value))
  (directory/'calls.json').write_text(json.dumps(rows,indent=2)+'\n')
  return response,value
 def tool(client,name,args,phase):
  r,v=request(client,'tools/call',dict(name=name,arguments=args),phase,follow=(label=='baseline'))
  assert r.status_code==200 and all(x==200 for x in [r.status_code])
  assert rows[-1]['statuses']==([307,200] if label=='baseline' else [200]),rows[-1]
  return body(v)
 with httpx.Client(base_url=BASE,headers=HEADERS,timeout=30) as client:
  params=dict(protocolVersion='2025-03-26',capabilities={},clientInfo=dict(name='glyphs-route-qualification',version='1'))
  response,value=request(client,'initialize',params,'configured-no-follow',follow=False)
  assert response.status_code==(307 if label=='baseline' else 200),response.text
  response,value=request(client,'initialize',params,'alternate-no-follow',path='/mcp',follow=False)
  assert response.status_code==(200 if label=='baseline' else 307),response.text
  response,value=request(client,'initialize',params,'initialize',follow=(label=='baseline'))
  assert response.status_code==200;initialize=value['result']
  response,value=request(client,'tools/list',{},'catalog',follow=(label=='baseline'))
  catalog=value['result']['tools'];assert {t['name'] for t in catalog}==EXPECTED
  status=tool(client,'get_status',{},'identity');assert status['ok'] and status['data']['bridge']['reachable']
  assert status['data']['activity']['activeCount']==0 and status['data']['bridge']['activeOperations']==0
  documents=tool(client,'list_documents',{},'discovery');assert documents['ok']
  # Use only the already-open disposable control. Never substitute another font.
  path='/private/tmp/vc01-full-20260912/v2-current-5/1789186800389374000-open-unrelated.glyphs'
  matches=[d for d in documents['data'] if d.get('path')==path];assert len(matches)==1,documents
  document=matches[0];assert document['dirty'] is False
  source=Path(path);source_hash=hashlib.sha256(source.read_bytes()).hexdigest()
  args=dict(document_id=document['id'],entities=[dict(kind='selection')],fields=['glyph','layer','selectedNodeCount'])
  results=[];load_before=os.getloadavg()
  for phase in ['first-attempt','warm-up']+['timed-'+str(i) for i in range(1,6)]:
   value=tool(client,'read_entities',args,phase);assert value['ok'],value;results.append(value)
  assert all(v==results[0] for v in results)
  errors={}
  for name,args in [('read_entities',dict(document_id='doc_route_test_missing',entities=[dict(kind='selection')],fields=['glyph'])),('get_job',dict(job_id='job_route_test_missing'))]:
   errors[name]=tool(client,name,args,'expected-error');assert errors[name]['ok'] is False,errors[name]
  after=tool(client,'list_documents',{},'preservation')
  assert documents==after
  assert hashlib.sha256(source.read_bytes()).hexdigest()==source_hash
  # Prove management endpoint still refuses unauthenticated requests; no reserve/release on the installed process.
  denied=client.post('/internal/control',json=dict(action='reserve'),follow_redirects=False)
  assert denied.status_code==403
 facts=dict(label=label,endpoint=BASE+'/mcp/',at=datetime.now(timezone.utc).isoformat(),initialize=initialize,catalog=catalog,status=status,documents=documents,read=results[0],errors=errors,sourceSHA256=source_hash,sourcePreserved=True,documentsPreserved=True,loadBefore=load_before,loadAfter=os.getloadavg(),selectionReadHTTPMs=stats([r['ms'] for r in rows if r['phase'].startswith('timed-')]),timedSamples=5,callCount=len(rows),totalHTTPExchanges=sum(len(r['statuses']) for r in rows),managementUnauthenticatedStatus=denied.status_code,nativeTiming='not instrumented; HTTP timing only',scope='Existing disposable control, read-only. No fresh-copy font/edit benchmark or large-tail attribution.')
 (directory/'facts.json').write_text(json.dumps(facts,indent=2)+'\n')
 print(json.dumps({k:facts[k] for k in ('label','selectionReadHTTPMs','callCount','totalHTTPExchanges','sourcePreserved','documentsPreserved')},indent=2))
if __name__=='__main__':run(sys.argv[1])
