from pathlib import Path
import sys,json,copy
O=Path(__file__).resolve().parent;sys.path[:0]=[str(O),str(O/'artifacts')]
from native_oracle import *
import outline_tasks as e
out=[]
for task,name,action in [('T04','o',e.adjust_handle),('T05','H',e.add_stem_midpoint),('T06','H',e.remove_stem_midpoint),('T07','at',e.add_extrema),('T08','o',e.split_o_midpoint)]:
 f=load(O/'font-source/RobotoSlab.glyphs');mids=[m.id for m in f.masters]
 if task=='T06':e.add_stem_midpoint(f,mids)
 def capture():
  layers=list(f.glyphs[name].layers);rows=[];nodes={}
  for l in layers:
   rows.append(dict(id=l.layerId,width=l.width,vertical=[l.vertWidth,l.vertOrigin],keys=[l.leftMetricsKey,l.rightMetricsKey,l.widthMetricsKey],anchors=[[a.name,a.position.x,a.position.y] for a in l.anchors],guides=[[a.position.x,a.position.y,a.angle] for a in l.guides],hints=[[ident(h),ident(h.originNode),ident(h.targetNode),h.type] for h in l.hints],userData=userdata(l),components=[[ident(c),c.componentName,list(c.transform),c.alignment,bool(c.automaticAlignment)] for c in l.components],rounding=bool(value(l,'temporarilyDisableRounding'))))
   for p in l.paths:
    for n in p.nodes:nodes[ident(n)]=dict(type=str(n.type),smooth=bool(n.smooth),name=n.name,userData=userdata(n))
  return dict(layers=rows,nodes=nodes,grid=[f.grid,f.gridSubDivisions] if hasattr(f,'gridSubDivisions') else [f.grid,f.gridSubDivision])
 a=capture();action(f,mids);b=capture();remaining=set(a['nodes'])&set(b['nodes']);out.append(dict(task=task,layerCollateralExact=a['layers']==b['layers'],gridExact=a['grid']==b['grid'],survivingNodeMetadataExact=all(a['nodes'][k]==b['nodes'][k] for k in remaining),survivingNodes=len(remaining),hintCount=sum(len(l['hints']) for l in a['layers'])))
(O/'target-collateral.json').write_text(json.dumps(out,indent=2));print(out)
