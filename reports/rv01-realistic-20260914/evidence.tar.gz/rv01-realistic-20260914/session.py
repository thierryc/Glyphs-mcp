import asyncio,json,time,sys,os
from pathlib import Path
from fastmcp import Client
O=Path(__file__).resolve().parent;R=O.parents[2];sys.path.insert(0,str(R/'scripts'))
from compare_connection_routing import body,plain

def write(name,obj):
 p=O/name;p.parent.mkdir(exist_ok=True,parents=True);p.write_text(json.dumps(obj,indent=2,default=str)+'\n')
async def setup(action,**args):
 rid=str(time.time_ns())+'-'+action;p=O/'native-request.tmp';c=dict(requestId=rid,action=action,**args);p.write_text(json.dumps(c));p.replace(O/'native-request.json');start=time.perf_counter();dest=O/'native-acks'/(rid+'.json')
 while not dest.exists():
  if time.perf_counter()-start>45:raise TimeoutError(rid)
  await asyncio.sleep(.05)
 r=json.loads(dest.read_text());assert r['ok'],r
 with (O/'setup-log.jsonl').open('a') as f:f.write(json.dumps(dict(request=c,nativeMs=r['nativeSetupMs'],wallMs=(time.perf_counter()-start)*1000,ack=str(dest)))+'\n')
 return r['data']
class API:
 async def __aenter__(self):
  self.client=Client('http://127.0.0.1:9680/mcp/',timeout=45);await self.client.__aenter__();write('catalog.json',[plain(x) for x in await self.client.list_tools()]);write('handshake.json',plain(self.client.initialize_result));return self
 async def __aexit__(self,*args):await self.client.__aexit__(*args)
 async def call(self,name,args,task):
  t=time.perf_counter();result=body(await self.client.call_tool_mcp(name,args));row=dict(at=time.time(),task=task,name=name,arguments=args,result=result,httpMs=(time.perf_counter()-t)*1000)
  with (O/'calls.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
  return result
 async def resolve(self,path,task):
  r=await self.call('list_documents',{},task);assert r['ok'];matches=[d for d in r['data'] if d['path']==path];assert len(matches)==1,r;return matches[0]['id']
async def main():
 async with API() as api:
  status=await api.call('get_status',{},'identity');assert status['data']['bridge']['codeHash'].endswith('8b74a8d27ae48b6d3ef1a317439c925f488ae5c9a0e5f0733221f468b97af687')
  opened=await setup('open');doc=await api.resolve(opened['path'],'T01');write('live-target.json',dict(**opened,document_id=doc));await setup('view')
  before=await setup('proof');write('tasks/T01/native-before.json',before)
  await setup('profile',enabled=True)
  rows=[dict(kind='layer',glyph=g,id=m['id']) for g in ('o','a','aacute','space') for m in opened['masters']]
  read=await api.call('read_entities',dict(document_id=doc,entities=rows,fields=['id','width','bounds','outlineHash']),'T01')
  selection=await api.call('read_entities',dict(document_id=doc,entities=[dict(kind='selection')],fields=['glyph','layer','selectedNodeCount','selectedAnchorCount','selectedComponentCount','selectedGuideCount','selectedOtherCount','nodes']),'T01')
  await asyncio.sleep(2);write('tasks/T01/timing.json',await setup('profile',enabled=False));write('tasks/T01/responses.json',dict(layers=read,selection=selection))
  start=await api.call('start_job',dict(document_id=doc,kind='width_delta',delta=12.375,glyphs=['o']),'T02')
  write('tasks/T02/start.json',start)
if __name__=='__main__':asyncio.run(main())
