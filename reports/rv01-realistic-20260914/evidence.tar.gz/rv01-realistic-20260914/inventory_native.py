from pathlib import Path
import json, time
from Foundation import NSURL
from GlyphsApp import GSFont,Glyphs,OFFCURVE,LINE
O=Path(__file__).resolve().parent
src=O/'font-source/RobotoSlab.glyphs'
t=time.perf_counter();r=GSFont.alloc().initWithURL_error_(NSURL.fileURLWithPath_(str(src)),None);f=r[0] if isinstance(r,tuple) else r
assert f is not None
names='o a s n at eight H A AE aacute space zero zero.slash f i f_i a.ss01 g.ss01'.split()
rows=[]
for name in names:
 g=f.glyphs[name]
 if g is None:continue
 for mi in range(len(f.masters)):
  l=g.layers[f.masters[mi].id]
  rows.append(dict(glyph=name,master=f.masters[mi].id,masterName=f.masters[mi].name,width=l.width,compatible=bool(g.mastersCompatible),compare=l.compareString(),paths=[dict(closed=bool(p.closed),nodes=[dict(x=n.position.x,y=n.position.y,type=str(n.type),smooth=bool(n.smooth)) for n in p.nodes]) for p in l.paths],anchors=[a.name for a in l.anchors],components=[c.componentName for c in l.components]))
result=dict(ok=True,host=str(Glyphs.versionNumber),build=str(Glyphs.buildNumber),glyphs=len(f.glyphs),masters=[dict(id=m.id,name=m.name) for m in f.masters],features=[dict(name=x.name,code=x.code,automatic=bool(x.automatic() if callable(x.automatic) else x.automatic),disabled=bool(x.disabled() if callable(x.disabled) else x.disabled)) for x in f.features],classes=[dict(name=x.name,code=x.code) for x in f.classes],prefixes=[dict(name=x.name,code=x.code) for x in f.featurePrefixes],rows=rows,nativeMs=(time.perf_counter()-t)*1000)
(O/'inventory-native.json').write_text(json.dumps(result,indent=2,default=str)+'\n')
print(json.dumps(dict(ok=True,glyphs=len(f.glyphs),masters=len(f.masters),features=[x.name for x in f.features])))
