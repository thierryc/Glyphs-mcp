from pathlib import Path
import json,hashlib,subprocess,time,os
O=Path(__file__).resolve().parent;R=O.parents[2];S=R/'build/milestone7/desktop'
def files(p):
 p=Path(p)
 if p.is_file():return {p.name:hashlib.sha256(p.read_bytes()).hexdigest()}
 return {str(q.relative_to(p)):hashlib.sha256(q.read_bytes()).hexdigest() for q in sorted(p.rglob('*')) if q.is_file() and '__pycache__' not in q.parts and q.name!='.DS_Store'}
paths={'realBaseline':S/'build/p13-curvature-candidate/fixtures/DactylotypeBaseline.glyphspackage','userFont':Path.home()/'Documents/fonts/Dactylotype/Dactylotype.glyphspackage','skills':Path.home()/'.codex/skills','installation':Path.home()/'Library/Application Support/Glyphs MCP/lean-v2','unrelatedSavedFile':Path('/private/tmp/vc01-full-20260912/v2-current-5/1789186800389374000-open-unrelated.glyphs')}
skills=['glyphs','glyphs-mcp-development','glyphs-mcp-scripting','glyphs-mcp-master-compatibility','glyphs-mcp-outlines-docs','glyphs-mcp-opentype-features']
result={'at':time.time(),'hostLoad':os.getloadavg(),'paths':{k:str(v) for k,v in paths.items()},'files':{k:files(v) for k,v in paths.items() if k not in ('skills','installation')},'skills':{n:files(paths['skills']/n) for n in skills},'crashes':sorted(str(p) for p in (Path.home()/'Library/Logs/DiagnosticReports').glob('Glyphs*'))}
result['processes']=subprocess.check_output(['ps','-axo','pid=,comm='],text=True)
(O/'freeze.json').write_text(json.dumps(result,indent=2)+'\n')
(O/'worktree-before.txt').write_text(subprocess.check_output(['git','status','--short'],cwd=S,text=True))
print(json.dumps({'baselineFiles':len(result['files']['realBaseline']),'baseline':str(paths['realBaseline']),'skills':list(result['skills']),'load':result['hostLoad']}))
