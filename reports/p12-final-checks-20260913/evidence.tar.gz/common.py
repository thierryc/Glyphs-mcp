import asyncio,json,os,sys,time,uuid
from pathlib import Path
from fastmcp import Client
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[3]
sys.path.insert(0,str(ROOT/'scripts'))
from compare_connection_routing import body,plain,now,measurement,SEVEN
def crash_guard():
 baseline=json.loads((OUT/'freeze.json').read_text())
 current={str(p) for p in (Path.home()/'Library/Logs/DiagnosticReports').glob('Glyphs*') if p.is_file()}
 new=sorted(current-set(baseline['crashes']))
 if new:
  save('crash-stop.json',dict(newReports=new,at=now()))
  raise RuntimeError('STOP: new Glyphs crash report: '+str(new))
 import subprocess
 processes=subprocess.check_output(['ps','-axo','pid=,comm='],text=True)
 pids=[int(line.strip().split(None,1)[0]) for line in processes.splitlines() if line.endswith('/Contents/MacOS/Glyphs 4')]
 if pids != [baseline['pid']]:
  save('crash-stop.json',dict(reason='Original Glyphs 4 process exited or changed',expectedPID=baseline['pid'],observedPIDs=pids,at=now()))
  raise RuntimeError('STOP: Glyphs 4 process changed; do not restart')
class Harness:
 def __init__(self,label):self.label=label;self.log=OUT/label;self.log.mkdir(exist_ok=True);self.calls=[]
 async def setup(self,action,**args):
  crash_guard()
  rid=str(time.time_ns())+'-'+action;c=dict(requestId=rid,action=action,**args);p=self.log/'native-request.tmp';p.write_text(json.dumps(c));p.replace(self.log/'native-request.json');dest=self.log/'native-acks'/(rid+'.json');start=time.perf_counter();guard_at=start
  while True:
   if time.perf_counter()-guard_at>.5:crash_guard();guard_at=time.perf_counter()
   if time.perf_counter()-start>40:raise TimeoutError(rid)
   if dest.exists():
    try:r=json.loads(dest.read_text());break
    except json.JSONDecodeError:pass
   await asyncio.sleep(.05)
  with (self.log/'setup-log.jsonl').open('a') as f:f.write(json.dumps(dict(at=now(),request=c,result=r if not r.get('ok') else {'ok':True,'nativeSetupMs':r['nativeSetupMs']},ack=str(dest),ms=(time.perf_counter()-start)*1000))+'\n')
  assert r['ok'],r;return r['data']
 async def call(self,name,args,phase):
  crash_guard()
  at=now();start=time.perf_counter()
  try:r=body(await self.client.call_tool_mcp(name,args))
  except Exception as e:r=dict(transportException=repr(e))
  row=dict(at=at,name=name,arguments=args,phase=phase,ms=(time.perf_counter()-start)*1000,result=r);self.calls.append(row)
  with (self.log/'calls.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
  return r,row['ms']
 async def connect(self):
  self.client=Client('http://127.0.0.1:'+('9680' if self.label=='v2' else '9682')+'/mcp/',timeout=45);await self.client.__aenter__()
  tools=[plain(t) for t in await self.client.list_tools()];self.catalog=tools
  suffix=str(time.time_ns());(self.log/('catalog-'+suffix+'.json')).write_text(json.dumps(tools,indent=2)+'\n');(self.log/('handshake-'+suffix+'.json')).write_text(json.dumps(plain(self.client.initialize_result),indent=2)+'\n')
  assert (set(t['name'] for t in tools)==SEVEN) if self.label=='v2' else len(tools)==87
  return await self.identity()
 async def identity(self):
  r,_=await self.call('get_status' if self.label=='v2' else 'get_server_info',{},'identity');s=r['data'] if self.label=='v2' else r;expected='61c6975537eabcd1b015df6ed8f754a45616da11c3c1106a766410ed88c779ae' if self.label=='v2' else 'c98c9840e87a9bb7773b8fe643f21e86400323874a35c695e8ad01eb5a46bacc';assert s['codeHash'].removeprefix('sha256:')==expected,s
  if self.label=='v2':assert s['bridge']['codeHash']=='sha256:bffc1729a4d7e8856c807629efa9022c14907d389134d78194c28a9949463e9b'
  return s
 async def resolve(self,path,phase):
  r,ms=await self.call('list_documents' if self.label=='v2' else 'list_open_fonts',{},phase+'-discovery');
  if self.label=='v2' and not r.get('ok'):raise RuntimeError('Document discovery failed: '+json.dumps(r))
  rows=r['data'] if self.label=='v2' else r;matches=[d for d in rows if d.get('path',d.get('filePath'))==path];assert len(matches)==1,r
  return matches[0]['id' if self.label=='v2' else 'fontIndex'],ms
 async def end(self):await self.client.__aexit__(None,None,None)
def save(name,data):(OUT/name).write_text(json.dumps(data,indent=2,default=str)+'\n')
