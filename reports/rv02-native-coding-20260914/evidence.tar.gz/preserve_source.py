from pathlib import Path
import json,subprocess,hashlib,difflib
O=Path(__file__).resolve().parent;R=O.parents[2];S=R/'build/milestone7/desktop';frozen=json.load(open(O/'freeze.json'))
tracked=subprocess.check_output(['git','diff','--name-only','-z'],cwd=S).decode().split('\0');before_names=set(str(Path(p).relative_to(S)) for p in frozen['preexisting']);before_hash=frozen['preexisting']
allowed={'skills/manifest.json','skills/glyphs/SKILL.md','skills/glyphs-mcp-development/SKILL.md','skills/glyphs-mcp-development/references/development-docs.md','skills/glyphs-mcp-scripting/SKILL.md','plugins/glyphs-mcp/skills/manifest.json','plugins/glyphs-mcp/skills/glyphs/SKILL.md','plugins/glyphs-mcp/skills/glyphs-mcp-development/SKILL.md','plugins/glyphs-mcp/skills/glyphs-mcp-development/references/development-docs.md','plugins/glyphs-mcp/skills/glyphs-mcp-scripting/SKILL.md','macos-installer/GlyphsMCPInstaller/Core/StarterProjectCreator.swift','macos-installer/GlyphsMCPInstaller/Resources/Starter/AGENTS.md','content/getting-started/use-agent-skills.mdx','src/glyphs-mcp/tests/test_codex_plugin.py','macos-installer/GlyphsMCPInstaller/Tests/GlyphsMCPInstallerTests/GlyphsMCPInstallerTests.swift'}
changed_unrelated=[]
for file,sha in before_hash.items():
 p=Path(file);rel=str(p.relative_to(S))
 if rel in allowed:continue
 if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=sha:changed_unrelated.append(rel)
assert not changed_unrelated,changed_unrelated
assert all(not (S/p).exists() for p in frozen['missing'])
# Reconstruct each original worktree file independently, without changing the source tree.
T=Path('/private/tmp/rv02-original-source');T.mkdir(exist_ok=True);chunks=[]
for rel in sorted(allowed):
 p=S/rel
 if not p.exists():continue
 baseline=subprocess.run(['git','show','HEAD:'+rel],cwd=S,capture_output=True)
 if baseline.returncode:
  assert rel in before_names,rel
  # Only this existing untracked Starter asset is edited; its source is mirrored
  # in the tracked built-in template, reconstructed below.
  continue
 q=T/rel;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(baseline.stdout)
 if rel in before_names:
  result=subprocess.run(['git','apply','--unsafe-paths','--include='+rel,str(O/'preexisting.diff')],cwd=T,capture_output=True,text=True)
  assert result.returncode==0,(rel,result.stderr)
  assert hashlib.sha256(q.read_bytes()).hexdigest()==before_hash[str(p)],rel
 old=q.read_text();new=p.read_text();chunks.extend(difflib.unified_diff(old.splitlines(keepends=True),new.splitlines(keepends=True),fromfile='a/'+rel,tofile='b/'+rel))
# Resource is already a pre-existing untracked asset: commit only tracked built-in
# source and its changed resource together? Record the pre-existing asset explicitly.
resource='macos-installer/GlyphsMCPInstaller/Resources/Starter/AGENTS.md'
p=S/resource
if resource in before_names and not (T/resource).exists():
 old=p.read_text().replace('For OpenType source work use $glyphs-mcp-opentype-features and its native workflow.\n','')
 assert hashlib.sha256(old.encode()).hexdigest()==before_hash[str(p)]
 q=T/resource;q.parent.mkdir(parents=True,exist_ok=True);q.write_text(old)
 # This asset has no HEAD entry; do not silently absorb it into the source commit.
(O/'rv02-only.patch').write_text(''.join(chunks))
(O/'source-preservation.json').write_text(json.dumps(dict(preexistingFilesChecked=len(before_hash),unrelatedChanged=changed_unrelated,missingStillAbsent=frozen['missing'],scopedTracked=list(sorted(allowed)),preexistingUntrackedModified=[resource] if resource in before_names and subprocess.run(['git','cat-file','-e','HEAD:'+resource],cwd=S,capture_output=True).returncode else []),indent=2))
print('Unrelated source preserved. Scoped patch prepared:',len(chunks),'lines')
