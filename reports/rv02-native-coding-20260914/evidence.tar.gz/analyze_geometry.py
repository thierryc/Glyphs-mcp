from pathlib import Path
import json,math,html
import numpy as np
O=Path(__file__).resolve().parent

def segments(path):
 nodes=path['nodes'];on=[i for i,n in enumerate(nodes) if n['type']!='offcurve'];result=[]
 for j,idx in enumerate(on):
  previous=on[j-1];indices=[];i=previous
  while True:
   indices.append(i)
   if i==idx:break
   i=(i+1)%len(nodes)
  pts=[(nodes[i]['x'],nodes[i]['y']) for i in indices]
  assert len(pts) in (2,4),(idx,len(pts));result.append(pts)
 return result

def evalc(p,t):
 if len(p)==2:return [(1-t)*p[0][i]+t*p[1][i] for i in (0,1)]
 return [sum(math.comb(3,k)*(1-t)**(3-k)*t**k*p[k][i] for k in range(4)) for i in (0,1)]
def poly(path):
 pts=[]
 for s in segments(path):
  count=2 if len(s)==2 else 151
  pts.extend(evalc(s,t/(count-1)) for t in range(count-1))
 pts.append(pts[0]);return np.array(pts)
def sampled_distance(a,b):
 B=b[:-1];v=b[1:]-B;den=(v*v).sum(axis=1);den[den==0]=1;worst=0
 for k in range(0,len(a),64):
  P=a[k:k+64,None,:];t=np.clip(((P-B)*v).sum(axis=2)/den,0,1);d=np.sqrt(((P-(B+t[:,:,None]*v))**2).sum(axis=2));worst=max(worst,float(d.min(axis=1).max()))
 return worst

def svg_path(path):
 ss=segments(path);d='M '+' '.join(map(str,ss[0][0]))
 for p in ss:d+=(' L ' if len(p)==2 else ' C ')+' '.join(str(c) for pt in p[1:] for c in pt)
 return d+' Z'
def draw_views(tid,data,suffix=''):
 W,H=1400,590;parts=[f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}"><rect width="100%" height="100%" fill="#faf9f6"/>',f'<text x="30" y="35" font-size="23" font-family="sans-serif">{tid} · Roboto Slab · native outline evidence</text><text x="30" y="60" font-size="14" font-family="sans-serif">Gray: before · teal: after · orange: added on-curves · coordinates plotted without rounding</text>']
 for col,(a,b) in enumerate(zip(data['before']['layers'],data['after']['layers'])):
  alln=[n for p in a['paths']+b['paths'] for n in p['nodes']];xmin=min(n['x'] for n in alln);xmax=max(n['x'] for n in alln);ymin=min(n['y'] for n in alln);ymax=max(n['y'] for n in alln);scale=min(370/(xmax-xmin),420/(ymax-ymin));x0=50+col*460-xmin*scale;y0=510+ymin*scale
  parts.append(f'<text x="{50+col*460}" y="90" font-size="19" font-family="sans-serif">{["Thin","Regular","Black"][col]}</text><g transform="translate({x0},{y0}) scale({scale},{-scale})">')
  for p in a['paths']:parts.append(f'<path d="{svg_path(p)}" fill="none" stroke="#999" stroke-width="{3/scale}"/>')
  for p in b['paths']:parts.append(f'<path d="{svg_path(p)}" fill="none" stroke="#007d86" stroke-width="{1.15/scale}"/>')
  old={n['id'] for p in a['paths'] for n in p['nodes']}
  for p in b['paths']:
   for n in p['nodes']:
    if n['type']=='offcurve':continue
    color='#c95716' if n['id'] not in old else '#007d86';radius=4/scale if n['id'] not in old else 1.8/scale
    parts.append(f'<circle cx="{n["x"]}" cy="{n["y"]}" r="{radius}" fill="{color}"/>')
  parts.append('</g>')
 parts.append('</svg>');(O/'visuals'/f'{tid}{suffix}.svg').write_text(''.join(parts))
result={}
for tid in ('T04','T05','T06','T07','T08'):
 folder=O/'tasks'/tid;corrected=folder/'native-outlines-corrected.json';p=corrected if corrected.exists() else folder/'native-outlines.json';data=json.loads(p.read_text());draw_views(tid,data);rows=[]
 for a,b in zip(data['before']['layers'],data['after']['layers']):
  distances=[max(sampled_distance(poly(pa),poly(pb)),sampled_distance(poly(pb),poly(pa))) for pa,pb in zip(a['paths'],b['paths'])]
  row=dict(layer=a['id'],sampledBidirectionalDistance=max(distances),nodeCountsBefore=[len(p['nodes']) for p in a['paths']],nodeCountsAfter=[len(p['nodes']) for p in b['paths']])
  if tid=='T08':
   A=[(n['x'],n['y']) for n in a['paths'][0]['nodes'][3:7]];B=[(n['x'],n['y']) for n in b['paths'][0]['nodes'][3:10]]
   row['polynomialMaxError']=max(math.dist(evalc(A,t/100),evalc(B[:4],t/50) if t<=50 else evalc(B[3:],(t-50)/50)) for t in range(101));row['passed']=row['polynomialMaxError']<=1e-9
  if tid=='T05':
   a0,a1=a['paths'][0]['nodes'][:2];n=b['paths'][0]['nodes'][1];row['exactMidpoint']=n['x']==(a0['x']+a1['x'])/2 and n['y']==(a0['y']+a1['y'])/2
  rows.append(row)
 result[tid]=rows
p=O/'tasks/T08/native-interpolation.json'
if p.exists():
 d=json.loads(p.read_text());rows=[]
 for aa,bb in zip(d['before'],d['after']):
  a=aa['outline']['layers'][0];b=bb['outline']['layers'][0];A=[(n['x'],n['y']) for n in a['paths'][0]['nodes'][3:7]];B=[(n['x'],n['y']) for n in b['paths'][0]['nodes'][3:10]]
  rows.append(dict(instance=aa['instance'],polynomialError=max(math.dist(evalc(A,t/100),evalc(B[:4],t/50) if t<=50 else evalc(B[3:],(t-50)/50)) for t in range(101)),beforeNodes=len(a['paths'][0]['nodes']),afterNodes=len(b['paths'][0]['nodes'])))
 result['nativeInterpolations']=rows
result['method']='Independent Bernstein-polynomial check at 101 parameters for the explicit split. Contour distances are sampled bidirectionally against 150 subdivisions per cubic; approximate, not a certified Hausdorff bound. Values exceeding 0.05 fail the proposed native-extrema tolerance.'
(O/'geometry.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
