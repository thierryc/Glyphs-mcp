"""Independent, bounded geometry proof for the recorded native cubic splits."""
from pathlib import Path
import json,math,numpy as np
O=Path(__file__).resolve().parent
# Reuse the read-only parser, without running the complete plotting script.
ns={};import ast
source=ast.parse((O/'analyze_geometry.py').read_text())
for f in source.body:
 if isinstance(f,ast.FunctionDef) and f.name in ('segments','evalc'):exec(compile(ast.Module(body=[f],type_ignores=[]),'geometry-parser','exec'),{'math':math},ns)
segments,evalc=ns['segments'],ns['evalc']
def param(P,X):
 if len(P)==2:
  v=np.array(P[1])-P[0];t=float(np.dot(np.array(X)-P[0],v)/np.dot(v,v));return t,math.dist(evalc(P,t),X)
 roots=[0.,1.]
 for ax in (0,1):
  a,b,c,d=[p[ax] for p in P];coef=[-a+3*b-3*c+d,3*a-6*b+3*c,-3*a+3*b,a-X[ax]]
  roots += [float(r.real) for r in np.roots(np.trim_zeros(coef,'f')) if abs(r.imag)<1e-7 and -1e-7<=r.real<=1.0000001]
 return min(((t,math.dist(evalc(P,t),X)) for t in roots),key=lambda x:x[1])
def deriv(P,t):return [3*((1-t)**2*(P[1][a]-P[0][a])+2*(1-t)*t*(P[2][a]-P[1][a])+t*t*(P[3][a]-P[2][a])) for a in (0,1)]
def certificate(before,after):
 results=[]
 for pi,(pa,pb) in enumerate(zip(before['paths'],after['paths'])):
  A=segments(pa);coverage={i:[] for i in range(len(A))};bounds=[]
  for b in segments(pb):
   candidates=[]
   for i,a in enumerate(A):
    if len(a)!=len(b):continue
    t0,e0=param(a,b[0]);t1,e1=param(a,b[-1])
    if t1<=t0 or min(t0,t1)<-1e-7 or max(t0,t1)>1.0000001:continue
    if len(a)==2:expected=[evalc(a,t0),evalc(a,t1)]
    else:
     p,q=evalc(a,t0),evalc(a,t1);dp,dq=deriv(a,t0),deriv(a,t1);expected=[p,[p[j]+(t1-t0)/3*dp[j] for j in (0,1)],[q[j]-(t1-t0)/3*dq[j] for j in (0,1)],q]
    bound=max(math.dist(x,y) for x,y in zip(expected,b));candidates.append((bound,i,t0,t1))
   assert candidates,'No correspondence for recorded segment';bound,i,t0,t1=min(candidates);bounds.append(bound);coverage[i].append((t0,t1))
  gaps=[]
  for i,ivs in coverage.items():
   end=0
   for start,stop in sorted(ivs):gaps.append(abs(start-end));end=stop
   gaps.append(abs(1-end))
  results.append(dict(path=pi,originalSegments=len(A),resultSegments=len(segments(pb)),maxControlPolygonDeviationBound=max(bounds),maxParameterCoverageGap=max(gaps),passed=max(bounds)<=.05 and max(gaps)<=1e-7))
 return results
allrows={}
for label,file in [('first','native-outlines.json'),('precision-control','native-outlines-corrected.json')]:
 d=json.loads((O/'tasks/T07'/file).read_text());rows=[]
 for a,b in zip(d['before']['layers'],d['after']['layers']):
  try:rows.append(dict(layer=a['id'],paths=certificate(a,b)))
  except Exception as e:rows.append(dict(layer=a['id'],error=str(e)))
 allrows[label]=rows
allrows['method']='Match each recorded result segment to a restriction of an original cubic/line by solving endpoint parameters. Maximum control-point difference bounds the whole Bézier deviation by convexity. Verify all original segment parameter intervals are covered with gap <=1e-7. This certifies this fixture only, not arbitrary native normalization.'
(O/'tasks/T07/geometry-certificate.json').write_text(json.dumps(allrows,indent=2));print(json.dumps(allrows,indent=2))
