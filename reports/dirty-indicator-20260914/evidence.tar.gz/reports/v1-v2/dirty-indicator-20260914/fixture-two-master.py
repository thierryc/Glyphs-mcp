"""Native, reproducible disposable fixture. Never opens an existing GUI document."""
from pathlib import Path
import hashlib,json,re,sys
from GlyphsApp import GSFont,GSFontMaster,GSGlyph,GSPath,GSNode,GSAnchor,GSHint,LINE,STEM,Glyphs
out=Path(sys.argv[-1]).resolve();assert not out.exists(),out
font=GSFont();font.familyName='Dirty Indicator Test';font.grid=0
master=GSFontMaster();master.id='DIRTY-TEST-MASTER-01';font.masters.append(master);master.name='Regular';master.ascender=800;master.descender=-200;master.xHeight=500;master.capHeight=700
for index,name in enumerate(['control','unrelated']):
 g=GSGlyph(name);font.glyphs.append(g);g.userData['preserve']='glyph-'+name
 layer=g.layers[master.id];layer.width=600+index*100;layer.userData['preserve']='layer-'+name
 path=GSPath();path.closed=True
 for n,(x,y) in enumerate([(50.125,.25),(250.125,.25),(250.125,700.25),(50.125,700.25)]):
  node=GSNode((x,y),LINE);node.name='node-'+str(n);node.userData['preserve']=n;path.nodes.append(node)
 layer.shapes.append(path);layer.anchors.append(GSAnchor('top',(150.125,700.25)))
 hint=GSHint();hint.type=STEM;hint.originNode=path.nodes[0];hint.targetNode=path.nodes[1];layer.hints.append(hint)
font.save(str(out))
s=out.read_text();s=re.sub(r'(?m)^(date|lastChange) = "[^"]*";',r'\1 = "2026-09-14 00:00:00 +0000";',s);out.write_text(s)
print(json.dumps(dict(path=str(out),sha256=hashlib.sha256(out.read_bytes()).hexdigest(),host=str(Glyphs.versionNumber),build=str(Glyphs.buildNumber),master=master.id,glyphs=['control','unrelated'])))
