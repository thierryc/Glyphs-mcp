from pathlib import Path
import re,shutil,json
O=Path(__file__).resolve().parent;R=O.parents[2];S=R/'build/milestone7/desktop';B=R/'reports/v2-realistic/20260914'
(O/'artifacts').mkdir(exist_ok=True);(O/'tasks').mkdir(exist_ok=True);shutil.copytree(B/'font-source',O/'font-source',dirs_exist_ok=True)
for n in ('native_oracle.py','analyze_geometry.py'):
 shutil.copy(B/n,O/n)
raw=(B/'artifacts/outline_tasks.py').read_text().split('# Qualification exposed')[0]
# The small actions are reused, but precision control is the executable candidate recipe.
recipe=re.findall(r'```python\n(.*?)```',(S/'skills/glyphs-mcp-development/references/native-precision.md').read_text(),re.S)[0]
wrapper='''\n# RV02: execute the candidate precision recipe around the existing bounded actions.\nPRECISION_RECIPE = %r\ndef precise_action(action, glyph):\n def run(font, master_ids):\n  expected=[m.id for m in font.masters]\n  if master_ids != expected: raise ValueError('This trial requires all explicit ordinary master IDs')\n  target_layers=layers(font,glyph,master_ids)\n  result=[]\n  def operation(targets): result.append(action(font,master_ids))\n  exec(PRECISION_RECIPE,dict(target_layers=target_layers,perform_requested_operation=operation,verify_exact_requested_values=lambda targets: None))\n  return result[0]\n return run\n''' % recipe
for name,glyph in [('adjust_handle','o'),('add_stem_midpoint','H'),('remove_stem_midpoint','H'),('add_extrema','at'),('split_o_midpoint','o')]:wrapper+=f'{name}=precise_action({name},{glyph!r})\n'
(O/'artifacts/outline_tasks.py').write_text(raw+wrapper)
shutil.copy(B/'artifacts/feature_tasks.py',O/'artifacts/feature_tasks.py')
shutil.copy(B/'artifacts/Realistic Master Audit.py',O/'artifacts/Realistic Master Audit.py')
# Preserve the independent assertions; fix the trial setup and add stronger success checks.
s=(B/'run_native.py').read_text().replace('import json,time,sys,traceback,importlib.util,copy,os','import json,time,sys,traceback,importlib.util,copy,os,shutil')
s=s.replace('f=load(SRC);mids=', 'copy_path=d/"source.glyphs";shutil.copy(SRC,copy_path);f=load(copy_path);mids=')
s=s.replace("d.mkdir(exist_ok=True)","d.mkdir(exist_ok=True,parents=True)")
s=s.replace("before=records(f);view=", "before=records(f);rounding_before=[bool(value(f.glyphs[target_name].layers[mid],'temporarilyDisableRounding')) for mid in mids] if target_name else [];view=")
s=s.replace("row['assertions']=verify(f,mids,before,after,result)","row['assertions']=verify(f,mids,before,after,result)\n  if target_name:\n   row['assertions'].append(assertion('rounding flags restored',rounding_before,[bool(value(f.glyphs[target_name].layers[mid],'temporarilyDisableRounding')) for mid in mids]))\n   write(d/'records.json',dict(before=before,after=after))")
s=s.replace("n.position=(n.position.x+.125,n.position.y)","old=bool(value(f.glyphs['H'].layers[m[-1]],'temporarilyDisableRounding'));f.glyphs['H'].layers[m[-1]].setTemporarilyDisableRounding_(True);n.position=(n.position.x+.125,n.position.y);f.glyphs['H'].layers[m[-1]].setTemporarilyDisableRounding_(old)")
s=s.replace("r=f.compileFeatures();return dict", "r=f.compileFeatures();assert isinstance(r,tuple) and len(r)==2 and r[0] is True,repr(r);return dict")
s=s.replace("try:r=f.compileFeatures();errors.append", "try:r=f.compileFeatures();assert isinstance(r,tuple) and len(r)==2 and r[0] is False,repr(r);errors.append")
s=s.replace("feature.code='sub g by g.ss01;';r=f.compileFeatures()", "feature.code='sub g by g.ss01;';r=f.compileFeatures();assert isinstance(r,tuple) and len(r)==2 and r[0] is True,repr(r)")
# Actual file revision verification is a separate snippet trial, not this historical in-memory control.
start=s.index("# Each script revision");end=s.index("run('T10'",start);s=s[:start]+s[end:]
(O/'run_native.py').write_text(s)
print('Prepared fresh-copy trials T04–T08, T10–T12 and original read-only oracle.')
