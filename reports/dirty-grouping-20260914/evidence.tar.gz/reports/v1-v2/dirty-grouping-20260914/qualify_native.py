"""Isolated native grouping gate. No GUI document or installed code changes."""
import json,sys
from pathlib import Path
from types import SimpleNamespace as NS
O=Path(__file__).resolve().parent;R=O.parents[2];S=R/'build/milestone7/desktop'
sys.path.insert(0,str(S/'scripts'))
from qualify_simple_v2_slant_native import native_worker,GlyphsAdapter,BridgeCore
from glyphs_mcp_bridge.native_undo import NativeUndoScope
from Foundation import NSUndoManager
import ast,objc
from GlyphsApp import GSPath,Glyphs
for n in ast.parse((R/'reports/v1-v2/09-spacing/NativeQualification.py').read_text()).body:
 if isinstance(n,ast.FunctionDef) and n.name in ('ident','point','userdata','snapshot'):
  exec(compile(ast.unparse(n),'existing-oracle','exec'))
rows=[]
def setup():
 f=native_worker._load_font(O/'ThreeMasterTest.glyphs');dm=NSUndoManager.alloc().init()
 wrapper=NS(glyphs=f.glyphs,masters=f.masters,grid=f.grid,upm=f.upm,kerning=f.kerning,userData=f.userData,familyName=f.familyName,filepath=str(O/'ThreeMasterTest.glyphs'),parent=NS(isDocumentEdited=lambda:False,changeCount=lambda:0,undoManager=lambda:dm))
 a=GlyphsAdapter(NS(fonts=[wrapper]));d=a.list_documents()[0];queue=[];core=BridgeCore(a,queue.append,chunk_limit=1)
 changes=[dict(kind='set',glyph=g.name,layer=l.layerId,field='width',before=l.width,after=l.width+8) for g in f.glyphs for l in g.layers]
 patch=dict(version=1,jobId='native-group',documentId=d['id'],sourcePath=wrapper.filepath,sourceHash='sha256:'+'a'*64,generation=0,changes=changes,summary='Grouping gate')
 return f,dm,a,d,queue,core,patch
def data(f):
 # Use native layer evidence; font.parent is absent in this CLI process.
 return [dict(name=g.name,layers=[dict(id=l.layerId,width=l.width,nodes=[[(n.position.x,n.position.y,n.type,n.smooth,str(n.userData),ident(n)) for n in p.nodes] for p in l.paths],anchors=[(a.name,a.position.x,a.position.y,ident(a)) for a in l.anchors],hints=[(ident(h),ident(h.originNode),ident(h.targetNode)) for h in l.hints],userData=str(l.userData),objects=[ident(l),*[ident(p) for p in l.paths]]) for l in g.layers],lastChange=str(g.lastChange),metadata=str(g.userData),object=ident(g)) for g in f.glyphs]
def flags(f):return [(g.undoManager().groupingLevel(),bool(g.undoManager().groupsByEvent())) for g in f.glyphs]
def drain(q):
 while q:q.pop(0)()
for case in ('complete','cancel','partial-write-failure','preexisting-group','document-fallback'):
 f,dm,a,d,q,core,p=setup();before=data(f);assert flags(f)==[(0,True),(0,True)]
 if case=='preexisting-group':
  m=f.glyphs[0].undoManager();m.setGroupsByEvent_(False);m.beginUndoGrouping()
  core.begin_apply(p);drain(q);result=core.operation(p['jobId'])
  assert result['status']=='failed' and 'open group' in result['error']['message'],result
  assert m.groupingLevel()==1 and not m.groupsByEvent() and data(f)==before
  m.endUndoGrouping();m.setGroupsByEvent_(True)
 elif case=='document-fallback':
  s=NativeUndoScope(dm);assert not dm.canUndo();s.manager_for(None);assert dm.groupingLevel()==1 and not dm.groupsByEvent();s.finish('Fallback');assert dm.groupingLevel()==0 and dm.groupsByEvent()
  result=dict(status='passed',fontDataUnchanged=data(f)==before)
 else:
  if case=='partial-write-failure':
   original=a._write_exact;calls=[0]
   def fail(l,c,v):
    original(l,c,v);calls[0]+=1
    if calls[0]==1:raise RuntimeError('Injected native setter failure after write')
   a._write_exact=fail
  core.begin_apply(p);q.pop(0)()
  if case=='cancel':core.discard(p['jobId'])
  drain(q);result=core.operation(p['jobId'])
  if case=='complete':
   assert result['status']=='applied';assert not dm.canUndo();after=data(f)
   counts=[g.changeCount() if callable(g.changeCount) else g.changeCount for g in f.glyphs]
   for g in f.glyphs:g.undoManager().undo()
   assert data(f)==before
   first=[g.changeCount() if callable(g.changeCount) else g.changeCount for g in f.glyphs];assert first==[0,0],first
   for g in f.glyphs:g.undoManager().redo()
   assert data(f)==after
   for g in f.glyphs:g.undoManager().undo()
   assert data(f)==before
   result.update(firstUndoCounts=first,appliedCounts=counts,redoUndoCounts=[g.changeCount() if callable(g.changeCount) else g.changeCount for g in f.glyphs])
  else:
   assert result['status']==('cancelled' if case=='cancel' else 'failed'),result
   assert data(f)==before
 assert flags(f)==[(0,True),(0,True)]
 rows.append(dict(case=case,passed=True,result=result,finalGroups=flags(f)))
out=dict(host=str(Glyphs.versionNumber),build=str(Glyphs.buildNumber),mode='isolated native CLI; no GUI document dirty assertion',cases=rows)
(O/'native-gate.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
