import asyncio,json,time
from session import *
async def main():
 target=json.loads((O/'live-target.json').read_text());job=json.loads((O/'tasks/T02/start.json').read_text())['data']['id']
 async with API() as a:
  write('tasks/T02/native-before.json',await setup('proof'));await setup('profile',enabled=True)
  r=await a.call('apply_job',dict(job_id=job,include_preview=False),'T02');write('tasks/T02/apply.json',r)
  for i in range(30):
   if not r.get('ok') or r['data']['status'] in ('applied','failed','partial','interrupted'):break
   await asyncio.sleep(.25);r=await a.call('get_job',dict(job_id=job,include_preview=False),'T02')
  await asyncio.sleep(2);write('tasks/T02/apply-timing.json',await setup('profile',enabled=False));write('tasks/T02/native-after.json',await setup('proof'))
  fields=dict(document_id=target['document_id'],entities=[dict(kind='layer',glyph='o',id=m['id']) for m in target['masters']],fields=['width','outlineHash'])
  write('tasks/T02/live-after.json',await a.call('read_entities',fields,'T02'))
  print(json.dumps(r,indent=2))
asyncio.run(main())
