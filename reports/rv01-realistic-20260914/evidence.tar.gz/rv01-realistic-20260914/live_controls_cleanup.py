import asyncio,json,time
from session import *
async def main():
 t=json.loads((O/'tasks/T03/target.json').read_text());doc=t['document_id'];args=dict(document_id=doc,entities=[dict(kind='selection')],fields=['glyph','layer','selectedNodeCount','nodes'])
 async with API() as a:
  await setup('view',nodes=3);await setup('profile',enabled=True)
  await a.call('read_entities',args,'T01-warmup')
  for i in range(5):await a.call('read_entities',args,'T01-micro-repeat-'+str(i+1))
  await asyncio.sleep(2);write('tasks/T01/micro-timing.json',await setup('profile',enabled=False))
  bounded={**args,'entities':[dict(kind='selection',nodeLimit=1)]};write('tasks/T01/bounded.json',await a.call('read_entities',bounded,'T01-controls'))
  invalid={**args,'entities':[dict(kind='glyph',name='rv01.missing')],'fields':['name']};write('tasks/T01/missing-glyph.json',await a.call('read_entities',invalid,'T01-controls'))
  await setup('view',nodes=0);write('tasks/T01/empty.json',await a.call('read_entities',args,'T01-controls'))
  write('native-cleanup.json',await setup('finish'))
  write('tasks/T01/stale-id.json',await a.call('read_entities',args,'T01-controls'))
  write('runtime-after.json',await a.call('get_status',{},'identity-final'))
asyncio.run(main())
