from pathlib import Path
import json,sys
O=Path(__file__).resolve().parent;R=O.parents[3];S=R/'build/milestone7/desktop'
sys.path.insert(0,str(S/'scripts'))
from build_simple_v2 import build,_identity
root=S/'build/http-route-candidate-20260914';assert not root.exists(),root
first=build(root/'Lean',runtime_root=S/'build/private-runtime')
second=build(root/'Lean-repeat',runtime_root=S/'build/private-runtime')
assert first==second
assert _identity(root/'Lean')==_identity(root/'Lean-repeat')
old=json.loads((S/'build/p13-curvature-candidate/Lean/manifest.json').read_text())
assert set(first)==set(old)
assert all(first[k]==old[k] for k in first if k!='sidecar')
assert first['sidecar']['codeHash']!=old['sidecar']['codeHash']
(O/'candidate-manifest.json').write_text(json.dumps(first,indent=2)+'\n')
result=dict(build=str(root/'Lean'),repeat=str(root/'Lean-repeat'),identical=True,wholePayloadSHA256=_identity(root/'Lean'),changedComponents=['sidecar'],sidecar=first['sidecar']['codeHash'],bridge=first['bridge']['codeHash'])
(O/'build.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
