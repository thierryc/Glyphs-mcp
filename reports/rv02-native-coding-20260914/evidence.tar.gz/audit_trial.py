from pathlib import Path
import sys,importlib.util,json,hashlib,shutil,time
O=Path(__file__).resolve().parent;sys.path.insert(0,str(O))
from native_oracle import *
p=O/'artifacts/RV02 Master Audit.py';spec=importlib.util.spec_from_file_location('rv02_audit',p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
d=O/'tasks/T09'/('revision'+str(m.REVISION));d.mkdir(exist_ok=False);path=d/'source.glyphs';shutil.copy(O/'font-source/RobotoSlab.glyphs',path);f=load(path);before=records(f);mids=[x.id for x in f.masters];names=['o','a','aacute','space'];t=time.perf_counter();r=m.audit(f,names,mids);elapsed=(time.perf_counter()-t)*1000
expected=[]
for name in names:
 for mid in mids:
  l=next(x for x in before['data']['layers'] if x['glyph']==name and x['layer']==mid);nodes=[n for s in l['shapes'] if s['kind']=='path' for n in s['nodes']];expected.append([name,mid,l['width'],len(nodes),sum(n['type']=='offcurve' for n in nodes)])
actual=[[x['glyph'],x['layer'],x['width'],x['nodes'],x['offcurve']] for x in r['rows']];rejected=[]
for args in ((['missing.rv02'],mids),(['o'],['missing']),(['o']*21,mids)):
 try:m.audit(f,*args)
 except ValueError as e:rejected.append(str(e))
after=records(f);result=dict(artifactSHA256=hashlib.sha256(p.read_bytes()).hexdigest(),result=r,nativeReadMs=elapsed,expectedRows=expected,rowsExact=expected==actual,rejected=rejected,fullDataExact=before['data']==after['data'],objectsExact=before['objects']==after['objects'])
if m.REVISION==2:result['anchorsExact']=all(row['anchors']==sorted(a.name for a in f.glyphs[row['glyph']].layers[row['layer']].anchors) for row in r['rows'])
(d/'result.json').write_text(json.dumps(result,indent=2));assert result['rowsExact'] and result['fullDataExact'] and result['objectsExact'] and len(rejected)==3;print('Actual file revision',m.REVISION,'verified')
