import asyncio,json,sys
from common import Harness,save,OUT
from workflow import *
async def main():
 label,action=sys.argv[1:3];name=sys.argv[3] if len(sys.argv)>3 else 'slant00';h=Harness(label);await h.connect();dest=label+'/ui-'+name+'.json'
 if action=='apply':
  ev=await h.setup('open');doc,_=await h.resolve(ev['path'],'ui');await h.setup('edit',glyph=name);b=await h.setup('proof');p=await prepare(h,doc,[name],'ui-'+name) if label=='v2' else await v1prepare(h,doc,[name],'ui-'+name,slant_mode='balanced',curve_strength=0,stem_compensation=0)
  if label=='v2':await h.call('apply_job',dict(job_id=p['id'],include_preview=False),'ui-apply');await poll(h,p['id'],{'applied'},'ui-apply-poll')
  else:await v1apply(h,p,'ui-apply')
  a=await h.setup('proof');r=dict(documentId=doc,path=ev['path'],before=b,prepared=p,applied=a,applicationDifferences=slanted(b,a,[name],allow_backups=label=='v1'));save(dest,r)
 else:
  r=json.loads((OUT/dest).read_text());a=await h.setup('proof');r[action]=a
  if action=='undo':r['undoDifferences']=same(r['before'],a)
  elif action=='redo':r['redoDifferences']=same(r['applied'],a)
  elif action=='discard':
   await restore(h,r['documentId'],[name],r['prepared'],'ui');a=await h.setup('proof');r['discard']=a;r['discardDifferences']=same(r['before'],a);await h.setup('close')
  save(dest,r)
 print(json.dumps({k:v for k,v in r.items() if k.endswith('Differences')}));await h.end()
asyncio.run(main())
