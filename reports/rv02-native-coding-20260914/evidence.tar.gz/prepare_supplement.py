from pathlib import Path
import shutil,re
O=Path(__file__).resolve().parent;B=O.parent/'20260914';S=O.parents[2]/'build/milestone7/desktop'
(O/'visuals').mkdir(exist_ok=True);(O/'tasks/T09').mkdir(exist_ok=True)
for name in ('interpolation_control.py','target_collateral.py','certify_extrema.py'):
 s=(B/name).read_text()
 if name=='certify_extrema.py':s=s.replace("[('first','native-outlines.json'),('precision-control','native-outlines-corrected.json')]","[('candidate','native-outlines.json')]")
 if name in ('interpolation_control.py','target_collateral.py'):
  s=s.replace("f=load(O/'font-source/RobotoSlab.glyphs')", "copy_path=O/('supplement-'+str(time.time_ns())+'.glyphs');shutil.copy(O/'font-source/RobotoSlab.glyphs',copy_path);f=load(copy_path)")
  s='import shutil,time\n'+s
 if name=='interpolation_control.py':s=s[:s.index('# Verify the actual changed artifact')]+"print('native interpolation recorded')\n"
 (O/name).write_text(s)
s=(O/'analyze_geometry.py').read_text();s=s[:s.index('# First split attempt')]+s[s.index("p=O/'tasks/T08/native-interpolation.json'"):];(O/'analyze_geometry.py').write_text(s)
(O/'native_supplement.py').write_text('''from pathlib import Path
import sys,json,time,shutil,re,traceback
O=Path(__file__).resolve().parent;sys.path[:0]=[str(O),str(O/'artifacts')]
from native_oracle import *
from outline_tasks import PRECISION_RECIPE
from feature_tasks import create_ss20
from GlyphsApp import Glyphs
S=O.parents[2]/'build/milestone7/desktop'
path=O/'precision-failure.glyphs';shutil.copy(O/'font-source/RobotoSlab.glyphs',path);f=load(path);mids=[m.id for m in f.masters];layers=[f.glyphs['o'].layers[m] for m in mids];layers[1].setTemporarilyDisableRounding_(True)
before=records(f);flags=[bool(value(l,'temporarilyDisableRounding')) for l in layers];caught=None
try:
 exec(PRECISION_RECIPE,dict(target_layers=layers,perform_requested_operation=lambda _: (_ for _ in ()).throw(ValueError('RV02 intentional failure')),verify_exact_requested_values=lambda _:None))
except ValueError as e:caught=str(e)
after=records(f);(O/'precision-failure.json').write_text(json.dumps(dict(caught=caught,beforeFlags=flags,afterFlags=[bool(value(l,'temporarilyDisableRounding')) for l in layers],dataExact=before['data']==after['data'],objectsExact=before['objects']==after['objects']),indent=2))
path=O/'export-source.glyphs';shutil.copy(O/'font-source/RobotoSlab.glyphs',path);f=load(path);before=records(f);feature=create_ss20(f)
notes=(S/'skills/glyphs-mcp-development/references/glyphs4-api-notes.md').read_text();blocks=re.findall(r'```python\\n(.*?)```',notes,re.S)
exec(blocks[2],dict(font=f));exec(blocks[1],globals()|dict(feature=feature))
D=O/'tasks/T11/export';D.mkdir(parents=True,exist_ok=False);instance=next(i for i in f.instances if i.name=='Regular');env=dict(instance=instance,output_directory=D);start=time.perf_counter();exec(blocks[0],env);elapsed=(time.perf_counter()-start)*1000
r=dict(host=str(Glyphs.versionNumber),build=str(Glyphs.buildNumber),nativeExportMs=elapsed,exportReturn=repr(env['result']),outputs=[str(p) for p in D.iterdir()],priorFeaturesExact=before['data']['features']['features']==records(f)['data']['features']['features'][:-1]);(O/'export.json').write_text(json.dumps(r,indent=2))
print('Native precision failure and qualified API examples completed')
''')
print('Prepared native supplements and reused numerical proof.')
