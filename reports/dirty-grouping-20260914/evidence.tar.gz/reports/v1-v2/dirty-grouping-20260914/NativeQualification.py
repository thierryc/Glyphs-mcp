# MenuTitle: Dirty Grouping Qualification
"""Temporary disposable setup and read-only state recorder. No primary edits/Undo."""
import ast,hashlib,json,os,shutil,time,traceback
from pathlib import Path
from datetime import datetime,timezone
import objc
from GlyphsApp import Glyphs,GSPath
from AppKit import NSDocumentController
from PyObjCTools import AppHelper
R=Path('/Users/thierryc/Dev/github/thierryc/Glyphs-mcp-worktrees/v2')
O=R/'reports/v1-v2/dirty-grouping-20260914';FOLDER=Path('/private/tmp/dirty-grouping-20260914');FOLDER.mkdir(exist_ok=True)
# Existing native oracle; use non-allocating undoManagerCheck for diagnostic reads.
for n in ast.parse((R/'reports/v1-v2/09-spacing/NativeQualification.py').read_text()).body:
 if isinstance(n,ast.FunctionDef) and n.name in ('ident','point','userdata','snapshot'):
  source=ast.unparse(n).replace('f.parent.undoManager()', 'f.parent.undoManagerCheck()')
  exec(compile(source,'p09-oracle-nonallocating-manager','exec'))
def val(o,name):
 if o is None:return None
 try:
  value=getattr(o,name)
  return value() if callable(value) else value
 except (AttributeError,TypeError):return None
def manager(o):
 if o is None:return None
 return dict(address=ident(o),nativeClass=type(o).__name__,**{k:val(o,k) for k in ('canUndo','canRedo','groupingLevel','isUndoing','isRedoing','isUndoRegistrationEnabled','groupsByEvent','undoActionName','redoActionName')})
def compact(f):
 d=f.parent
 return dict(at=time.time(),monotonic=time.monotonic(),path=str(f.filepath),documentAddress=ident(d),dirty=bool(d.isDocumentEdited()),hasUnautosavedChanges=val(d,'hasUnautosavedChanges'),documentChangeCount=val(d,'changeCount'),isAutosaving=val(d,'isAutosaving'),isSaving=val(d,'isSaving'),lastAutosaveInterval=val(d,'lastAutosaveInterval'),autosavedContentsFileURL=str(val(d,'autosavedContentsFileURL')),autosavesInPlace=val(d,'autosavesInPlace'),documentUndo=manager(val(d,'undoManagerCheck')),windows=[dict(title=str(val(val(wc,'window'),'title')),edited=val(val(wc,'window'),'isDocumentEdited')) for wc in (val(d,'windowControllers') or [])],glyphs=[dict(name=g.name,changeCount=val(g,'changeCount'),lastChange=str(val(g,'lastChange')),undo=manager(val(g,'undoManagerCheck')),widths=[[l.layerId,l.width] for l in g.layers]) for g in f.glyphs])
def proof(f):
 s=snapshot(f);bounds=[l.pop('bounds') for l in s['data']['layers']]
 s['bounds']=bounds;s['data']['upm']=f.upm;s['data']['grid']=f.grid
 for row,g in zip(s['data']['glyphs'],f.glyphs):row['lastChange']=str(val(g,'lastChange'))
 s['state']=compact(f);return s
def stable(f):
 s=proof(f);return {k:s[k] for k in ('data','objects','hintReferences','bounds')}
EXISTING=list(Glyphs.fonts);BEFORE=[stable(f) for f in EXISTING]
state=dict(active=True,target=None,copies=[],seen=None,deadline=time.monotonic()+7200,watchEnd=0,watchLabel=None,samples=[],watches=[])
def check():
 assert [stable(f) for f in EXISTING]==BEFORE,'Original document changed; stop'
 assert all(f in EXISTING or (f.filepath and Path(str(f.filepath)).parent==FOLDER) for f in Glyphs.fonts),'Unexpected font'
def close():
 f=state['target'];state['target']=None;state['watchEnd']=0
 if f is not None:
  assert Path(str(f.filepath)).parent==FOLDER
  f.close(ignoreChanges=True)
def flush():
 (O/'native-timeline.json').write_text(json.dumps(dict(watches=state['watches'],samples=state['samples']),indent=2,default=str)+'\n')
def execute(c):
 check();a=c['action']
 if a=='open':
  close();p=FOLDER/(c['requestId']+'.glyphs');assert not p.exists();fixture=c.get('fixture','DirtyIndicatorTest.glyphs');assert fixture in ('DirtyIndicatorTest.glyphs','ThreeMasterTest.glyphs');shutil.copy2(O/fixture,p)
  state['copies'].append(dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest()));state['target']=Glyphs.open(str(p),showInterface=True)
  assert state['target'] is not None
  return dict(path=str(p),proof=proof(state['target']))
 if a=='view':
  f=state['target'];name=c.get('glyph','control');assert name in ('control','unrelated')
  if f.currentTab:f.currentTab.text='/'+name
  else:f.newTab('/'+name)
  f.currentTab.masterIndex=c.get('master',0)
  return proof(f)
 if a=='proof':return proof(state['target'])
 if a=='watch':
  seconds=c.get('seconds',14);assert 0<seconds<=20 and len(state['watches'])<40
  state['watchEnd']=time.monotonic()+seconds;state['watchLabel']=c['label'];state['watches'].append(dict(label=c['label'],start=time.time(),seconds=seconds))
  return proof(state['target'])
 if a=='close':close();flush();return dict(documents=len(Glyphs.fonts))
 if a=='finish':
  close();flush();state['active']=False;check()
  return dict(pid=os.getpid(),autosavingDelay=float(NSDocumentController.sharedDocumentController().autosavingDelay()),copies=state['copies'],existing=[dict(path=str(f.filepath),dirty=bool(f.parent.isDocumentEdited())) for f in EXISTING],originalsExact=[stable(f) for f in EXISTING]==BEFORE)
 raise ValueError('Unsupported diagnostic action: '+str(a))
def pump():
 if not state['active']:return
 if time.monotonic()>state['deadline']:state['active']=False;flush();return
 p=O/'native-request.json'
 if p.exists():
  c=json.loads(p.read_text())
  if c['requestId']!=state['seen']:
   state['seen']=c['requestId'];start=time.perf_counter()
   try:result=dict(ok=True,data=execute(c))
   except Exception:result=dict(ok=False,error=traceback.format_exc())
   result['nativeMs']=(time.perf_counter()-start)*1000
   dest=O/'native-acks';dest.mkdir(exist_ok=True);tmp=dest/(c['requestId']+'.tmp');tmp.write_text(json.dumps(result,indent=2,default=str)+'\n');tmp.replace(tmp.with_suffix('.json'))
 if state['target'] is not None and time.monotonic()<state['watchEnd'] and len(state['samples'])<3200:
  state['samples'].append(dict(label=state['watchLabel'],state=compact(state['target'])))
 elif state['watchEnd']:
  state['watchEnd']=0;flush()
 if state['active']:AppHelper.callLater(.25,pump)
(O/'native-ready.json').write_text(json.dumps(dict(pid=os.getpid(),host=str(Glyphs.versionNumber),build=str(Glyphs.buildNumber),autosavingDelay=float(NSDocumentController.sharedDocumentController().autosavingDelay()),existing=[dict(path=str(f.filepath),dirty=bool(f.parent.isDocumentEdited())) for f in EXISTING],originals=BEFORE,activeReporters=[type(r).__name__ for r in Glyphs.activeReporters]),indent=2,default=str)+'\n')
AppHelper.callLater(.25,pump)
