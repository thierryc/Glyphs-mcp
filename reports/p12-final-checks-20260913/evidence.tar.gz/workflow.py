import asyncio,copy,json,math,time
from pathlib import Path
from common import OUT,save
E=json.loads((OUT.parent/'expected.json').read_text());MID=[m['id'] for m in E['masters']]
def differences(a,b,path='',tol=0):
 if isinstance(a,dict) and isinstance(b,dict):
  return sum((differences(a.get(k),b.get(k),path+'/'+str(k),tol) for k in a.keys()|b.keys()),[])
 if isinstance(a,list) and isinstance(b,list):
  if len(a)!=len(b):return [path+': length '+str(len(a))+' != '+str(len(b))]
  return sum((differences(x,y,path+'/'+str(i),tol) for i,(x,y) in enumerate(zip(a,b))),[])
 if isinstance(a,(int,float)) and isinstance(b,(int,float)) and not isinstance(a,bool) and not isinstance(b,bool):
  return [] if abs(a-b)<=tol else [path+': '+str(a)+' != '+str(b)]
 return [] if a==b else [path+': '+str(a)[:100]+' != '+str(b)[:100]]
def same(b,a):
 errors=[]
 for role in ('target','unrelated'):
  for key in ('data','objects','hintReferences','drawing','masterAngles'):errors+=differences(b[role][key],a[role][key],role+'/'+key)
 return errors+differences(b['existing'],a['existing'],'existing')
def slanted(b,a,names,angle=12,pivot=0,mids=None,anchor_policy='shear',allow_backups=False):
 mids=MID if mids is None else mids;t=math.tan(math.radians(angle));expected=copy.deepcopy(b);actual=copy.deepcopy(a);errors=[];count=0
 for l in expected['target']['data']['layers']:
  if l['glyph'] not in names or l['layer'] not in mids:continue
  if any(s.get('automaticAlignment') for s in l['shapes']):continue
  count+=1
  for s in l['shapes']:
   for n in s.get('nodes',[]):n['position'][0]+=t*(n['position'][1]-pivot)
   if s['kind']=='component':
    mat=s['transform'];base_selected=s['name'] in names
    # Independent affine equation for translation-only fixture components.
    mat[4]+=t*(mat[5]-pivot)
    if not base_selected:mat[2]+=t
    elif pivot:mat[4]+=t*pivot
  if anchor_policy=='shear':
   for v in l['anchors']:v[1]+=t*(v[2]-pivot)
 # Bounds are derived; native path commands give a stricter geometry proof.
 for r in (expected,actual):
  for l in r['target']['data']['layers']:l.pop('bounds',None)
 if allow_backups:
  existing={(l['glyph'],l['layer']) for l in b['target']['data']['layers']}
  actual['target']['data']['layers']=[l for l in actual['target']['data']['layers'] if (l['glyph'],l['layer']) in existing]
  # Dedicated identity checks below retain all original objects and references.
 errors+=differences(expected['target']['data'],actual['target']['data'],'target/data',1e-9)
 if not set(b['target']['objects']).issubset(a['target']['objects']):errors.append('original native objects replaced')
 if not allow_backups and b['target']['objects']!=a['target']['objects']:errors.append('native objects changed')
 if not all(h in a['target']['hintReferences'] for h in b['target']['hintReferences']):errors.append('hint references changed')
 expected_drawing=copy.deepcopy(b['target']['drawing'])
 for key,paths in expected_drawing.items():
  g,m=key.split('/',1)
  if g not in names or m not in mids:continue
  for segments in paths:
   for segment in segments:
    for point in segment[1:]:point[0]+=t*(point[1]-pivot)
   if segments:segments[:]=min(segments[i:]+segments[:i] for i in range(len(segments)))
 actual_drawing={k:v for k,v in a['target']['drawing'].items() if k in expected_drawing}
 errors+=differences(expected_drawing,actual_drawing,'nativeDrawing',1e-9)
 errors+=differences(b['target']['masterAngles'],a['target']['masterAngles'],'masterAngles')
 for k in ('data','objects','hintReferences','drawing','masterAngles'):errors+=differences(b['unrelated'][k],a['unrelated'][k],'unrelated/'+k)
 errors+=differences(b['existing'],a['existing'],'existing')
 return errors
async def poll(h,job,terminal,phase):
 started=time.perf_counter()
 while True:
  r,_=await h.call('get_job',dict(job_id=job,include_preview=False),phase);assert r.get('ok'),r;d=r['data']
  if d['status'] in terminal:return d
  if d['status'] in ('failed','cancelled','discarded') or time.perf_counter()-started>90:raise RuntimeError(d)
  await asyncio.sleep(.1)
async def prepare(h,doc,names,phase,options=None):
 r,_=await h.call('start_job',dict(document_id=doc,kind='slant',glyphs=names,options=options or dict(masters=MID,angle=12,pivotY=0,preserveStraightStems=False)),phase+'-start');assert r.get('ok'),r
 d=await poll(h,r['data']['id'],{'ready','failed'},phase+'-poll')
 if d['status']=='ready':
  report=json.loads(Path(d['report']['path']).read_text());save(h.label+'/'+phase.replace('/','-')+'-report.json',report);d['externalReport']=report
 return d
async def codecall(h,doc,code,phase,limit=2000):
 r,_=await h.call('execute_code_with_context',dict(font_index=doc,code=code,capture_output=True,return_last_expression=False,max_output_chars=limit,max_error_chars=2000),phase);assert r.get('success') and not r.get('output_truncated'),r;return json.loads(r['output'])
async def read(h,doc,names,phase):
 if h.label=='v2':
  r,_=await h.call('read_entities',dict(document_id=doc,entities=[dict(kind='layer',glyph=g,id=m) for g in names for m in MID],fields=['width','outlineHash']),phase);assert r.get('ok'),r;return r['data']
 code='import json\nprint(json.dumps([[g,m,[[[float(n.position.x),float(n.position.y),str(n.type),bool(n.smooth)] for n in p.nodes] for p in font.glyphs[g].layers[m].paths],font.glyphs[g].layers[m].width] for g in '+repr(names)+' for m in '+repr(MID)+']))'
 return await codecall(h,doc,code,phase,50000)
def v1args(doc,names,mid,**kw):return dict(font_index=doc,source_font_index=doc,target_font_index=doc,source_master_id=mid,target_master_id=mid,scope='glyph_names',glyph_names=names,angle=12,slant_mode='raw',stem_policy='skip_for_raw',origin=4,copy_options=dict(paths=True,components=True,anchors=True,metrics=True),**kw)
def data(r):return r.get('data',r)
async def v1prepare(h,doc,names,phase,target_mids=None,**kw):
 sessions=[]
 for mid in (MID if target_mids is None else target_mids):
  args=v1args(doc,names,mid);args.update(kw);r,_=await h.call('preview_italic_first_pass_candidate',args,phase+'-preview');assert r.get('ok'),r;d=data(r);sid=d['sessionId']
  r,_=await h.call('review_outline_candidate_session',dict(font_index=doc,session_id=sid,include_diffs=True),phase+'-review');assert r.get('ok'),r;d=data(r);assert d['readyToAccept'],r
  token=d['reviewToken'];args=dict(font_index=doc,session_id=sid,review_token=token)
  r,_=await h.call('accept_outline_candidate_session',dict(**args,dry_run=True),phase+'-dry-run');assert r.get('ok'),r;sessions.append(args)
 return sessions
async def v1apply(h,sessions,phase):
 results=[]
 for args in sessions:
  r,_=await h.call('accept_outline_candidate_session',dict(**args,dry_run=False,confirm=True),phase+'-accept');results.append(r)
  if not r.get('ok'):break
 return results
async def restore(h,doc,names,prepared,phase):
 if h.label=='v2':
  r,_=await h.call('discard_job',dict(job_id=prepared['id'],include_preview=False),phase+'-discard');assert r.get('ok'),r;return await poll(h,prepared['id'],{'discarded','failed'},phase+'-discard-poll')
 code='import json\ncounts=[]\nfor name in '+repr(names)+':\n u=font.glyphs[name].undoManager();n=0\n while u.canUndo() and n<10:\n  u.undo();n+=1\n counts.append([name,n,bool(u.canUndo())])\nprint(json.dumps(counts))'
 return await codecall(h,doc,code,phase+'-undo')
