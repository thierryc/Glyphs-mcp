"""Normal FastMCP client against the installed endpoint, with redirects disabled."""
from pathlib import Path
import asyncio,json,time
import httpx
from fastmcp import Client
from fastmcp.client.transports import StreamableHttpTransport
O=Path(__file__).resolve().parent
async def main():
 rows=[]
 async def received(response):
  request=response.request
  try: message=json.loads(request.content)
  except (ValueError,httpx.RequestNotRead):message={}
  rows.append(dict(method=request.method,url=str(request.url),status=response.status_code,mcpMethod=message.get('method'),tool=message.get('params',{}).get('name')))
 def factory(headers=None,timeout=None,auth=None):
  return httpx.AsyncClient(headers=headers,timeout=timeout or 30,auth=auth,follow_redirects=False,event_hooks={'response':[received]})
 transport=StreamableHttpTransport('http://127.0.0.1:9680/mcp/',httpx_client_factory=factory)
 facts=json.loads((O/'candidate/facts.json').read_text());doc=facts['documents']['data'][0]['id']
 start=time.perf_counter()
 async with Client(transport,timeout=30) as client:
  catalog=await client.list_tools();assert [t.model_dump(mode='json',exclude_none=True) for t in catalog] # Decode success separately from wire-level exact catalog comparison.
  result=await client.call_tool_mcp('read_entities',dict(document_id=doc,entities=[dict(kind='selection')],fields=['glyph','layer','selectedNodeCount']))
  body=result.structuredContent or json.loads(result.content[0].text)
  assert body==facts['read']
  identity=await client.call_tool_mcp('get_status',{})
  identity=identity.structuredContent or json.loads(identity.content[0].text)
  assert identity['data']['codeHash']==json.loads((O/'candidate-manifest.json').read_text())['sidecar']['codeHash']
 assert not any(300<=r['status']<400 for r in rows),rows
 for name in ('get_status','read_entities'):
  matching=[r for r in rows if r['tool']==name]
  assert len(matching)==1 and matching[0]['status']==200,matching
 record=dict(ok=True,elapsedMs=(time.perf_counter()-start)*1000,tools=[t.name for t in catalog],responses=rows,liveSidecar=identity['data']['runtimeId'])
 (O/'sdk-client.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2))
asyncio.run(main())
