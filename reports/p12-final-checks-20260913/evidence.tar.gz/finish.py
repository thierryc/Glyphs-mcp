import asyncio,sys,json
from common import Harness,save
async def main():
 label=sys.argv[1];h=Harness(label);await h.connect();r=await h.setup('finish');save(label+'/native-finish.json',r);status=await h.identity();save(label+'/final-identity.json',status);r,_=await h.call('list_documents' if label=='v2' else 'list_open_fonts',{},'final-documents');save(label+'/final-documents.json',r);await h.end();print(label,'finished')
asyncio.run(main())
