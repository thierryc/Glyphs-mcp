import shutil,time
from pathlib import Path
import sys,json,time,importlib.util,hashlib
O=Path(__file__).resolve().parent;sys.path[:0]=[str(O),str(O/'artifacts')]
from native_oracle import load,target,records,digest,value
from outline_tasks import split_o_midpoint
copy_path=O/('supplement-'+str(time.time_ns())+'.glyphs');shutil.copy(O/'font-source/RobotoSlab.glyphs',copy_path);f=load(copy_path);names=('Light','Medium','Bold');before=[];after=[]
for name in names:
 instance=next(i for i in f.instances if i.name==name);inter=value(instance,'interpolatedFont');before.append(dict(instance=name,outline=target(inter,'o')))
flags0=[bool(value(l,'temporarilyDisableRounding')) for l in f.glyphs['o'].layers];split_o_midpoint(f,[m.id for m in f.masters]);flags1=[bool(value(l,'temporarilyDisableRounding')) for l in f.glyphs['o'].layers]
for name in names:
 instance=next(i for i in f.instances if i.name==name);inter=value(instance,'interpolatedFont');after.append(dict(instance=name,outline=target(inter,'o')))
(O/'tasks/T08/native-interpolation.json').write_text(json.dumps(dict(before=before,after=after,transientFlagsRestored=flags0==flags1),indent=2))
print('native interpolation recorded')
