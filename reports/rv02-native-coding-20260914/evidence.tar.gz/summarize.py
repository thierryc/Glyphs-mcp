from pathlib import Path
import json,hashlib,sys,os,time,statistics,re
O=Path(__file__).resolve().parent;R=O.parents[2];S=R/'build/milestone7/desktop';SK=Path.home()/'.codex/skills';B=O.parent/'20260914'
def write(name,data):(O/name).write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n')
def read(name):return json.load(open(O/name))
def tree(p):return {str(f.relative_to(p)):hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(p.rglob('*')) if f.is_file() and not any(x in f.parts for x in ('__pycache__','.git')) and f.name!='.DS_Store' and f.suffix not in ('.pyc','.pyo')}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
frozen=read('freeze.json');assertions=[]
def check(name,expected,observed,scope='qualification'):
 assertions.append(dict(name=name,expected=expected,observed=observed,scope=scope,status='passed' if expected==observed else 'failed'))
for t in read('native-summary.json'):
 for a in t['assertions']:assertions.append(dict(a,scope=t['id']))
 check('unrelated native data',True,t['preservation']['unrelatedDataExact'],t['id'])
 check('hint references',True,t['preservation']['hintReferencesExact'],t['id'])
for row in read('target-collateral.json'):
 for name in ('layerCollateralExact','gridExact','survivingNodeMetadataExact'):check(name,True,row[name],row['task'])
for row in read('geometry.json')['T05']:check('exact inserted midpoint',True,row['exactMidpoint'],'T05')
for row in read('geometry.json')['T06']:check('removed midpoint leaves exact sampled polygon',0,row['sampledBidirectionalDistance'],'T06')
for row in read('geometry.json')['T08']:check('split curve within 0.05 units',True,row['polynomialMaxError']<=.05,'T08')
for row in read('geometry.json')['nativeInterpolations']:check('native '+row['instance']+' interpolation within 0.05 units',True,row['polynomialError']<=.05,'T08')
for layer in read('tasks/T07/geometry-certificate.json')['candidate']:
 for path in layer['paths']:check('complete parameter coverage and geometry within tolerance',True,path['passed'],'T07')
j=read('precision-failure.json');check('exception propagated','RV02 intentional failure',j['caught']);check('mixed previous flags restored',j['beforeFlags'],j['afterFlags']);check('failure data preserved',True,j['dataExact']);check('failure objects preserved',True,j['objectsExact'])
for rev in (1,2):
 j=read(f'tasks/T09/revision{rev}/result.json')
 for name in ('rowsExact','fullDataExact','objectsExact'):check(name,True,j[name],f'T09 revision {rev}')
 check('bounded invalid inputs rejected',3,len(j['rejected']),f'T09 revision {rev}')
 if rev==2:check('anchor names exact',True,j['anchorsExact'],'T09 revision 2')
j=read('shaping.json')
for row in j['shapeCases']:check('shape '+row['text']+' '+str(row.get('features','control')),row['expected'],row['observed'],'OpenType')
for name in ('featureFlagsAndCodeExact','priorClassesExact','priorPrefixesExact'):check(name,True,j[name],'OpenType')
j=read('selector-results.json');oracle=read('metadata-oracle.json');check('three native metadata rows exact',oracle['rows'],[r['values'] for r in j['valid']['data']],'MCP')
check('named missing glyph','target_not_found',j['missing']['error']['code'],'MCP');check('error names requested glyph',True,'missing.rv02' in j['missing']['error']['message'],'MCP');check('same-ID read after missing glyph',True,j['repeat']['ok'],'MCP');check('closed document stale ID','document_not_found',read('stale-id.json')['error']['code'],'MCP')
j=read('installed-native-smoke.json')
for name in ('exactCoordinates','flagsRestored','unrelatedDataExact','objectsExact','invalidCompileRejected','correctedCompilePassed'):check(name,True,j[name],'installed native')
installed=read('installation.json')
for row in installed['verified']:check('installed '+row['name'],row['expected'],row['installed'],'installation')
check('seven tools',7,len(read('catalog.json')),'runtime')
for name in ('codeHash','runtimeId'):check('sidecar '+name,read('runtime-before.json')['data'][name],read('runtime-final.json')['data'][name],'runtime');check('bridge '+name,read('runtime-before.json')['data']['bridge'][name],read('runtime-final.json')['data']['bridge'][name],'runtime')
check('official corpus unchanged',frozen['sourceCorpus'],tree(S/'skills/glyphs-mcp-development/assets/knowledge'),'preservation')
for name,data in frozen['runtimeSource'].items():check(name+' unchanged',data,tree(S/name),'preservation')
for path,expected in frozen['protected'].items():check('protected file '+path,expected,sha(Path(path)),'preservation')
check('Dactylotype unchanged',frozen['userFont'],tree(Path('/Users/thierryc/Documents/fonts/Dactylotype/Dactylotype.glyphspackage')),'preservation')
changed_names={'glyphs','glyphs-mcp-development','glyphs-mcp-scripting','glyphs-mcp-opentype-features','.glyphs-mcp-skills.json'}
configured=tree(SK);other_before={k:v for k,v in frozen['configured'].items() if k.split('/')[0] not in changed_names};other_after={k:v for k,v in configured.items() if k.split('/')[0] not in changed_names};check('unrelated configured skills unchanged',other_before,other_after,'preservation')
backup_rows=[]
for p in (SK.parent/'glyphs-mcp-skill-backups').glob('*/backup.json'):
 try:j=json.load(open(p))
 except Exception:continue
 if j.get('source')==str(SK/'glyphs-mcp-opentype-features') and tree(Path(j['backup']))==tree(O/'installed-before/glyphs-mcp-opentype-features'):backup_rows.append(j)
check('obsolete OpenType tree has exact external backup',True,bool(backup_rows),'installation');write('backup-evidence.json',backup_rows)
new_crashes=[str(p) for p in (Path.home()/'Library/Logs/DiagnosticReports').iterdir() if 'glyphs' in p.name.lower() and p.is_file() and p.stat().st_mtime>frozen['at']];check('new Glyphs crash reports',[],new_crashes,'preservation')
check('RV01 script entry removed',False,'RV01 Realistic Qualification' in (O/'scripts-final.txt').read_text(),'cleanup');check('user window restored',True,'standard window MCP Selection Inspection.glyphs' in (O/'gui-final.txt').read_text(),'cleanup');check('protected window not Edited',False,'Edited' in (O/'gui-final.txt').read_text(),'cleanup')
# Retain manageable facts; large exact comparisons already retain their source hashes.
for a in assertions:
 for k in ('expected','observed'):
  if len(str(a[k]))>1200:a[k]=dict(sha256=hashlib.sha256(json.dumps(a[k],sort_keys=True,separators=(',',':')).encode()).hexdigest())
assertions.append(dict(name='populated-hint preservation',status='unverified',scope='native',reason='The edited real layers have zero hints.'))
write('assertions.json',dict(counts={status:sum(a['status']==status for a in assertions) for status in ('passed','failed','unverified')},assertions=assertions))
# Use the same historical tokenizer and literal/sorted-JSON method.
sys.path.insert(0,'/private/tmp/glyphs-metadata-tokenizer-20260910');os.environ['TIKTOKEN_CACHE_DIR']='/private/tmp/glyphs-metadata-tokenizer-cache';import tiktoken
enc=tiktoken.get_encoding('o200k_base');tokens=lambda s:len(enc.encode(s));compact=lambda j:json.dumps(j,sort_keys=True,separators=(',',':'),ensure_ascii=False)
texts={}
for name in ('glyphs','glyphs-mcp-development','glyphs-mcp-scripting','glyphs-mcp-opentype-features'):
 texts[name]=dict(before=tokens((O/'installed-before'/name/'SKILL.md').read_text()),after=tokens((SK/name/'SKILL.md').read_text()))
refs={str(p.relative_to(SK)):tokens(p.read_text()) for p in [SK/'glyphs-mcp-development/references/native-precision.md',SK/'glyphs-mcp-development/references/glyphs4-api-notes.md',SK/'glyphs-mcp-opentype-features/references/native-features.md']}
calls=[json.loads(l) for l in (O/'calls.jsonl').read_text().splitlines()];lat=[r['httpMs'] for r in calls if r['name']=='read_entities'];lat.sort()
def percentile(values,p):
 k=(len(values)-1)*p;i=int(k);return values[i]+(values[min(i+1,len(values)-1)]-values[i])*(k-i)
metrics=dict(tokenizer=dict(packageVersion=tiktoken.__version__,encoding='o200k_base',method='Literal text; one parsed response; sorted compact JSON with literal Unicode',actualBilledTokens=None),skillTokens=texts,focusedReferenceTokens=refs,publicCalls=len(calls),directConnectorStatusCalls=2,documentDiscoveries=sum(r['name']=='list_documents' for r in calls),retryAfterMCPError=0,metadataContinuationCalls=1,publicPayloadTokens=dict(requests=sum(tokens(compact(r['arguments'])) for r in calls),responses=sum(tokens(compact(r['result'])) for r in calls)),readLatency=dict(n=len(lat),median=statistics.median(lat),minimum=min(lat),maximum=max(lat),p95=percentile(lat,.95),unit='ms',limitation='Heterogeneous valid/missing/stale reads, descriptive samples, not repeated matched workflows or a responsiveness probe'),nativeActionMs={r['id']:r['nativeActionMs'] for r in read('native-summary.json')},nativeExportMs=read('export.json')['nativeExportMs'],installedNativeCoordinateMs=read('installed-native-smoke.json')['nativeCoordinateMs'],loadBefore=frozen['hostLoad'],loadAfter=os.getloadavg(),elapsedMinutes=(time.time()-frozen['at'])/60,installCommands=1,installerEntries=installed['entries'],glyphsRelaunches=0,nativeCLIInvocations=8,nativeTimingLimit='Directly measured isolated native action time; no GUI callback/queue probe. Load, oracle and process startup excluded. n=1 per phase.')
write('measurements.json',metrics)
print('assertions',read('assertions.json')['counts']);print('tokens',texts,refs);print('latency',metrics['readLatency']);print('new crashes',new_crashes)
assert not any(a['status']=='failed' for a in assertions)
