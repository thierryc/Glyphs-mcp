"""Archive only this investigation and its existing native-oracle dependency."""
import gzip,hashlib,io,json,shutil,tarfile
from pathlib import Path
O=Path(__file__).resolve().parent;R=O.parents[2]
D=R/'build/milestone7/desktop/reports/dirty-indicator-20260914'
assert not D.exists(),'Never replace a published evidence checkpoint'
initial=json.loads((O/'initial-public-status.json').read_text())['data']
final=json.loads((O/'final-public-state.json').read_text())['status']['structuredContent']['data']
facts=json.loads((O/'facts.json').read_text());audit=json.loads((O/'preservation-audit.json').read_text())
verification=dict(runtimeUnchanged=all(initial[k]==final[k] for k in ('runtimeId','codeHash','release','tools','protocol')),bridgeIdentityUnchanged=all(initial['bridge'][k]==final['bridge'][k] for k in ('runtimeId','codeHash','release','host')),sevenTools=len(final['tools'])==7,activeJobs=final['activity']['activeCount'],activeOperations=final['bridge']['activeOperations'],fixtureDeterministic=facts['fixture']['equal'],disposableSourcesUnchanged=all(c['unchanged'] for c in facts['copies']),disposableSources=len(facts['copies']),originalNativeDataObjectsPreserved=facts['cleanup']['originalsExact'],autosavingDelay=facts['cleanup']['autosavingDelay'],temporaryCommandsRemoved=json.loads((O/'menu-cleanup.json').read_text())['temporaryCommands']==[],allAvailableFrozenRootsUnchanged=audit['allAvailableRootsUnchanged'],unavailableFrozenRoots=audit['unavailableRoots'],newCrashReports=audit['newCrashReports'],productOrSkillFixImplemented=False)
assert verification['runtimeUnchanged'] and verification['bridgeIdentityUnchanged'] and verification['sevenTools']
assert verification['activeJobs']==verification['activeOperations']==0
assert verification['disposableSourcesUnchanged'] and verification['originalNativeDataObjectsPreserved'] and verification['temporaryCommandsRemoved']
(O/'verification.json').write_text(json.dumps(verification,indent=2)+'\n')
files=sorted([p for p in O.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc']+[R/'reports/v1-v2/README.md',R/'reports/v1-v2/09-spacing/NativeQualification.py'])
D.mkdir(parents=True);manifest=[]
with (D/'evidence.tar.gz').open('wb') as dest:
 with gzip.GzipFile(fileobj=dest,mode='wb',filename='',mtime=0) as z:
  with tarfile.open(fileobj=z,mode='w') as tar:
   for p in files:
    data=p.read_bytes();name=str(p.relative_to(R));info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0
    tar.addfile(info,io.BytesIO(data));manifest.append(dict(path=name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
with tarfile.open(D/'evidence.tar.gz','r:gz') as tar:
 assert tar.getnames()==[r['path'] for r in manifest]
 for row in manifest:assert hashlib.sha256(tar.extractfile(row['path']).read()).hexdigest()==row['sha256']
for name in ('report.md','test-spec.md','sources.md','verification.json','facts.json'):
 shutil.copy2(O/name,D/name)
shutil.copy2(R/'reports/v1-v2/README.md',D/'coverage-index.md')
raw=(D/'evidence.tar.gz').read_bytes();(D/'evidence-manifest.json').write_text(json.dumps(dict(archive=dict(path='evidence.tar.gz',bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()),memberCount=len(manifest),members=manifest),indent=2)+'\n')
(D/'README.md').write_text('''# Dirty-indicator investigation

Evidence only; no product implementation, installation, skill change or release.
The report separates unused document groups, duplicate automatic/explicit glyph
groups, native Redo drift and reverse-write discard semantics. A single-group
diagnostic clears the first Undo, but is not a qualified product fix.

The archive preserves every local attempt, native traces, UI proofs, fixture,
source fingerprints, the existing P09 native oracle and updated coverage index.
Every member was read back and checksum verified. Extract into a fresh directory:

```sh
mkdir dirty-evidence
tar -xzf evidence.tar.gz -C dirty-evidence
```

Open `dirty-evidence/reports/v1-v2/dirty-indicator-20260914/report.md` for working
relative evidence links. Helpers contain historical paths; use a new output and
disposable-font directory before an authorized replay. Read the test specification.
No private font source or credential is included. One inherited legacy plugin-cache
path is unavailable for final verification; current configured skills and product
files match their frozen hashes. V1 and earlier reports were not modified.
''')
print(json.dumps(dict(directory=str(D),members=len(manifest),archiveBytes=len(raw),verification=verification),indent=2))
