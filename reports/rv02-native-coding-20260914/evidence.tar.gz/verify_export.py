from pathlib import Path
import json,hashlib
import glyphsLib,uharfbuzz as hb
from fontTools.ttLib import TTFont
O=Path(__file__).resolve().parent;p=O/'tasks/T11/export/RobotoSlab-Regular.ttf';data=p.read_bytes();tt=TTFont(p);order=tt.getGlyphOrder();font=hb.Font(hb.Face(data));hb.ot_font_set_funcs(font)
def shape(text,features,language=None):
 b=hb.Buffer();b.add_str(text);b.guess_segment_properties()
 if language:b.language=language
 hb.shape(font,b,features);return [order[x.codepoint] for x in b.glyph_infos]
cases=[('g',{'ss20':0},['g'],None),('g',{'ss20':1},['g.ss01'],None),('agogo',{'ss20':1},['a','g.ss01','o','g.ss01','o'],None),('fi',{'liga':0},['f','i'],None),('fi',{'liga':1},['fi'],None),('1/4',{'frac':1},['onequarter'],None),('g',{'ss01':1},['g.ss01'],None),('abc',{'smcp':1},['a.sc','b.sc','c.sc'],None),('012',{'lnum':1},['zero.lf','one.lf','two.lf'],None),('Ş',{'locl':1},['Scommaaccent'],'ro')]
rows=[]
for text,features,expected,lang in cases:
 actual=shape(text,features,lang);rows.append(dict(text=text,features=features,language=lang,expected=expected,observed=actual,passed=expected==actual))
control='HAMBURGEFONTSIV';a=shape(control,{'ss20':0});b=shape(control,{'ss20':1});rows.append(dict(text=control,expected=a,observed=b,passed=a==b))
f=glyphsLib.GSFont(O/'font-source/RobotoSlab.glyphs');native=json.loads((O/'tasks/T10/facts-first.json').read_text())['result'];expected=[dict(name=x.name,code=x.code,automatic=bool(x.automatic),disabled=bool(x.disabled)) for x in f.features]
r=dict(ttfSHA256=hashlib.sha256(data).hexdigest(),bytes=len(data),shaper=hb.__version__,shapeCases=rows,featureFlagsAndCodeExact=expected==native['features'],features=len(expected),automatic=sum(x['automatic'] for x in expected),priorClassesExact=[dict(name=x.name,code=x.code) for x in f.classes]==native['classes'],priorPrefixesExact=[dict(name=x.name,code=x.code) for x in f.featurePrefixes]==native['prefixes'])
(O/'shaping.json').write_text(json.dumps(r,indent=2)+'\n');print({k:v for k,v in r.items() if k!='shapeCases'});assert all(x['passed'] for x in rows) and r['featureFlagsAndCodeExact'] and r['priorClassesExact'] and r['priorPrefixesExact']
