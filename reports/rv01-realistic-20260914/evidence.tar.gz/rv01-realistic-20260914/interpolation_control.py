from pathlib import Path
import sys,json,time,importlib.util,hashlib
O=Path(__file__).resolve().parent;sys.path[:0]=[str(O),str(O/'artifacts')]
from native_oracle import load,target,records,digest,value
from outline_tasks import split_o_midpoint
f=load(O/'font-source/RobotoSlab.glyphs');names=('Light','Medium','Bold');before=[];after=[]
for name in names:
 instance=next(i for i in f.instances if i.name==name);inter=value(instance,'interpolatedFont');before.append(dict(instance=name,outline=target(inter,'o')))
flags0=[bool(value(l,'temporarilyDisableRounding')) for l in f.glyphs['o'].layers];split_o_midpoint(f,[m.id for m in f.masters]);flags1=[bool(value(l,'temporarilyDisableRounding')) for l in f.glyphs['o'].layers]
for name in names:
 instance=next(i for i in f.instances if i.name==name);inter=value(instance,'interpolatedFont');after.append(dict(instance=name,outline=target(inter,'o')))
(O/'tasks/T08/native-interpolation.json').write_text(json.dumps(dict(before=before,after=after,transientFlagsRestored=flags0==flags1),indent=2))
# Verify the actual changed artifact, not an in-memory version switch.
p=O/'artifacts/Realistic Master Audit.py';s=importlib.util.spec_from_file_location('rv01_audit_revision2',p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);g=load(O/'font-source/RobotoSlab.glyphs');a=records(g);r=m.audit(g,['o','a','aacute','space'],[x.id for x in g.masters]);b=records(g)
(O/'tasks/T09/revision2-loaded.json').write_text(json.dumps(dict(artifactSHA256=hashlib.sha256(p.read_bytes()).hexdigest(),result=r,fullDataExact=digest(a['data'])==digest(b['data']),objectsExact=a['objects']==b['objects']),indent=2))
print('native interpolation and loaded revision 2 recorded')
