# Proposed next actions — not implemented

The approved documentation changes are installed and qualified. Keep the existing native bridge, document registry, selection context, seven tools, five jobs and native Undo/discard. V1 remains unchanged. Report 08 stays paused.

## 1. Remove the confirmed extra HTTP exchange

**Small patch in `build/milestone7/desktop/src/sidecar/glyphs_mcp_sidecar/server.py`:** pass `path="/mcp/"` to the existing HTTP `server.run(...)` call. The installed FastMCP 2.12.0 exposes this option and constructs its streamable HTTP route from it. This aligns the served path with the existing configured endpoint; it requires no client configuration, port change, new middleware, alias implementation or public-tool change. Preserve stateless HTTP and existing management routes. The alternate `/mcp` behavior remains the framework's normal handling and must be tested explicitly.

Evidence: every tested configured-path read issued a 307 followed by a 200, while every direct-path read issued one 200. Two counterbalanced blocks per size had lower direct-path medians. The redirect itself took medians 2.32/2.63 ms. Host-load drift prevents assigning the entire 1.56/8.66 ms aggregate median difference to this hop. It does not explain the dirty 289 ms outlier.

Implementation and validation:

1. Change only the HTTP path argument. Keep stdio behavior, interfaces, schemas, tool descriptions, source guards, errors and job/control lifecycle unchanged.
2. Extend the existing server/identity HTTP tests: initialized public client at the configured `/mcp/` sees no redirect; catalog contains exactly seven unchanged schemas; representative read/error responses are unchanged; protocol negotiation and streaming work. Inspect actual HTTP response history with redirect following disabled so an automatic redirect cannot hide a failure.
3. Exercise `/mcp` explicitly and document its native framework response. Check `/internal/control` still uses its existing authorization/lifecycle rules. Add no earlier-private workflow.
4. Build twice, compare deterministic payloads, install through the existing transactional installer, and verify fresh manifest/receipt/runtime fingerprints. Expect a sidecar hash change; bridge bytes remain unchanged. All ten configured skills must still match; no skill migration is needed for this route correction.
5. Repeat first/warm-up/five fresh-copy 12/100-pair tasks using public discovery, retained IDs and two open fonts. Record initial discovery plus defined five-read totals; compare before/candidate under comparable recorded load. Verify exact values, dirty/stale-ID/error controls, source/native-object preservation and cleanup. Keep request/native timing separate. Require one HTTP request per tool call on the configured endpoint, no response regressions and no native responsiveness regression.
6. Add two counterbalanced 30-sample blocks per size for HTTP proxy comparison, retaining outliers and load. Do not promise that all HTTP p95 becomes <50 ms. Native acceptance remains p95 <50 ms and maximum <200 ms. Report token payloads unchanged unless measurement contradicts that expectation.

This patch is a separate reviewable improvement. It was **not applied** during the current investigation.

## 2. Isolate the larger non-native tail if it recurs

Retain the callback, dispatch and bridge client functions. The final dirty outlier spends only 13.47 ms in native dispatch/callback, leaving 276.02 ms elsewhere. Current stage samples do not attribute that exact request further.

If the route candidate still shows this tail, use the corrected bounded harness with stable load and concurrent client/ASGI/service/bridge spans on the same serial requests. Buffer samples and flush explicitly outside the measured window; verify trace completeness before terminating the temporary process. Record existing access-log I/O. Correlate by test-owned request order and document IDs outside the public schema. Do not add caches, polling services, threads or fairness-yield changes before a bottleneck is reproducible in at least two blocks. Stop at 1,500 measured reads or 15 minutes of sampling and report unavailable evidence rather than extending indefinitely.

## 3. Retain the host crash as a separate reliability issue

The crash after Report A is not explained by the unchanged bridge or new documentation. Preserve the original crash file and timing. Before declaring the overall workflow smooth, run a bounded native disposable-font control: open/read/close, then observe at least 120 seconds of idle time using one-shot checks, with matching open/close-only controls. Record whether UI/accessibility inspection is attempted during that interval and any crash report. Keep test helper state and companion presence explicit; change one condition at a time only if the failure reproduces. Never use user fonts or a custom recovery system. A host-stack failure alone is insufficient to choose a bridge fix.

The three dirty preservation failures need no Undo implementation change: they captured natural groupingLevel 1→0. The successful control required native groupingLevel 0 after an 8-second poll-off settling interval, then preserved exact state. Preserve all earlier failed windows and disclose the resulting 8.38-second mutation-to-first-read gap.
