from pathlib import Path
import sys,json,time,traceback
O=Path(__file__).resolve().parent;sys.path[:0]=[str(O),str(O/'artifacts')]
from native_oracle import load,records,digest
from feature_tasks import create_ss20
from GlyphsApp import TT,PLAIN,Glyphs
D=O/'tasks/T11/export';D.mkdir(exist_ok=True,parents=True)
f=load(O/'font-source/RobotoSlab.glyphs');before=records(f);feature=create_ss20(f)
r=dict(host=str(Glyphs.versionNumber),build=str(Glyphs.buildNumber),instances=[x.name for x in f.instances],at=time.time())
try:
 r['compile']=str(f.compileFeatures());instance=next(x for x in f.instances if x.name=='Regular');t=time.perf_counter();r['export']=str(instance.generate(FontPath=str(D),Format=TT,AutoHint=False,RemoveOverlap=False,UseProductionNames=False,Containers=[PLAIN]));r['nativeExportMs']=(time.perf_counter()-t)*1000
 r['outputs']=[str(p) for p in D.iterdir() if p.is_file()]
except Exception:r['error']=traceback.format_exc()
r['sourceAfterSHA256']=digest(records(f)['data']);(O/'tasks/T11/export-first.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
