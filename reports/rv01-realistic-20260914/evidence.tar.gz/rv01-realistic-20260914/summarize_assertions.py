from pathlib import Path
import json,copy,hashlib
O=Path(__file__).resolve().parent

def get(s):return json.loads((O/s).read_text())
def sha(x):return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':'),default=str).encode()).hexdigest()
def check(name,expected,observed):
 return dict(name=name,status='passed' if expected==observed else 'failed',expected=expected if len(str(expected))<160 else {'sha256':sha(expected)},observed=observed if len(str(observed))<160 else {'sha256':sha(observed)})
results={}
b=get('tasks/T01/native-before.json');r=get('tasks/T01/responses.json');checks=[]
for row in r['layers']['data']:
 e=row['entity'];v=row['values'];l=next(x for x in b['data']['layers'] if x['glyph']==e['glyph'] and x['layer']==e['id']);checks += [check(e['glyph']+' '+e['id']+' exact ID',l['layer'],v['id']),check(e['glyph']+' '+e['id']+' width',l['width'],v['width']),check(e['glyph']+' '+e['id']+' bounds',l['bounds'],[v['bounds'][k] for k in ('x','y','width','height')])]
v=r['selection']['data'][0]['values'];expected=[dict(x=x['x'],y=x['y'],type=x['type'],smooth=x['smooth'],pathIndex=x['path'],nodeIndex=x['node']) for x in b['selected']];checks.append(check('exact on/off-curve selection',expected,v['nodes']['items']));checks.append(check('complete selection',True,v['nodes']['complete']))
v=get('tasks/T01/bounded.json')['data'][0]['values']['nodes'];checks.append(check('bounded evidence counts/completeness',[3,1,1,False],[v[k] for k in ('total','returned','limit','complete')]))
v=get('tasks/T01/empty.json')['data'][0]['values']['nodes'];checks.append(check('empty active selection',[0,0,True],[v[k] for k in ('total','returned','complete')]))
checks.append(check('stale ID rejected','document_not_found',get('tasks/T01/stale-id.json')['error']['code']));checks.append(dict(name='missing named glyph control',status='unverified',expected="glyph rv01.missing not found",observed="Agent supplied name instead of id; server reported glyph ''. No replacement font/discovery followed."));results['T01']=checks
b=get('tasks/T02/native-before.json');a=get('tasks/T02/native-after.json');expected=copy.deepcopy(b['data'])
for l in expected['layers']:
 if l['glyph']=='o':l['width']+=12.375
checks=[check('exact width delta and every other recorded property',expected,a['data']),check('native object identities',b['objects'],a['objects']),check('hint references',b['hintReferences'],a['hintReferences'])]
for phase in ('undo','discard'):
 x=get('tasks/T02/native-'+phase+'.json');checks.extend([check(phase+' exact data',b['data'],x['data']),check(phase+' exact native objects',b['objects'],x['objects'])])
x=get('tasks/T02/native-redo.json');checks.extend([check('Redo exact result',a['data'],x['data']),check('first Undo clears Edited',False,get('tasks/T02/native-undo.json')['dirty'])]);results['T02']=checks
b=get('tasks/T03/native-before.json');a=get('tasks/T03/native-after.json');expected=copy.deepcopy(b['data']);orig=get('inventory-native.json')['rows'];checks=[]
for l in expected['layers']:
 if l['glyph']!='o':continue
 before=next(t for t in b['target']['layers'] if t['id']==l['layer']);after=next(t for t in a['target']['layers'] if t['id']==l['layer'])
 for pi,s in enumerate(l['shapes']):
  if s['kind']!='path':continue
  ids=[n['id'] for n in before['paths'][pi]['nodes']];newids=[n['id'] for n in after['paths'][pi]['nodes']];s['nodes']=[s['nodes'][ids.index(k)] for k in newids]
 current=next(x for x in a['data']['layers'] if x['glyph']=='o' and x['layer']==l['layer']);reference=next(x for x in orig if x['glyph']=='o' and x['master']==l['layer']);checks.append(check('restored original contour '+l['layer'],[[[n['x'],n['y'],n['type'],n['smooth']] for n in p['nodes']] for p in reference['paths']],[[[*n['position'],n['type'],n['smooth']] for n in p['nodes']] for p in current['shapes']]))
checks.extend([check('only native node permutations changed',expected,a['data']),check('all native objects retained',sorted(b['objects']),sorted(a['objects'])),check('native compatibility restored',True,a['target']['compatible'])]);d=get('tasks/T03/native-discard.json');checks.extend([check('discard exact recorded data',b['data'],d['data']),check('discard exact object order',b['objects'],d['objects'])]);results['T03']=checks
collateral={x['task']:x for x in get('target-collateral.json')}
for i in range(4,13):
 tid=f'T{i:02}';p=f'tasks/{tid}/facts-corrected.json';p=p if (O/p).exists() else f'tasks/{tid}/facts-first.json';r=get(p);checks=r['assertions'][:];checks.append(check('all unrelated recorded data',True,r['preservation']['unrelatedDataExact']))
 if tid in collateral:
  for k in ('layerCollateralExact','gridExact','survivingNodeMetadataExact'):checks.append(check(k,True,collateral[tid][k]))
 results[tid]=checks
results['T05'].append(check('all inserted coordinates exact midpoints',True,all(x['exactMidpoint'] for x in get('geometry.json')['T05'])))
results['T06'].append(check('nonredundant point rejected without edits','passed',get('tasks/T06-negative/facts-corrected.json')['status']))
results['T07'].append(check('all six contour split bounds below .05',True,all(p['passed'] for x in get('tasks/T07/geometry-certificate.json')['precision-control'] for p in x['paths'])))
results['T08'].append(check('three original cubics preserved within 1e-9',True,all(x['passed'] for x in get('geometry.json')['T08'])));results['T08'].append(check('three native interpolated instances preserved within 1e-9',True,all(x['polynomialError']<=1e-9 for x in get('geometry.json')['nativeInterpolations'])))
r=get('tasks/T09/revision2-loaded.json');results['T09'].append(check('actual revised file loaded',2,r['result']['revision']));results['T09'].append(check('actual revision read-only',True,r['fullDataExact'] and r['objectsExact']))
results['T10'].append(check('independent source feature flags/code',True,get('tasks/T10/source-cross-check.json')['exact']));results['T10'].append(check('seven existing OpenType behavior cases',True,all(x['passed'] for x in get('tasks/T10/existing-feature-shaping.json'))));results['T10'].append(dict(name='configured focused feature skill',status='blocked',expected='Applicable lean-v2 instructions',observed='Retired get_server_info/apiMajor=2/read_document/preview_change/execute_python tools; installed skill is absent from current lean package'))
results['T11'].append(check('actual exported GSUB shaping',True,get('tasks/T11/shaping.json')['passed']))
r=get('tasks/T12/facts-first.json')['result'];results['T12'].append(check('compiler rejects bad reference with location',True,'False' in r['invalidCompile'][0]['returnValue'] and 'Unknown glyph' in r['invalidCompile'][0]['returnValue'] and 'line 1' in r['invalidCompile'][0]['returnValue']));results['T12'].append(check('corrected native compile','(True, None)',r['correctedCompileReturn']))
allchecks=[x for rows in results.values() for x in rows];counts={s:sum(x['status']==s for x in allchecks) for s in ('passed','failed','blocked','unverified')}
for tid,checks in results.items():(O/f'tasks/{tid}/assertions-final.json').write_text(json.dumps(checks,indent=2))
(O/'assertion-index.json').write_text(json.dumps(dict(counts=counts,tasks=results),indent=2));print(counts)
