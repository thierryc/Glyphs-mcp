from pathlib import Path
import sys,json,time,shutil,re,traceback
O=Path(__file__).resolve().parent;sys.path[:0]=[str(O),str(O/'artifacts')]
from native_oracle import *
from outline_tasks import PRECISION_RECIPE
from feature_tasks import create_ss20
from GlyphsApp import Glyphs
S=O.parents[2]/'build/milestone7/desktop'
path=O/'precision-failure.glyphs';shutil.copy(O/'font-source/RobotoSlab.glyphs',path);f=load(path);mids=[m.id for m in f.masters];layers=[f.glyphs['o'].layers[m] for m in mids];layers[1].setTemporarilyDisableRounding_(True)
before=records(f);flags=[bool(value(l,'temporarilyDisableRounding')) for l in layers];caught=None
try:
 exec(PRECISION_RECIPE,dict(target_layers=layers,perform_requested_operation=lambda _: (_ for _ in ()).throw(ValueError('RV02 intentional failure')),verify_exact_requested_values=lambda _:None))
except ValueError as e:caught=str(e)
after=records(f);(O/'precision-failure.json').write_text(json.dumps(dict(caught=caught,beforeFlags=flags,afterFlags=[bool(value(l,'temporarilyDisableRounding')) for l in layers],dataExact=before['data']==after['data'],objectsExact=before['objects']==after['objects']),indent=2))
path=O/'export-source.glyphs';shutil.copy(O/'font-source/RobotoSlab.glyphs',path);f=load(path);before=records(f);feature=create_ss20(f)
notes=(S/'skills/glyphs-mcp-development/references/glyphs4-api-notes.md').read_text();blocks=re.findall(r'```python\n(.*?)```',notes,re.S)
exec(blocks[2],dict(font=f));exec(blocks[1],globals()|dict(feature=feature))
D=O/'tasks/T11/export';D.mkdir(parents=True,exist_ok=False);instance=next(i for i in f.instances if i.name=='Regular');env=dict(instance=instance,output_directory=D);start=time.perf_counter();exec(blocks[0],env);elapsed=(time.perf_counter()-start)*1000
r=dict(host=str(Glyphs.versionNumber),build=str(Glyphs.buildNumber),nativeExportMs=elapsed,exportReturn=repr(env['result']),outputs=[str(p) for p in D.iterdir()],priorFeaturesExact=before['data']['features']['features']==records(f)['data']['features']['features'][:-1]);(O/'export.json').write_text(json.dumps(r,indent=2))
print('Native precision failure and qualified API examples completed')
