"""Derive evidence tables without treating dirty state as a data comparison."""
import hashlib,json,statistics
from pathlib import Path
O=Path(__file__).resolve().parent
def load(name):return json.loads((O/name).read_text())
def dif(a,b,path=''):
 if isinstance(a,dict) and isinstance(b,dict):return sum((dif(a.get(k),b.get(k),path+'/'+k) for k in sorted(a.keys()|b.keys())),[])
 if isinstance(a,list) and isinstance(b,list):
  if len(a)!=len(b):return [dict(path=path,before=a,after=b)]
  return sum((dif(x,y,path+'/'+str(i)) for i,(x,y) in enumerate(zip(a,b))),[])
 return [] if a==b else [dict(path=path,before=a,after=b)]
def compare(a,b):return {k:dif(a[k],b[k]) for k in ('data','objects','hintReferences','bounds')}
def compact(p):
 s=p['state'];return dict(dirty=s['dirty'],hasUnautosavedChanges=s['hasUnautosavedChanges'],glyphCounts=[g['changeCount'] for g in s['glyphs']],glyphGroupLevels=[(g['undo'] or {}).get('groupingLevel') for g in s['glyphs']],documentCanUndo=(s['documentUndo'] or {}).get('canUndo'),widths=[g['widths'] for g in s['glyphs']])
facts=dict(primary=[],controls=[],isolated=[],limitations=['Native UI edits change glyph lastChange; timestamps are retained in the comparisons.','Isolated manager invocations are not public-agent workflow or native UI evidence.','No plugin-free GUI reproduction or alternate Glyphs 4 build was tested.','No native callback timing or performance benchmark was run.'])
for label,phases in [('ui2',['edited','undo-immediate','undo-settled','redo','final-undo']),('ui3',['edited','edited-settled','undo','redo','final-undo','final-settled']),('v2a',['applied','undo','redo','final-undo','final-settled']),('v2b',['applied','undo','redo','final-undo','final-settled']),('discard',['applied','restored'])]:
 before=load(label+'-baseline.json');row=dict(label=label,baseline=compact(before),phases=[])
 for phase in phases:
  after=load(label+'-'+phase+'.json');row['phases'].append(dict(phase=phase,state=compact(after),differences=compare(before,after)))
 facts['primary'].append(row)
for a,b in [('unrelated-native-edited','unrelated-after-discard'),('unrelated-baseline','unrelated-after-discard'),('unrelated-baseline','unrelated-ui-undo'),('initially-dirty-before-job','initially-dirty-after-refusal')]:
 before=load(a+'.json');after=load(b+'.json');facts['controls'].append(dict(before=a,after=b,state=compact(after),differences=compare(before,after)))
for name in ('isolated-bookkeeping-primary-probes.json','isolated-bookkeeping.json'):
 for row in load(name)['cases']:
  assert not row.get('error'),row.get('error')
  final=row['final'];facts['isolated'].append(dict(source=name,case=row['case'],states={k:compact(row[k]) for k in ('baseline','edited','undone','redone','final') if k in row},finalDifferences=compare(row['baseline'],final)))
timeline=load('native-timeline.json');facts['timeline']=dict(samples=len(timeline['samples']),watches=len(timeline['watches']),countsByLabel={})
for label in sorted({s['label'] for s in timeline['samples']}):
 ss=[x['state'] for x in timeline['samples'] if x['label']==label]
 facts['timeline']['countsByLabel'][label]=dict(samples=len(ss),observedSeconds=ss[-1]['monotonic']-ss[0]['monotonic'],dirtyValues=sorted({s['dirty'] for s in ss}),unautosavedValues=sorted({s['hasUnautosavedChanges'] for s in ss}))
facts['fixture']=load('fixture-determinism.json');facts['cleanup']=load('primary-cleanup.json')
facts['copies']=[dict(path=c['path'],unchanged=hashlib.sha256(Path(c['path']).read_bytes()).hexdigest()==c['sha256']) for c in facts['cleanup']['copies']]
for name in ('isolated-bookkeeping-first.json','isolated-bookkeeping-primary-probes.json','isolated-bookkeeping.json'):
 for c in load(name)['cases']:
  facts['copies'].append(dict(path=c['path'],unchanged=hashlib.sha256(Path(c['path']).read_bytes()).hexdigest()==facts['fixture']['sha256']))
assert all(c['unchanged'] for c in facts['copies'])
assert facts['fixture']['equal'] and facts['cleanup']['originalsExact']
assert all(not d for label in ('v2a','v2b') for phase in ('undo','final-undo','final-settled') for d in compare(load(label+'-baseline.json'),load(label+'-'+phase+'.json')).values())
assert all(not d for d in compare(load('discard-baseline.json'),load('discard-restored.json')).values())
assert all(not d for d in compare(load('initially-dirty-before-job.json'),load('initially-dirty-after-refusal.json')).values())
(O/'facts.json').write_text(json.dumps(facts,indent=2)+'\n')
print(json.dumps(dict(primaryCases=len(facts['primary']),isolatedCases=len(facts['isolated']),copiesUnchanged=len(facts['copies']),timeline=facts['timeline']),indent=2))
