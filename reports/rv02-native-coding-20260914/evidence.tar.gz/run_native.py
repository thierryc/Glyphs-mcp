from pathlib import Path
import json,time,sys,traceback,importlib.util,copy,os,shutil
from GlyphsApp import Glyphs,OFFCURVE,GSNode,LINE
O=Path(__file__).resolve().parent;sys.path[:0]=[str(O),str(O/'artifacts')]
from native_oracle import *
import outline_tasks as edits,feature_tasks as features
SRC=O/'font-source/RobotoSlab.glyphs'
OUT=O/'tasks';ALL=[]
def write(p,v):p.write_text(json.dumps(v,indent=2,default=str)+'\n')
def run(tid,name,action,verify,target_name=None,seed=None):
 d=OUT/tid;d.mkdir(exist_ok=True,parents=True);copy_path=d/"source.glyphs";shutil.copy(SRC,copy_path);f=load(copy_path);mids=[m.id for m in f.masters];seed_result=seed(f,mids) if seed else None
 before=records(f);rounding_before=[bool(value(f.glyphs[target_name].layers[mid],'temporarilyDisableRounding')) for mid in mids] if target_name else [];view=target(f,target_name) if target_name else None;start=time.perf_counter();row=dict(id=tid,name=name,route='authored-native-script / isolated Glyphs 4 CLI',at=time.time(),masterIds=mids,seed=seed_result,host=str(Glyphs.versionNumber),build=str(Glyphs.buildNumber),assertions=[])
 try:
  t=time.perf_counter();result=action(f,mids);row['nativeActionMs']=(time.perf_counter()-t)*1000;row['result']=result
  after=records(f);row['preservation']=compare(before,after,target_name,tid in ('T11','T12'))
  row['assertions']=verify(f,mids,before,after,result)
  if target_name:
   row['assertions'].append(assertion('rounding flags restored',rounding_before,[bool(value(f.glyphs[target_name].layers[mid],'temporarilyDisableRounding')) for mid in mids]))
   write(d/'records.json',dict(before=before,after=after))
  row['status']='passed' if all(a['status']=='passed' for a in row['assertions']) and row['preservation']['unrelatedDataExact'] else 'failed'
  if target_name:write(d/'native-outlines.json',dict(before=view,after=target(f,target_name)))
 except Exception:
  row['status']='failed';row['error']=traceback.format_exc();row['preservationAfterFailure']=compare(before,records(f),target_name,tid in ('T11','T12'))
 row['taskHarnessMs']=(time.perf_counter()-start)*1000;write(d/'facts-first.json',row);ALL.append(row);write(O/'native-summary.json',ALL);print(tid,row['status'],flush=True)

def target_rows(s,name):return [l for l in s['data']['layers'] if l['glyph']==name]
def checks_handle(f,m,a,b,result):
 A=copy.deepcopy(a['data']);B=b['data']
 for l in A['layers']:
  if l['glyph']=='o' and l['master'] in m and l['layer'] in m:
   idx=next(i for i,n in enumerate(l['shapes'][0]['nodes']) if n['type']=='offcurve');l['shapes'][0]['nodes'][idx]['position'][0]+=2.5
   # Bounds are derived, excluded from coordinate preservation comparison.
 for l in A['layers']:l.pop('bounds')
 C=copy.deepcopy(B)
 for l in C['layers']:l.pop('bounds')
 return [assertion('exact requested handle changes only',A,C),assertion('existing object order exact',a['objects'],b['objects']),assertion('master compatibility retained',True,bool(f.glyphs['o'].mastersCompatible))]
# Large expected/observed values get reduced to hashes when writing after comparison.
def compact_checks(fn):
 def wrapped(*args):
  rows=fn(*args)
  for r in rows:
   for k in ('expected','observed'):
    if len(str(r[k]))>300:r[k]=dict(sha256=digest(r[k]))
  return rows
 return wrapped
run('T04','Adjust an o handle',edits.adjust_handle,compact_checks(checks_handle),'o')
def checks_add(f,m,a,b,r):
 A=copy.deepcopy(a['data']);B=copy.deepcopy(b['data'])
 for l in B['layers']:
  if l['glyph']=='H' and l['layer'] in m:del l['shapes'][0]['nodes'][1]
 return [assertion('remove inserted midpoint recovers exact original data',digest(A),digest(B)),assertion('nodes added',3,len(set(b['objects'])-set(a['objects']))),assertion('all master topology compatible',True,bool(f.glyphs['H'].mastersCompatible))]
run('T05','Add exact collinear H midpoints',edits.add_stem_midpoint,checks_add,'H')
def checks_remove(f,m,a,b,r):
 A=copy.deepcopy(a['data']);B=b['data']
 for l in A['layers']:
  if l['glyph']=='H' and l['layer'] in m:del l['shapes'][0]['nodes'][1]
 return [assertion('only seeded midpoint removed',digest(A),digest(B)),assertion('removed nodes',3,len(set(a['objects'])-set(b['objects']))),assertion('master compatibility',True,bool(f.glyphs['H'].mastersCompatible))]
run('T06','Remove seeded redundant H midpoints',edits.remove_stem_midpoint,checks_remove,'H',edits.add_stem_midpoint)
def seed_invalid(f,m):
 edits.add_stem_midpoint(f,m);n=f.glyphs['H'].layers[m[-1]].paths[0].nodes[1];old=bool(value(f.glyphs['H'].layers[m[-1]],'temporarilyDisableRounding'));f.glyphs['H'].layers[m[-1]].setTemporarilyDisableRounding_(True);n.position=(n.position.x+.125,n.position.y);f.glyphs['H'].layers[m[-1]].setTemporarilyDisableRounding_(old)
def reject_remove(f,m):
 try:edits.remove_stem_midpoint(f,m)
 except ValueError as e:return dict(rejected=True,message=str(e))
 return dict(rejected=False)
run('T06-negative','Reject removal of a nonredundant point',reject_remove,lambda f,m,a,b,r:[assertion('explicit rejection',True,r['rejected']),assertion('zero partial mutation',digest(a['data']),digest(b['data']))],'H',seed_invalid)
def extrema_checks(f,m,a,b,r):
 aa=target_rows(a,'at');bb=target_rows(b,'at')
 return [assertion('at widths retained',[l['width'] for l in aa],[l['width'] for l in bb]),assertion('native master compatibility retained',True,bool(f.glyphs['at'].mastersCompatible))]
run('T07','Native at extrema',edits.add_extrema,extrema_checks,'at')
run('T08','Corresponding cubic midpoint on o',edits.split_o_midpoint,lambda f,m,a,b,r:[assertion('nodes added',9,len(set(b['objects'])-set(a['objects']))),assertion('existing nodes retained',0,len(set(a['objects'])-set(b['objects']))),assertion('native compatibility',True,bool(f.glyphs['o'].mastersCompatible)),assertion('widths exact',[l['width'] for l in target_rows(a,'o')],[l['width'] for l in target_rows(b,'o')])],'o')
run('T10','Native OpenType review control',lambda f,m:features.review(f),lambda f,m,a,b,r:[assertion('read-only full data',digest(a['data']),digest(b['data'])),assertion('feature count',17,len(r['features']))])

def add_feature(f,m):
 feature=features.create_ss20(f);r=f.compileFeatures();assert isinstance(r,tuple) and len(r)==2 and r[0] is True,repr(r);return dict(code=feature.code,compileReturn=str(r),compileReturnType=type(r).__name__,feature=features.review(f)['features'][-1])
run('T11','Create native ss20 control',add_feature,lambda f,m,a,b,r:[assertion('exact new code','sub g by g.ss01;',r['code']),assertion('prior features unchanged',a['data']['features']['features'],b['data']['features']['features'][:-1]),assertion('new feature active',False,r['feature']['disabled'])])

def bad_feature(f,m):
 feature=features.create_ss20(f,invalid=True);errors=[]
 try:r=f.compileFeatures();assert isinstance(r,tuple) and len(r)==2 and r[0] is False,repr(r);errors.append(dict(returnValue=str(r),returnType=type(r).__name__))
 except Exception as e:errors.append(dict(exception=type(e).__name__,message=str(e)))
 feature.code='sub g by g.ss01;';r=f.compileFeatures();assert isinstance(r,tuple) and len(r)==2 and r[0] is True,repr(r)
 return dict(invalidCompile=errors,corrected=feature.code,correctedCompileReturn=str(r))
run('T12','Diagnose invalid feature then correct',bad_feature,lambda f,m,a,b,r:[assertion('corrected code','sub g by g.ss01;',r['corrected']),assertion('prior feature source preserved',digest(a['data']['features']['features']),digest(b['data']['features']['features'][:-1]))])
write(O/'native-session.json',dict(ok=True,host=str(Glyphs.versionNumber),build=str(Glyphs.buildNumber),tasks=len(ALL),note='Independent detached loads; GUI bridge not invoked by these tasks. Runtime snapshot hashes include metadata and native object identities separately.'))
