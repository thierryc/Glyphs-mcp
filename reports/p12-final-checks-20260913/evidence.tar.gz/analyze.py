from pathlib import Path
import json,hashlib,os,sys,math,statistics,copy
from collections import Counter
from datetime import datetime,timezone
from workflow import same,slanted
O=Path(__file__).resolve().parent;P=O.parent
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def stats(v):
 v=sorted(v);return dict(n=len(v),median=statistics.median(v),min=min(v),max=max(v),p95=v[math.ceil(.95*len(v))-1]) if v else dict(n=0)
sys.path.insert(0,'/private/tmp/glyphs-metadata-tokenizer-20260910');os.environ['TIKTOKEN_CACHE_DIR']='/private/tmp/glyphs-metadata-tokenizer-cache'
import tiktoken
enc=tiktoken.get_encoding('o200k_base')
def tokens(d):return len(enc.encode(json.dumps(d,sort_keys=True,separators=(',',':'),ensure_ascii=False)))
f=read(O/'freeze.json');preservation={}
def digest(x):return 'link:'+os.readlink(x) if x.is_symlink() else sha(x) if x.is_file() else None
for label,root,entries in [('previous-p12',P,f['priorReports'])]+[(k,Path(f['roots'][k]),v) for k,v in f['hashes'].items()]:
 preservation[label]=dict(files=len(entries),differences=[n for n,h in entries.items() if digest(root/n)!=h])
finish=read(O/'v2/native-finish.json');preservation['copies']=dict(count=len(finish['copies']),differences=[r['path'] for r in finish['copies'] if sha(Path(r['path']))!=r['sha256']]);preservation['originalControl']=sha(Path(f['originalFont']))==f['originalFontHash']
ui=read(O/'v2/ui-slant01.json');history={k:v for k,v in ui.items() if k.endswith('Differences')};history['dirty']={k:ui[k]['target']['dirty'] for k in ['before','applied','undo','redo','discard']}
bounds=read(O/'v2/component-bounds.json');dependent={k:v for k,v in bounds.items() if k not in ['before','applied','discard']};dependent['applicationDifferences']=slanted(bounds['before'],bounds['applied'],['slant00']);dependent['locations']=[{k:bounds['before']['target']['data']['layers'][i][k] for k in ['glyph','layer']} for i in [4,5,12,13]]
d=read(O/'v2/profile.json');profile=dict(callbackMs=stats([x['callbackMs'] for x in d['samples'] if 'dispatchWaitMs' in x]),dispatchWaitMs=stats([x['dispatchWaitMs'] for x in d['samples'] if 'dispatchWaitMs' in x]),nativeChunkMs=stats([x['callbackMs'] for x in d['samples'] if x.get('kind')=='native-edit-chunk']),queueLagMs=stats(d['mainQueueLagsMs']),load=d['load'],afterLoad=d['afterLoad'],postMutationSeconds=d['postMutationSeconds'],overhead={k:stats(v) for k,v in read(O/'v2/probe-overhead.json').items()},accuracy=read(O/'v2/profile-accuracy.json'))
profile['budgetsPass']={k:v['p95']<50 and v['max']<200 for k,v in profile.items() if k in ['callbackMs','nativeChunkMs','queueLagMs']}
calls=[json.loads(l) for l in (O/'v2/calls.jsonl').read_text().splitlines()];reports=[read(x) for x in (O/'v2').glob('*-report.json')]
crashes=[str(x) for x in (Path.home()/'Library/Logs/DiagnosticReports').glob('Glyphs*') if x.is_file() and str(x) not in f['crashes']]
r=dict(at=datetime.now(timezone.utc).isoformat(),sourceCommit=f['sourceCommit'],pid=f['pid'],autosavingDelay=finish['autosavingDelay'],countLimit=read(O/'v2/count-limit.json'),cubicHistory=history,dependentBounds=dependent,profile=profile,publicCalls=dict(n=len(calls),byTool=dict(Counter(x['name'] for x in calls)),latencyMs=stats([x['ms'] for x in calls]),transportErrors=[x for x in calls if 'transportException' in x['result']],retries=0),tokenMethod=dict(tokenizer=tiktoken.__version__,encoding='o200k_base',serialization='compact sorted literal-Unicode requests plus parsed results; each report once',aggregateTokens=sum(tokens(dict(name=x['name'],arguments=x['arguments']))+tokens(x['result']) for x in calls)+sum(tokens(x) for x in reports),reportCount=len(reports),actualBilledUsage='unavailable'),preservation=preservation,nativeFinish=finish,newCrashes=crashes,cleanup=read(O/'script-cleanup.json'),remainingIssues=['Known stale dependent bounds until affected master viewed','Native Undo/discard dirty flag remains true','Recurring historical autosave-associated crash root cause unresolved'])
if (O/'final-observation.json').exists():r['observation']=read(O/'final-observation.json')
assert r['countLimit']['passed'];assert all(not history[k] for k in history if k.endswith('Differences'));assert not dependent['storedRestorationDifferences'] and not dependent['applicationDifferences'];assert all(not x['storedDifferences'] for x in dependent['redraw']);assert not profile['accuracy']['applicationDifferences'] and not profile['accuracy']['restorationDifferences'];assert all(profile['budgetsPass'].values());assert all(not v.get('differences') for v in preservation.values() if isinstance(v,dict));assert preservation['originalControl'] and finish['autosavingDelay']==8
(O/'facts.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:r[k] for k in ['cubicHistory','profile','publicCalls','tokenMethod','newCrashes']},indent=2));print('Preservation',[(k,v.get('files',v.get('count')),len(v.get('differences',[]))) for k,v in preservation.items() if isinstance(v,dict)])
