"""Independent read-only evidence; never completes an authored task."""
import ast,hashlib,json,objc
from pathlib import Path
from GlyphsApp import GSPath,CURVE,OFFCURVE
from Foundation import NSURL
from GlyphsApp import GSFont
R=Path('/Users/thierryc/Dev/github/thierryc/Glyphs-mcp-worktrees/v2')
for n in ast.parse((R/'reports/v1-v2/09-spacing/NativeQualification.py').read_text()).body:
 if isinstance(n,ast.FunctionDef) and n.name in ('ident','point','userdata','snapshot'):
  exec(compile(ast.unparse(n).replace('f.parent.undoManager()', 'f.parent.undoManagerCheck()'),'recorded-native-oracle','exec'))
def value(obj,name):
 v=getattr(obj,name);return v() if callable(v) else v

def digest(v):return hashlib.sha256(json.dumps(v,sort_keys=True,default=str,separators=(',',':')).encode()).hexdigest()
def load(p):
 r=GSFont.alloc().initWithURL_error_(NSURL.fileURLWithPath_(str(p)),None);f=r[0] if isinstance(r,tuple) else r;assert f;return f

def records(f):
 s=snapshot(f)
 features={name:[dict(name=x.name,code=x.code,automatic=bool(value(x,'automatic')),disabled=bool(value(x,'disabled')) if hasattr(x,'disabled') else None) for x in getattr(f,name)] for name in ('features','classes','featurePrefixes')}
 s['data']['features']=features
 return s

def compare(a,b,target=None,changed_features=False):
 A=a['data'];B=b['data'];keys=[k for k in A if k!='layers' and not(changed_features and k=='features')]
 aa=[r for r in A['layers'] if r['glyph']!=target];bb=[r for r in B['layers'] if r['glyph']!=target]
 return dict(unrelatedDataExact=all(A[k]==B[k] for k in keys) and aa==bb,fullDataExact=A==B,objectSetPreserved=set(a['objects'])<=set(b['objects']),removedObjects=len(set(a['objects'])-set(b['objects'])),addedObjects=len(set(b['objects'])-set(a['objects'])),hintReferencesExact=a['hintReferences']==b['hintReferences'],beforeSHA256=digest(A),afterSHA256=digest(B))

def target(f,name):
 g=f.glyphs[name]
 return dict(glyph=name,compatible=bool(value(g,'mastersCompatible')),layers=[dict(id=l.layerId,master=l.associatedMasterId,width=l.width,compare=l.compareString(),paths=[dict(closed=bool(p.closed),nodes=[dict(x=n.position.x,y=n.position.y,type=str(n.type),smooth=bool(n.smooth),id=ident(n)) for n in p.nodes]) for p in l.paths]) for l in g.layers if l.isMasterLayer])

def assertion(name,expected,observed):return dict(name=name,expected=expected,observed=observed,status='passed' if expected==observed else 'failed')
