from pathlib import Path
import json,shutil,tarfile,gzip,hashlib,time,re
O=Path(__file__).resolve().parent;R=O.parents[2];S=R/'build/milestone7/desktop';D=S/'reports/rv02-native-coding-20260914';D.mkdir(exist_ok=False)
index=R/'reports/v1-v2/README.md';note='> **RV02 native-coding follow-up — September 14, 2026:** [Implemented and installed skills](../v2-realistic/rv02-20260914/report.md). Current OpenType routing, native precision and qualified API notes pass 150 checks; populated-hint coverage remains unverified. The corrected glyph selector and stale-ID controls pass. Eleven configured skill identities match the tested payload; bridge/sidecar and seven tools remain unchanged. RV01’s pending UI cleanup is now complete. Earlier reports remain historical; no fresh v1 benchmark or latency improvement is claimed.\n\n';index.write_text(note+index.read_text());shutil.copy(index,D/'coverage-index.md')
copy_names=['report.md','judgment.md','action-log.md','assertions.json','measurements.json','installation.json','installation.log','backup-evidence.json','runtime-before.json','runtime-after-install.json','runtime-final.json','catalog.json','handshake.json','calls.jsonl','selector-results.json','metadata-oracle.json','stale-id.json','native-summary.json','precision-failure.json','export.json','shaping.json','geometry.json','target-collateral.json','installed-native-smoke.json','offline-validation.json','source-preservation.json','rv02-only.patch','python-tests-first.log','python-tests.log','package-tests-final.log','swift-tests-first.log','swift-tests-corrected.log','swift-tests-final.log','build-candidate.log','gui-final.txt','scripts-final.txt','InstallSkills.swift']
for name in copy_names:shutil.copy(O/name,D/name)
for name in ('artifacts','visuals','font-source'):
 if name=='font-source':
  (D/name).mkdir()
  for f in ['LICENSE.txt','SOURCE.json']:shutil.copy(O/name/f,D/name/f)
 else:shutil.copytree(O/name,D/name,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
for p in (O/'tasks').rglob('*.json'):
 if p.name=='records.json':continue
 q=D/p.relative_to(O);q.parent.mkdir(parents=True,exist_ok=True);shutil.copy(p,q)
# Raw source and native proofs are local, self-contained archived evidence;
# omit unrelated preexisting code diffs and unchanged official corpus copies.
files=[]
for p in sorted(O.rglob('*')):
 if not p.is_file() or '__pycache__' in p.parts:continue
 rel=p.relative_to(O)
 if rel.name in ('preexisting.diff',):continue
 if rel.parts[0]=='installed-before' and 'assets' in rel.parts:continue
 files.append(p)
archive=D/'evidence.tar.gz';members=[]
with archive.open('wb') as target:
 with gzip.GzipFile(fileobj=target,mode='wb',mtime=0,filename='') as zipped:
  with tarfile.open(fileobj=zipped,mode='w') as tar:
   for p in files:
    rel=p.relative_to(O);b=p.read_bytes();info=tar.gettarinfo(str(p),arcname=str(rel));info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0
    with p.open('rb') as source:tar.addfile(info,source)
    members.append(dict(path=str(rel),bytes=len(b),sha256=hashlib.sha256(b).hexdigest()))
manifest=dict(sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),bytes=archive.stat().st_size,members=members,excluded=['Unrelated preexisting code diff','Unchanged official asset copies from installed-before','Generated Python caches'])
(D/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(archive,'r:gz') as tar:
 for row in members:assert hashlib.sha256(tar.extractfile(row['path']).read()).hexdigest()==row['sha256']
for file in ['report.md','judgment.md','action-log.md']:
 for link in re.findall(r'\]\(([^)]+)\)',(D/file).read_text()):assert (D/link).exists(),link
print('Published',D,'archive',archive.stat().st_size,'bytes',len(members),'verified members')
