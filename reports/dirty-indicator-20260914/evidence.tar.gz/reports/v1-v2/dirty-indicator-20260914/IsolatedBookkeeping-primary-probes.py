# MenuTitle: Dirty Indicator Isolated Bookkeeping
"""Separately labelled native diagnostic operations, not public-MCP workflow.

No patching of the installed bridge or native methods, no counter writes or saves.
Copy the current write_value function and add read-only stage logging only.
"""
import ast,hashlib,json,os,shutil,time,traceback
from pathlib import Path
import objc
from GlyphsApp import Glyphs,GSPath
from AppKit import NSDocumentController
from PyObjCTools import AppHelper
from glyphs_mcp_bridge.glyphs_adapter import GlyphsAdapter
R=Path('/Users/thierryc/Dev/github/thierryc/Glyphs-mcp-worktrees/v2')
O=R/'reports/v1-v2/dirty-indicator-20260914'
FOLDER=Path('/private/tmp/dirty-indicator-20260914')
for p,names in [(R/'reports/v1-v2/09-spacing/NativeQualification.py',('ident','point','userdata','snapshot')),(O/'NativeQualification.py',('val','manager','compact','proof','stable'))]:
 for n in ast.parse(p.read_text()).body:
  if isinstance(n,ast.FunctionDef) and n.name in names:
   exec(compile(ast.unparse(n).replace('f.parent.undoManager()', 'f.parent.undoManagerCheck()'),'nonallocating-oracle','exec'))
existing=list(Glyphs.fonts);before=[stable(f) for f in existing]
cases=['rounding_only','document_group_only','native_setter','block_no_document','block_with_document']
state=dict(font=None,index=-1,rows=[],current=None)
def flush():
 (O/'isolated-bookkeeping.json').write_text(json.dumps(dict(pid=os.getpid(),host=str(Glyphs.versionNumber),build=str(Glyphs.buildNumber),autosavingDelay=float(NSDocumentController.sharedDocumentController().autosavingDelay()),cases=state['rows'],originalsExact=[stable(f) for f in existing]==before),indent=2,default=str)+'\n')
def note(label):
 state['current']['stages'].append(dict(label=label,state=compact(state['font'])))
# Copy the implementation; insert evidence reads at its operation boundaries.
src=(R/'build/milestone7/desktop/src/bridge/glyphs_mcp_bridge/native_undo.py').read_text()
assert src.count('register(target, restore)')==1
instrumented=src.replace('    register(target, restore)','    note("before-register")\n    register(target, restore)\n    note("after-register")').replace('    manager.disableUndoRegistration()','    manager.disableUndoRegistration()\n    note("registration-disabled")').replace('        manager.enableUndoRegistration()','        manager.enableUndoRegistration()\n        note("registration-enabled")')
ns={'note':note};exec(compile(instrumented,'read-logged-native-undo-copy','exec'),ns)
(O/'native-undo-source.py').write_text(src)
(O/'native-undo-instrumented.py').write_text(instrumented)
def guard():assert [stable(f) for f in existing]==before,'Original changed'
def fail():
 state['current']['error']=traceback.format_exc();flush()
 # Stop on unexpected failure. Keep the disposable font available for inspection.
def next_case():
 try:
  guard()
  if state['font'] is not None:
   f=state['font'];state['font']=None;f.close(ignoreChanges=True)
  state['index']+=1
  if state['index']==len(cases):
   flush();(O/'isolated-finished.json').write_text(json.dumps(dict(ok=True,originalsExact=True,pid=os.getpid())));return
  case=cases[state['index']];p=FOLDER/(str(time.time_ns())+'-isolated-'+case+'.glyphs');shutil.copy2(O/'DirtyIndicatorTest.glyphs',p)
  f=Glyphs.open(str(p),showInterface=True);state['font']=f;f.newTab('/control')
  row=dict(case=case,path=str(p),sourceHash=hashlib.sha256(src.encode()).hexdigest(),stages=[],baseline=proof(f));state['rows'].append(row);state['current']=row
  assert not f.parent.isDocumentEdited();AppHelper.callLater(.5,edit)
 except Exception:fail()
def edit():
 try:
  guard();f=state['font'];l=f.glyphs['control'].layers[0];case=state['current']['case'];note('before')
  if case=='rounding_only':
   GlyphsAdapter._set_rounding(l,True);note('flag-on');GlyphsAdapter._set_rounding(l,False);note('flag-off')
  elif case=='document_group_only':
   s=ns['NativeUndoScope'](f.parent.undoManager());note('doc-group-open');s.finish('Diagnostic empty group');note('doc-group-closed')
  elif case=='native_setter':
   m=l.undoManager();m.beginUndoGrouping();l.width=608;note('setter');m.endUndoGrouping();note('group-closed')
  else:
   s=ns['NativeUndoScope'](f.parent.undoManager() if case=='block_with_document' else None);note('scope-open');m=s.manager_for(l);note('glyph-group-open')
   change=dict(kind='set',field='width')
   def exact(owner,key,value):
    note('before-exact');GlyphsAdapter._write_exact(owner,key,value);note('after-exact')
   ns['write_value'](m,l,change,608,lambda owner,key:owner.width,exact);s.finish('Diagnostic copied registration');note('scope-closed')
  AppHelper.callLater(.5,undo)
 except Exception:fail()
def undo():
 try:
  note('edit-settled');f=state['font'];state['current']['edited']=proof(f);m=f.glyphs['control'].undoManagerCheck()
  if state['current']['case'] in ('rounding_only','document_group_only'):AppHelper.callLater(.5,final);return
  assert m.groupingLevel()<=1 and m.canUndo();m.undo();note('undo-returned');AppHelper.callLater(.5,redo)
 except Exception:fail()
def redo():
 try:
  f=state['font'];state['current']['undone']=proof(f);note('undo-settled');m=f.glyphs['control'].undoManagerCheck();assert m.canRedo();m.redo();note('redo-returned');AppHelper.callLater(.5,final_undo)
 except Exception:fail()
def final_undo():
 try:
  f=state['font'];state['current']['redone']=proof(f);note('redo-settled');f.glyphs['control'].undoManagerCheck().undo();note('final-undo-returned');AppHelper.callLater(.5,final)
 except Exception:fail()
def final():
 try:
  note('final-settled');state['current']['final']=proof(state['font']);guard();flush();AppHelper.callLater(.5,next_case)
 except Exception:fail()
AppHelper.callLater(.5,next_case)
