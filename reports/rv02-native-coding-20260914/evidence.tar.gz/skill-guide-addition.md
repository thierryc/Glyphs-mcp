
OpenType source work uses `glyphs-mcp-opentype-features` for native Glyphs 4
scripts, compilation diagnostics and exported behavior checks. This skill adds
no feature-editing or Python-execution MCP tool.
