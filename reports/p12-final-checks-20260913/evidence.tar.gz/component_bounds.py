import asyncio,json,copy,sys
from common import Harness,save
from workflow import *
def stored(b,a):
 b=copy.deepcopy(b);a=copy.deepcopy(a)
 for r in (b,a):
  for role in ('target','unrelated'):
   for l in r[role]['data']['layers']:l.pop('bounds',None)
 return same(b,a)
async def main():
 label=sys.argv[1] if len(sys.argv)>1 else 'v2';h=Harness(label);await h.connect();ev=await h.setup('open');doc,_=await h.resolve(ev['path'],'component-bounds');await h.setup('edit',glyph='slant00');b=await h.setup('proof');p=await prepare(h,doc,['slant00'],'component-bounds') if label=='v2' else await v1prepare(h,doc,['slant00'],'component-bounds',slant_mode='balanced',curve_strength=0,stem_compensation=0)
 if label=='v2':await h.call('apply_job',dict(job_id=p['id'],include_preview=False),'component-bounds-apply');await poll(h,p['id'],{'applied'},'component-bounds-poll')
 else:await v1apply(h,p,'component-bounds')
 a=await h.setup('proof');u=await h.setup('undo',glyph='slant00');redo=await h.setup('redo',glyph='slant00')
 for mi in (0,1,2):await h.setup('edit',glyph='slant00',master=mi)
 await restore(h,doc,['slant00'],p,'component-bounds');z=await h.setup('proof');r=dict(path=ev['path'],before=b,applied=a,undoDifferences=same(b,u),redoDifferences=same(a,redo),discard=z,discardDifferences=same(b,z),storedRestorationDifferences=stored(b,z),redraw=[])
 save(label+'/component-bounds.json',r)
 for name in ('automatic','manual'):
  for mi in (0,1,2):
   await h.setup('edit',glyph=name,master=mi);v=await h.setup('proof');r['redraw'].append(dict(glyph=name,master=mi,differences=same(b,v),storedDifferences=stored(b,v)));save(label+'/component-bounds.json',r)
 print(json.dumps({k:v for k,v in r.items() if k not in ('before','applied','discard')}),flush=True);await h.setup('close');await h.end()
asyncio.run(main())
