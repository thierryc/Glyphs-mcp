import asyncio,json
from common import Harness,save
from workflow import same
async def main():
 h=Harness('v2');await h.connect();ev=await h.setup('open');doc,_=await h.resolve(ev['path'],'unique-limit');b=await h.setup('proof')
 names=['p12_limit_'+str(i) for i in range(10001)]
 r,_=await h.call('start_job',dict(document_id=doc,kind='slant',glyphs=names),'unique-limit-refusal');z=await h.setup('proof');d=same(b,z)
 result=dict(requestedCount=len(names),uniqueCount=len(set(names)),expectedLimit=10000,response=r,preservation=d,passed=r.get('error',{}).get('code')=='invalid_request' and r.get('error',{}).get('message')=='glyphs must contain 1-10,000 names' and not d)
 save('v2/count-limit.json',result);print(json.dumps(result));await h.setup('close');await h.end()
asyncio.run(main())
