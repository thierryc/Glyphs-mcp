import asyncio,json,time,os,sys
from common import Harness,save
from workflow import *
async def main():
 label=sys.argv[1];h=Harness(label);await h.connect();ev=await h.setup('open');doc,_=await h.resolve(ev['path'],'profile');b=await h.setup('proof');overhead={}
 for enabled in (False,True):
  await h.setup('profile',enabled=enabled);samples=[]
  for i in range(6):
   _,ms=await h.call('get_status' if label=='v2' else 'get_server_info',{},'probe-overhead-'+str(enabled))
   if i:samples.append(ms)
  overhead[str(enabled)]=samples
 save(label+'/probe-overhead.json',overhead);await h.setup('profile',enabled=True);t=time.perf_counter();load=os.getloadavg()
 p=await prepare(h,doc,E['batch'],'profile') if label=='v2' else await v1prepare(h,doc,E['batch'],'profile',slant_mode='balanced',curve_strength=0,stem_compensation=0)
 if label=='v2':await h.call('apply_job',dict(job_id=p['id'],include_preview=False),'profile-apply');await poll(h,p['id'],{'applied'},'profile-apply-poll')
 else:await v1apply(h,p,'profile')
 mutation=time.perf_counter()
 while time.perf_counter()-mutation<2.1:await read(h,doc,E['core'],'profile-post-read');await asyncio.sleep(.05)
 result=await h.setup('profile',enabled=False);result.update(load=load,afterLoad=os.getloadavg(),wallMs=(time.perf_counter()-t)*1000,postMutationSeconds=time.perf_counter()-mutation);save(label+'/profile.json',result);a=await h.setup('proof');await restore(h,doc,E['batch'],p,'profile');z=await h.setup('proof');save(label+'/profile-accuracy.json',dict(applicationDifferences=slanted(b,a,E['batch'],allow_backups=label=='v1'),restorationDifferences=same(b,z)));await h.setup('close');await h.end()
asyncio.run(main())
