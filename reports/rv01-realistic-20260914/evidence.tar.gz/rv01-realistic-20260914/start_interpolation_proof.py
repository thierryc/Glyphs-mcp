from pathlib import Path
import sys,json,traceback
O=Path(__file__).resolve().parent;sys.path.insert(0,str(O));from native_oracle import load,target,value
sources=[('misaligned',Path('/private/tmp/rv01-20260914/RobotoSlab-shifted.glyphs')),('original-correspondence',O/'font-source/RobotoSlab.glyphs')];rows=[]
for label,path in sources:
 f=load(path);row=dict(label=label,compatible=bool(value(f.glyphs['o'],'mastersCompatible')),instances=[])
 for name in ('Light','Medium','Bold'):
  try:
   i=next(x for x in f.instances if x.name==name);r=target(value(i,'interpolatedFont'),'o');row['instances'].append(dict(name=name,outline=r))
  except Exception:row['instances'].append(dict(name=name,error=traceback.format_exc()))
 rows.append(row)
(O/'tasks/T03/native-interpolation.json').write_text(json.dumps(rows,indent=2));print([(r['label'],r['compatible'],[(x['name'],'error' in x) for x in r['instances']]) for r in rows])
