# MenuTitle: P09 Spacing Qualification
"""Temporary disposable setup/oracle and native timings. No public task writes or IDs."""
import json,hashlib,shutil,time,traceback,re
from pathlib import Path
from datetime import datetime,timezone
import objc
from GlyphsApp import Glyphs,GSPath
from PyObjCTools import AppHelper
ROOT=Path('/Users/thierryc/Dev/github/thierryc/Glyphs-mcp-worktrees/v2')
OUT=ROOT/'reports/v1-v2/09-spacing';LABEL='v2' if str(Glyphs.versionNumber).startswith('4') else 'v1'
LOG=OUT/LABEL;LOG.mkdir(exist_ok=True);FOLDER=Path('/private/tmp/p09-spacing-20260912')/LABEL;FOLDER.mkdir(parents=True,exist_ok=True)
EXISTING=list(Glyphs.fonts)
def external_state():
 return [dict(id=int(objc.pyobjc_id(f)),path=str(f.filepath),dirty=bool(f.parent.isDocumentEdited()),glyphCount=len(f.glyphs)) for f in EXISTING]
EXTERNAL_BEFORE=external_state()
state=dict(active=True,seen=None,deadline=time.monotonic()+5400,target=None,unrelated=None,copies=[],instrument=False,samples=[],lags=[])
if LABEL=='v2':
 from glyphs_mcp_bridge.lifecycle import bridge_lifecycle as life
 assert not hasattr(life,'_p09_qualification');life._p09_qualification=state
 state['call']=life.server.main_thread.call;state['chunk']=life.core._run_chunk
else:
 import mcp_tool_helpers as v1helpers
 state['call']=v1helpers._run_on_main_thread

def ident(o):return int(objc.pyobjc_id(o)) if o is not None else None
def point(o):return [o.x,o.y]
def userdata(o):return dict(o.userData or {})
def snapshot(f):
 objects=[f,*f.masters];rows=[]
 for g in f.glyphs:
  objects.append(g)
  for l in g.layers:
   objects.append(l);shapes=[]
   for s in l.shapes:
    objects.append(s)
    if isinstance(s,GSPath):
     objects.extend(s.nodes);shapes.append(dict(kind='path',closed=bool(s.closed),nodes=[dict(position=point(n.position),type=str(n.type),smooth=bool(n.smooth),name=n.name,userData=userdata(n)) for n in s.nodes]))
    else:shapes.append(dict(kind='component',name=s.componentName,transform=list(s.transform),alignment=s.alignment,automaticAlignment=bool(s.automaticAlignment)))
   for seq in (l.anchors,l.guides,l.hints):objects.extend(seq)
   nodeidx={ident(n):[pi,ni] for pi,p in enumerate(l.paths) for ni,n in enumerate(p.nodes)}
   rows.append(dict(glyph=g.name,layer=l.layerId,master=l.associatedMasterId,width=l.width,vertical=[l.vertWidth,l.vertOrigin],keys=[l.leftMetricsKey,l.rightMetricsKey,l.widthMetricsKey],shapes=shapes,anchors=[[a.name,*point(a.position)] for a in l.anchors],guides=[[*point(a.position),a.angle] for a in l.guides],hints=[dict(type=h.type,origin=nodeidx.get(ident(h.originNode)),target=nodeidx.get(ident(h.targetNode))) for h in l.hints],userData=userdata(l),bounds=[l.bounds.origin.x,l.bounds.origin.y,l.bounds.size.width,l.bounds.size.height]))
 um=f.parent.undoManager() if f.parent is not None else None
 return dict(data=dict(family=f.familyName,userData=userdata(f),masters=[dict(id=m.id,name=m.name,ascender=m.ascender,descender=m.descender) for m in f.masters],glyphs=[dict(name=g.name,unicode=g.unicode,export=bool(g.export),keys=[g.leftMetricsKey,g.rightMetricsKey,g.widthMetricsKey],userData=userdata(g)) for g in f.glyphs],layers=rows,kerning=str(f.kerning)),objects=[ident(o) for o in objects],hintReferences=[[ident(h),ident(h.originNode),ident(h.targetNode)] for g in f.glyphs for l in g.layers for h in l.hints],dirty=bool(f.parent.isDocumentEdited()) if um else None,undo=dict(canUndo=bool(um.canUndo()),canRedo=bool(um.canRedo()),groupingLevel=um.groupingLevel()) if um else None)
def pairproof():return dict({r:snapshot(state[r]) if state[r] else None for r in ('target','unrelated')}, existing=external_state())
def close(role):
 f=state[role]
 if f is not None:
  assert Path(str(f.filepath)).parent==FOLDER;f.close(ignoreChanges=True);state[role]=None
def measured_call(callback):
 queued=time.perf_counter_ns()
 def run():
  start=time.perf_counter_ns()
  try:return callback()
  finally:
   if len(state['samples'])<5000:state['samples'].append(dict(at=datetime.now(timezone.utc).isoformat(),callback=getattr(callback,'__qualname__',type(callback).__name__),dispatchWaitMs=(start-queued)/1e6,callbackMs=(time.perf_counter_ns()-start)/1e6))
 return state['call'](run)
def measured_chunk(job):
 start=time.perf_counter_ns()
 try:return state['chunk'](job)
 finally:
  if len(state['samples'])<5000:state['samples'].append(dict(kind='native-edit-chunk',job=job,at=datetime.now(timezone.utc).isoformat(),callbackMs=(time.perf_counter_ns()-start)/1e6))
def tick(due):
 if not state['active'] or not state['instrument']:return
 if len(state['lags'])<10000:state['lags'].append(max(0,(time.perf_counter()-due)*1000))
 AppHelper.callLater(.01,tick,time.perf_counter()+.01)
def instrument(enabled):
 if LABEL=='v2':
  life.server.main_thread.call=measured_call if enabled else state['call']
  life.core._run_chunk=measured_chunk if enabled else state['chunk']
 else:v1helpers._run_on_main_thread=measured_call if enabled else state['call']
 start=enabled and not state['instrument'];state['instrument']=enabled
 if start:AppHelper.callLater(.01,tick,time.perf_counter()+.01)
def execute(c):
 assert external_state()==EXTERNAL_BEFORE,'An existing document changed; stop qualification'
 assert all(f in EXISTING or (f.filepath and Path(str(f.filepath)).parent==FOLDER) for f in Glyphs.fonts),'Unexpected document appeared'
 action=c['action']
 if action=='finish':
  instrument(False);close('target');close('unrelated');state['active']=False
  if LABEL=='v2':del life._p09_qualification
  return dict(documents=len(list(Glyphs.fonts)),copies=state['copies'])
 if action=='profile':
  result=dict(samples=state['samples'],mainQueueLagsMs=state['lags']);state['samples']=[];state['lags']=[];instrument(c['enabled']);return result
 if action=='proof':return pairproof()
 if action=='edit':
  f=state['target'];g=c.get('glyph','A.p00');f.show();tab=f.newTab('/'+g);tab.masterIndex=c.get('master',0);return dict(path=str(f.filepath),glyph=g)
 if action=='visual':
  f=state['target'];f.show();f.newTab('HHHOHH AVAYAW nonono 0123456789');return dict(path=str(f.filepath))
 if action=='close':close('target');close('unrelated');return dict(documents=len(list(Glyphs.fonts)))
 if action=='close-target':state['closedPath']=str(state['target'].filepath);close('target');return dict(documents=len(list(Glyphs.fonts)))
 if action=='reopen':state['target']=Glyphs.open(state['closedPath'],showInterface=True);return dict(path=state['closedPath'])
 if action=='foreground':state['unrelated'].show();return dict(path=str(Glyphs.font.filepath))
 if action in ('undo','redo'):
  f=state['target'];um=f.parent.undoManager();getattr(um,action)();return pairproof()
 if action=='dirty':
  f=state['target'];l=f.glyphs[c.get('glyph','control')].layers[f.masters[0].id];l.width+=.125;f.parent.updateChangeCount_(0);return dict(dirty=bool(f.parent.isDocumentEdited()),width=l.width)
 if action=='save':state['target'].save();return dict(path=str(state['target'].filepath))
 assert action=='open';close('target');close('unrelated')
 for role in ('unrelated','target'):
  p=FOLDER/(c['requestId']+'-'+role+'.glyphs');assert not p.exists();shutil.copy2(OUT/'SpacingTest.glyphs',p)
  # Disposable setup only: match the host's producer header to avoid a modal
  # version notice. Preserve all font content and the immutable baseline.
  text=p.read_text();text=re.sub(r'\.appVersion = "?\d+"?;', '.appVersion = "'+str(int(float(Glyphs.buildNumber)))+'";',text,count=1);p.write_text(text)
  state['copies'].append(dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest()));state[role]=Glyphs.open(str(p),showInterface=True)
 return dict(path=str(state['target'].filepath),documents=len(list(Glyphs.fonts)))
def pump():
 if not state['active']:return
 if time.monotonic()>state['deadline']:execute({'action':'finish'});return
 p=LOG/'native-request.json'
 if p.exists():
  c=json.loads(p.read_text())
  if c['requestId']!=state['seen']:
   state['seen']=c['requestId'];start=time.perf_counter()
   try:r=dict(ok=True,data=execute(c))
   except Exception:r=dict(ok=False,error=traceback.format_exc())
   r['nativeSetupMs']=(time.perf_counter()-start)*1000
   (LOG/'native-acks').mkdir(exist_ok=True);p=LOG/'native-acks'/(c['requestId']+'.tmp');p.write_text(json.dumps(r,indent=2,default=str)+'\n');p.replace(p.with_suffix('.json'))
 if state['active']:AppHelper.callLater(.1,pump)
(LOG/'native-ready.json').write_text(json.dumps(dict(host=str(Glyphs.versionNumber),build=str(Glyphs.buildNumber),ready=True,at=datetime.now(timezone.utc).isoformat())))
AppHelper.callLater(.1,pump)
