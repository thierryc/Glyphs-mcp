"""Read-only before/after installation, source, original-font and script audit."""
import hashlib,json,time
from pathlib import Path
O=Path(__file__).resolve().parent
before=json.loads((O/'freeze.json').read_text());result=dict(at=time.time(),roots={},newCrashReports=[])
for name,row in before['roots'].items():
 root=Path(row['path']);current={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in root.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc'}
 old=row['files'];result['roots'][name]=dict(rootExists=root.exists(),beforeFiles=len(old),afterFiles=len(current),changed=[p for p in sorted(old.keys()|current.keys()) if old.get(p)!=current.get(p)])
crash=Path.home()/'Library/Logs/DiagnosticReports';old=set(before['crashes'])
result['newCrashReports']=[str(p) for p in crash.glob('*Glyphs*') if str(p) not in old]
result['unavailableRoots']=[name for name,row in result['roots'].items() if not row['rootExists']]
result['allAvailableRootsUnchanged']=all(not row['changed'] for row in result['roots'].values() if row['rootExists'])
result['allFrozenRootsUnchanged']=all(not r['changed'] for r in result['roots'].values())
(O/'preservation-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
