"""Store the completed route qualification without running Glyphs or any test."""
from pathlib import Path
import gzip,hashlib,io,json,shutil,tarfile
O=Path(__file__).resolve().parent;R=O.parents[3];S=R/'build/milestone7/desktop'
D=S/'reports/http-route-fix-20260914';D.mkdir(parents=True,exist_ok=False)
paths=sorted([p for p in O.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc']+[R/'reports/v1-v2/README.md',O.parent/'latency-investigation-20260911/report.md',O.parent/'latency-investigation-20260911/next-actions.md'])
rows=[]
with (D/'evidence.tar.gz').open('wb') as dest:
 with gzip.GzipFile(fileobj=dest,mode='wb',filename='',mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w',format=tarfile.PAX_FORMAT) as tar:
   for p in paths:
    b=p.read_bytes();rel=p.relative_to(R).as_posix();row=dict(path=rel,size=len(b),sha256=hashlib.sha256(b).hexdigest());rows.append(row)
    info=tarfile.TarInfo(rel);info.size=len(b);info.mode=0o644;info.mtime=0;info.uid=info.gid=0;info.uname=info.gname='';tar.addfile(info,io.BytesIO(b))
with tarfile.open(D/'evidence.tar.gz','r:gz') as tar:
 members=tar.getmembers();assert len(members)==len(rows)
 for member,row in zip(members,rows):
  assert member.name==row['path'] and member.size==row['size']
  assert hashlib.sha256(tar.extractfile(member).read()).hexdigest()==row['sha256']
p=D/'evidence.tar.gz';manifest=dict(archive=dict(path=p.name,bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()),memberCount=len(rows),members=rows)
(D/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for name in ('report.md','test-spec.md','verification.json','candidate-manifest.json','build.json'):
 shutil.copyfile(O/name,D/name)
shutil.copyfile(R/'reports/v1-v2/README.md',D/'coverage-index.md')
(D/'README.md').write_text('''# Installed HTTP route correction

The configured `/mcp/` endpoint is now served directly using FastMCP's existing
path option. Seven tools and their schemas remain unchanged. The installed
sidecar is `2.0.0-beta.1+82daa62ac227`; bridge, companions and skills are unchanged.

581 lean tests pass. The live comparison records 12 tool calls / 24 HTTP exchanges
before, versus 12 / 12 after, with identical read/error evidence. Timing is not a
matched-load performance comparison. The first installation was refused by the
existing Glyphs-closed guard; a normal close/install/relaunch restored the clean
disposable font. No Undo, queue-tail or autosave fix is included.

The archive contains the full follow-up folder, logs, scripts, first refused
installation, completed receipt, frozen identities and verification, plus the
historical P07 report/proposal and updated coverage index. Every archive member
was read back and checksum verified. Extract into a fresh directory:

```sh
mkdir route-evidence
tar -xzf evidence.tar.gz -C route-evidence
```

Then open `route-evidence/reports/v1-v2/07-stored-kerning/http-route-fix-20260914/report.md`.
The older P07 report's full raw evidence remains in its original worktree folder;
it is not duplicated here. Qualification scripts contain historical paths and
phase folders that deliberately refuse overwriting the recorded run. Read the
specification and use new output paths before any authorized replay.

No private font source or credential is included. No release was published.
''')
print(json.dumps({k:manifest[k] for k in ('archive','memberCount')},indent=2))
