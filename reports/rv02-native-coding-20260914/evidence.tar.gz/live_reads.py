from pathlib import Path
import asyncio,json,time,sys,os
from fastmcp import Client
O=Path(__file__).resolve().parent;R=O.parents[2];sys.path.insert(0,str(R/'scripts'))
from compare_connection_routing import body,plain
async def main():
 async with Client('http://127.0.0.1:9680/mcp/',timeout=45) as client:
  (O/'catalog.json').write_text(json.dumps([plain(x) for x in await client.list_tools()],indent=2));(O/'handshake.json').write_text(json.dumps(plain(client.initialize_result),indent=2))
  async def call(name,args):
   t=time.perf_counter();r=body(await client.call_tool_mcp(name,args));row=dict(at=time.time(),name=name,arguments=args,result=r,httpMs=(time.perf_counter()-t)*1000,load=os.getloadavg())
   with (O/'calls.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
   return r
  if len(sys.argv)>1 and sys.argv[1]=='stale':
   doc=json.load(open(O/'live-target.json'))['id'];r=await call('read_entities',dict(document_id=doc,entities=[dict(kind='glyph',id='o')],fields=['name']));assert not r['ok'] and r['error']['code']=='document_not_found',r
   (O/'stale-id.json').write_text(json.dumps(r,indent=2));return
  r=await call('get_status',{});(O/'runtime-after-install.json').write_text(json.dumps(r,indent=2));baseline=json.load(open(O/'runtime-before.json'))['data'];assert r['data']['codeHash']==baseline['codeHash'] and r['data']['bridge']['codeHash']==baseline['bridge']['codeHash'];assert len(r['data']['tools'])==7
  ds=await call('list_documents',{});matches=[d for d in ds['data'] if d['path']=='/private/tmp/RV02-20260914.glyphs'];assert len(matches)==1,ds;doc=matches[0]['id'];(O/'live-target.json').write_text(json.dumps(matches[0],indent=2));(O/'documents-before.json').write_text(json.dumps(ds,indent=2))
  valid=await call('read_entities',dict(document_id=doc,entities=[dict(kind='glyph',id=n) for n in ['o','H','at']],fields=['name','unicode','category','subCategory','export']))
  missing=await call('read_entities',dict(document_id=doc,entities=[dict(kind='glyph',id='missing.rv02')],fields=['name']))
  repeat=await call('read_entities',dict(document_id=doc,entities=[dict(kind='glyph',id='o')],fields=['name','unicode']))
  (O/'selector-results.json').write_text(json.dumps(dict(valid=valid,missing=missing,repeat=repeat),indent=2));assert valid['ok'] and repeat['ok'];assert not missing['ok'] and missing['error']['code']=='target_not_found' and 'missing.rv02' in missing['error']['message'],missing
  print('Valid id, named missing glyph and same-ID recovery verified.')
asyncio.run(main())
