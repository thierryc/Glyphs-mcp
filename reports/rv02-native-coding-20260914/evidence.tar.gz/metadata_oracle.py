from pathlib import Path
import sys,json,shutil
O=Path(__file__).resolve().parent;sys.path.insert(0,str(O));from native_oracle import *
p=O/'metadata-oracle.glyphs';shutil.copy(O/'font-source/RobotoSlab.glyphs',p);f=load(p);before=records(f);rows=[]
for name in ['o','H','at']:
 g=f.glyphs[name];rows.append(dict(name=g.name,unicode=g.unicode,category=g.category,subCategory=g.subCategory,export=bool(value(g,'export'))))
after=records(f);(O/'metadata-oracle.json').write_text(json.dumps(dict(rows=rows,fullDataExact=before['data']==after['data'],objectsExact=before['objects']==after['objects']),indent=2))
