from pathlib import Path
import json
from fontTools.ttLib import TTFont
from fontTools.pens.svgPathPen import SVGPathPen
O=Path(__file__).resolve().parent;ft=TTFont(O/'tasks/T11/export/RobotoSlab-Regular.ttf');gs=ft.getGlyphSet();parts=['<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="840"><rect width="100%" height="100%" fill="#faf9f6"/><text x="35" y="40" font-family="sans-serif" font-size="24">T11 · Actual exported Regular outlines · ss20 off / on</text><text x="35" y="69" font-family="sans-serif" font-size="14">Compiled TTF shaped with HarfBuzz · g changes to g.ss01 · different advances retained</text>']
shapes=json.loads((O/'tasks/T11/shaping.json').read_text())['samples']
for idx,row in enumerate(shapes[2:4]):
 parts.append(f'<text x="35" y="{110+idx*370}" font-family="sans-serif" font-size="18">ss20 {"on" if row["ss20"] else "off"}</text>');x=35;y=295+idx*370;scale=.16
 for name,pos in zip(row['glyphs'],row['positions']):
  pen=SVGPathPen(gs);gs[name].draw(pen);parts.append(f'<path d="{pen.getCommands()}" transform="translate({x},{y}) scale({scale},{-scale})" fill="#183d43"/>');x+=pos[0]*scale
parts.append('</svg>');(O/'visuals/T11.svg').write_text(''.join(parts))
