"""Public MCP requests only; retain native setup and UI actions separately."""
import asyncio,json,sys,time,os
from pathlib import Path
from fastmcp import Client
O=Path(__file__).resolve().parent
def body(r):
 return r.structuredContent or json.loads(r.content[0].text)
async def main():
 label,action,arg=sys.argv[1:4]
 async with Client('http://127.0.0.1:9680/mcp/',timeout=30) as c:
  async def call(name,args):
   at=time.time();start=time.perf_counter();r=body(await c.call_tool_mcp(name,args));row=dict(at=at,label=label,name=name,args=args,result=r,httpMs=(time.perf_counter()-start)*1000,load=os.getloadavg())
   with (O/'public-calls.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
   return r
  if action=='prepare':
   docs=await call('list_documents',{});matches=[d for d in docs['data'] if d['path']==arg];assert len(matches)==1,docs
   r=await call('start_job',dict(document_id=matches[0]['id'],kind='width_delta',delta=8,glyphs=['control']))
   if not r.get('ok'):print(json.dumps(r));return
   job=r['data']['id'];(O/(label+'-job.json')).write_text(json.dumps(dict(job=job,document=matches[0]['id'],path=arg)))
  else:
   job=json.loads((O/(arg+'-job.json')).read_text())['job'];r=await call(action,dict(job_id=job,include_preview=False))
  for _ in range(30):
   if not r.get('ok') or r['data']['status'] not in ('preparing','applying','discarding'):break
   await asyncio.sleep(.2);r=await call('get_job',dict(job_id=job,include_preview=True if action=='prepare' else False))
  print(json.dumps(r))
asyncio.run(main())
