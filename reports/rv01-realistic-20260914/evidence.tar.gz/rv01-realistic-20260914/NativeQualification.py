# MenuTitle: RV01 Realistic Qualification
"""Temporary setup/read-only oracle. Public jobs remain public MCP operations."""
from pathlib import Path
import sys,json,time,traceback,shutil,os
from GlyphsApp import Glyphs,OFFCURVE,GSNode
from AppKit import NSDocumentController
from PyObjCTools import AppHelper
O=Path('/Users/thierryc/Dev/github/thierryc/Glyphs-mcp-worktrees/v2/reports/v2-realistic/20260914');sys.path.insert(0,str(O))
from native_oracle import records,digest,target
P=Path('/private/tmp/rv01-20260914');P.mkdir(exist_ok=True)
EXISTING=list(Glyphs.fonts)
def existing():return [dict(path=str(f.filepath),data=digest(records(f)['data']),objects=records(f)['objects'],dirty=bool(f.parent.isDocumentEdited())) for f in EXISTING]
BEFORE=existing();state=dict(active=True,seen=None,target=None,copies=[],ticks=[],samples=[],instrument=False)
from glyphs_mcp_bridge.lifecycle import bridge_lifecycle as life
original_call=life.server.main_thread.call

def dispatch(callback):
 queued=time.perf_counter()
 def perform():
  start=time.perf_counter()
  try:return callback()
  finally:state['samples'].append(dict(callback=getattr(callback,'__qualname__',str(type(callback))),dispatchWaitMs=(start-queued)*1000,nativeMs=(time.perf_counter()-start)*1000,at=time.time()))
 return original_call(perform)
life.server.main_thread.call=dispatch

def tick(due):
 if not state['active']:return
 if state['instrument'] and len(state['ticks'])<10000:state['ticks'].append(max(0,(time.perf_counter()-due)*1000))
 AppHelper.callLater(.02,tick,time.perf_counter()+.02)
def check():assert existing()==BEFORE,'Protected document changed'
def close():
 f=state['target']
 if f:
  assert Path(str(f.filepath)).parent==P;f.close(ignoreChanges=True);state['target']=None

def proof():
 f=state['target'];s=records(f)
 return dict(data=s['data'],objects=s['objects'],hintReferences=s['hintReferences'],dirty=bool(f.parent.isDocumentEdited()),selected=[dict(path=pi,node=ni,x=n.position.x,y=n.position.y,type=str(n.type),smooth=bool(n.smooth)) for pi,p in enumerate(f.selectedLayers[0].paths) for ni,n in enumerate(p.nodes) if n in list(f.selectedLayers[0].selection)] if f.currentTab and f.selectedLayers else [],rounding=[str(getattr(l,'temporarilyDisableRounding',None)) for l in f.glyphs['o'].layers],target=target(f,'o'))
def execute(c):
 check();a=c['action']
 if a=='open':
  close();src=O/'font-source/RobotoSlab.glyphs' if c.get('fixture')!='shifted' else P/'RobotoSlab-shifted.glyphs';p=P/(c['requestId']+'.glyphs');assert not p.exists();shutil.copy2(src,p);f=Glyphs.open(str(p),showInterface=True);assert f;state['target']=f;state['copies'].append(str(p));return dict(path=str(p),masters=[dict(id=m.id,name=m.name) for m in f.masters],glyphs=len(f.glyphs))
 if a=='view':
  f=state['target'];name=c.get('glyph','o')
  if f.currentTab:f.currentTab.text='/'+name
  else:f.newTab('/'+name)
  f.currentTab.masterIndex=c.get('master',1);l=f.glyphs[name].layers[f.masters[c.get('master',1)].id];l.selection=[]
  for n in list(l.paths[0].nodes)[:c.get('nodes',3)]:l.selection.append(n)
  return dict(layer=l.layerId,glyph=name,selected=len(l.selection))
 if a=='proof':return proof()
 if a=='profile':
  out=dict(samples=state['samples'],mainQueueLagsMs=state['ticks']);state['samples']=[];state['ticks']=[];state['instrument']=c.get('enabled',False);return out
 if a=='close':close();return dict(ok=True)
 if a=='finish':
  state['instrument']=False;close();life.server.main_thread.call=original_call;state['active']=False;check();return dict(originalExact=True,originals=BEFORE,copies=state['copies'],samples=state['samples'],pid=os.getpid(),autosavingDelay=NSDocumentController.sharedDocumentController().autosavingDelay())
 raise ValueError('Unknown diagnostic action')
def pump():
 if not state['active']:return
 p=O/'native-request.json'
 if p.exists():
  c=json.loads(p.read_text())
  if c['requestId']!=state['seen']:
   state['seen']=c['requestId'];start=time.perf_counter()
   try:r=dict(ok=True,data=execute(c))
   except Exception:r=dict(ok=False,error=traceback.format_exc())
   r['nativeSetupMs']=(time.perf_counter()-start)*1000;dest=O/'native-acks';dest.mkdir(exist_ok=True);tmp=dest/(c['requestId']+'.tmp');tmp.write_text(json.dumps(r,default=str));tmp.replace(tmp.with_suffix('.json'))
 if state['active']:AppHelper.callLater(.15,pump)
(O/'native-ready.json').write_text(json.dumps(dict(pid=os.getpid(),host=str(Glyphs.versionNumber),build=str(Glyphs.buildNumber),originals=BEFORE,autosavingDelay=NSDocumentController.sharedDocumentController().autosavingDelay()),default=str))
AppHelper.callLater(.15,pump);AppHelper.callLater(.02,tick,time.perf_counter()+.02)
