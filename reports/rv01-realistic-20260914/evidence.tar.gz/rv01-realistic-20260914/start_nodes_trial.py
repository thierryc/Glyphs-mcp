import asyncio,json
from session import *
async def main():
 async with API() as a:
  opened=await setup('open',fixture='shifted');doc=await a.resolve(opened['path'],'T03');await setup('view');write('tasks/T03/native-before.json',await setup('proof'));write('tasks/T03/target.json',dict(**opened,document_id=doc))
  r=await a.call('start_job',dict(document_id=doc,kind='start_nodes',glyphs=['o'],options=dict(masters=[m['id'] for m in opened['masters']],path=0,referenceMaster=opened['masters'][0]['id'])),'T03');write('tasks/T03/start.json',r);print(json.dumps(r))
asyncio.run(main())
