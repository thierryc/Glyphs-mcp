from pathlib import Path
import re,sys,json,shutil,time
O=Path(__file__).resolve().parent;sys.path.insert(0,str(O));from native_oracle import *
from GlyphsApp import OFFCURVE,GSFeature,Glyphs
SK=Path.home()/'.codex/skills';recipe=re.findall(r'```python\n(.*?)```',(SK/'glyphs-mcp-development/references/native-precision.md').read_text(),re.S)[0];blocks=re.findall(r'```python\n(.*?)```',(SK/'glyphs-mcp-development/references/glyphs4-api-notes.md').read_text(),re.S)
p=O/'installed-smoke.glyphs';shutil.copy(O/'font-source/RobotoSlab.glyphs',p);f=load(p);mids=[m.id for m in f.masters];layers=[f.glyphs['o'].layers[mid] for mid in mids];nodes=[next(n for n in l.paths[0].nodes if n.type==OFFCURVE) for l in layers];expected=[(n.position.x+2.5,n.position.y) for n in nodes];flags=[bool(value(l,'temporarilyDisableRounding')) for l in layers];before=records(f)
def action(targets):
 for n,xy in zip(nodes,expected):n.position=xy
def verify(targets):assert [(n.position.x,n.position.y) for n in nodes]==expected
start=time.perf_counter();exec(recipe,dict(target_layers=layers,perform_requested_operation=action,verify_exact_requested_values=verify));ms=(time.perf_counter()-start)*1000;after=records(f)
feature=GSFeature('ss20','sub g by missing.rv02;');feature.automatic=False;f.features.append(feature);failed=False
try:exec(blocks[2],dict(font=f))
except RuntimeError as e:failed=True;error=str(e)
feature.code='sub g by g.ss01;';exec(blocks[2],dict(font=f));env=dict(feature=feature);exec(blocks[1],env)
r=dict(host=str(Glyphs.versionNumber),build=str(Glyphs.buildNumber),nativeCoordinateMs=ms,exactCoordinates=[(n.position.x,n.position.y) for n in nodes]==expected,flagsRestored=[bool(value(l,'temporarilyDisableRounding')) for l in layers]==flags,unrelatedDataExact=compare(before,after,'o')['unrelatedDataExact'],objectsExact=before['objects']==after['objects'],invalidCompileRejected=failed,diagnostic=error,correctedCompilePassed=True,automatic=env['automatic'],disabled=env['disabled']);(O/'installed-native-smoke.json').write_text(json.dumps(r,indent=2));assert r['exactCoordinates'] and r['flagsRestored'] and r['unrelatedDataExact'] and r['objectsExact'] and failed;print('Installed native recipe and API notes pass')
