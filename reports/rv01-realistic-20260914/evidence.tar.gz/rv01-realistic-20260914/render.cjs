const fs=require('fs'),path=require('path');const sharp=require('/Users/thierryc/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/sharp');
(async()=>{const dir=path.join(__dirname,'visuals');for(const file of fs.readdirSync(dir).filter(x=>x.endsWith('.svg')))await sharp(path.join(dir,file)).png().toFile(path.join(dir,file.replace('.svg','.png')));})();
