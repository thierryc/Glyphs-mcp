from pathlib import Path
import copy,hashlib,json,plistlib,subprocess,sys
O=Path(__file__).resolve().parent;R=O.parents[3];S=R/'build/milestone7/desktop';H=Path.home()
sys.path.insert(0,str(S/'scripts'))
from build_simple_v2 import _identity
baseline=json.loads((O/'baseline/facts.json').read_text());candidate=json.loads((O/'candidate/facts.json').read_text())
for key in ('initialize','catalog','read','errors','sourceSHA256'):
 assert baseline[key]==candidate[key],key
old_documents=copy.deepcopy(baseline['documents']);new_documents=copy.deepcopy(candidate['documents'])
old_ids=[d.pop('id') for d in old_documents['data']];new_ids=[d.pop('id') for d in new_documents['data']]
assert old_ids!=new_ids # Required Glyphs relaunch: never reuse the stale binding.
assert old_documents==new_documents,(old_documents,new_documents)
a=copy.deepcopy(baseline['status']);b=copy.deepcopy(candidate['status'])
for value in (a,b):
 for key in ('runtimeId','codeHash'):value['data'].pop(key)
assert a==b,'Unexpected public status change beyond sidecar identity'
manifest=json.loads((O/'candidate-manifest.json').read_text());receipt=json.loads((H/'Library/Application Support/Glyphs MCP/lean-v2/installation.json').read_text())
(O/'installation.json').write_text(json.dumps(receipt,indent=2)+'\n')
assert candidate['status']['data']['codeHash']==manifest['sidecar']['codeHash']
assert candidate['status']['data']['bridge']['codeHash']==manifest['bridge']['codeHash']
installed={}
for row in receipt['installed']:
 actual=_identity(Path(row['path']));assert actual==row['identity'],row['path'];installed[row['path']]=actual
frozen=json.loads((O/'freeze.json').read_text());changes={}
for label,root_info in frozen['roots'].items():
 root=Path(root_info['path']);before=root_info['files'];after={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in root.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc'}
 changes[label]=sorted(k for k in set(before)|set(after) if before.get(k)!=after.get(k))
 expected=['glyphs-mcp/tests/test_simple_v2_http_route.py','glyphs-mcp/tests/test_simple_v2_sidecar.py','sidecar/glyphs_mcp_sidecar/server.py'] if label=='source' else []
 assert changes[label]==expected,(label,changes[label])
config_changes=[p for p,h in frozen['configHashes'].items() if hashlib.sha256(Path(p).read_bytes()).hexdigest()!=h]
# Glyphs may persist window/recent-file state during the required normal relaunch.
assert all(p.endswith('/Preferences/com.GeorgSeifert.Glyphs4.plist') for p in config_changes),config_changes
processes=subprocess.check_output(['ps','-axo','pid=,comm='],text=True)
rows=[s.strip() for s in processes.splitlines() if s.endswith('/Contents/MacOS/Glyphs 4')];assert len(rows)==1
new_crashes=sorted(str(p) for p in (H/'Library/Logs/DiagnosticReports').glob('Glyphs*') if p.is_file() and str(p) not in frozen['crashes']);assert not new_crashes,new_crashes
calls={label:json.loads((O/label/'calls.json').read_text()) for label in ('baseline','candidate')}
public={label:[r for r in values if r['method']=='tools/call'] for label,values in calls.items()}
assert all(r['statuses']==[307,200] for r in public['baseline'])
assert all(r['statuses']==[200] for r in public['candidate'])
result=dict(exactCatalogAndHandshake=True,exactSelectionAndErrors=True,statusChangedOnlySidecarIdentity=True,documentsEqualExceptFreshIDs=True,previousIDs=old_ids,currentIDs=new_ids,toolCallsPerArm=len(public['candidate']),baselineHTTPExchanges=sum(len(r['statuses']) for r in public['baseline']),candidateHTTPExchanges=sum(len(r['statuses']) for r in public['candidate']),installed=installed,preservation=changes,configurationChanges=config_changes,glyphsProcessBefore=json.loads((O/'host-before.json').read_text())['glyphsProcess'],glyphsProcessAfter=rows[0],relaunchRequiredByExistingInstaller=True,newCrashReports=new_crashes,limitations=['Same existing disposable Font View control: no new editing/history, fresh-copy task benchmark or large-font benchmark.','No native callback or queue instrumentation; HTTP samples do not establish a matched-load speed improvement.','Expected new document IDs after the mandatory Glyphs restart.'])
(O/'verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ('installed','preservation')},indent=2))
