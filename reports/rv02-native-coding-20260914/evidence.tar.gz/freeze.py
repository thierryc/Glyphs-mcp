from pathlib import Path
import hashlib,json,shutil,subprocess,time,os
R=Path('/Users/thierryc/Dev/github/thierryc/Glyphs-mcp-worktrees/v2');S=R/'build/milestone7/desktop';O=Path(__file__).resolve().parent
SK=Path.home()/'.codex/skills'
def tree(p):
 return {str(f.relative_to(p)):hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(p.rglob('*')) if f.is_file() and not any(x in f.parts for x in ('__pycache__','.git')) and f.name!='.DS_Store' and f.suffix not in ('.pyc','.pyo')}
def files(paths):
 return {str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths if p.is_file()}
changed=subprocess.check_output(['git','diff','--name-only','-z'],cwd=S).decode().split('\0');untracked=subprocess.check_output(['git','ls-files','--others','--exclude-standard','-z'],cwd=S).decode().split('\0')
for name in ('glyphs','glyphs-mcp-development','glyphs-mcp-scripting','glyphs-mcp-opentype-features'):
 shutil.copytree(SK/name,O/'installed-before'/name)
font=R/'reports/v2-realistic/20260914/font-source/RobotoSlab.glyphs'; assert hashlib.sha256(font.read_bytes()).hexdigest()=='98bd0e35d9267ad101270727f18bb58b17b629160ccdf3d8a60f9a99d526e845'
shutil.copy(SK/'.glyphs-mcp-skills.json',O/'ownership-before.json')
data=dict(at=time.time(),hostLoad=os.getloadavg(),head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=S).decode().strip(),preexisting=files([S/p for p in changed+untracked if p]),missing=[p for p in changed if p and not (S/p).exists()],configured=tree(SK),sourceCorpus=tree(S/'skills/glyphs-mcp-development/assets/knowledge'),runtimeSource={n:tree(S/n) for n in ('src/bridge','src/sidecar','src/shared','legacy/glyphs3')},protected=files([font,S/'build/preserved-user-work-20260914/MCP Selection Inspection.glyphs',Path('/private/tmp/vc01-full-20260912/v2-current-5/1789186800389374000-open-unrelated.glyphs')]),userFont=tree(Path('/Users/thierryc/Documents/fonts/Dactylotype/Dactylotype.glyphspackage')),crashes=files(list((Path.home()/'Library/Logs/DiagnosticReports').glob('*Glyphs*'))))
(O/'freeze.json').write_text(json.dumps(data,indent=2)+'\n')
(O/'preexisting.diff').write_bytes(subprocess.check_output(['git','diff','--binary'],cwd=S))
print({'preexistingFiles':len(data['preexisting']),'configuredFiles':len(data['configured']),'corpusFiles':len(data['sourceCorpus']),'head':data['head']})
