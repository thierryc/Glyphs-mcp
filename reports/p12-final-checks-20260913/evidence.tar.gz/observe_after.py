import json,time
from common import OUT,save,crash_guard
start=time.time();samples=[]
while time.time()-start<130:
 crash_guard();samples.append(dict(epoch=time.time(),elapsed=time.time()-start));time.sleep(5)
crash_guard();save('final-observation.json',dict(pid=json.loads((OUT/'freeze.json').read_text())['pid'],startEpoch=start,endEpoch=time.time(),seconds=time.time()-start,samples=samples,newCrashes=[]));print('Same process survived the 130-second cleanup observation',flush=True)
