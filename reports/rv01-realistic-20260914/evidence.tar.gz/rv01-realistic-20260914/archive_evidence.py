from pathlib import Path
import tarfile,gzip,hashlib,json,shutil,re
O=Path(__file__).resolve().parent;R=O.parents[2];S=R/'build/milestone7/desktop';D=S/'reports/rv01-realistic-20260914';D.mkdir(parents=True,exist_ok=True)
exclude={'archive-manifest.json','inventory-dactylotype-unused.json','inventory-dactylotype-unused.py','inventory-native.log','test-spec-preference-draft.md'}
files=[p for p in sorted(O.rglob('*')) if p.is_file() and '__pycache__' not in p.parts and p.name not in exclude]
archive=D/'evidence.tar.gz'
with archive.open('wb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,filename='',compresslevel=6) as gz:
  with tarfile.open(fileobj=gz,mode='w') as tar:
   for p in files:
    name=str(p.relative_to(O));info=tar.gettarinfo(str(p),arcname='rv01-realistic-20260914/'+name);info.mtime=0;info.uid=info.gid=0;info.uname=info.gname='';info.mode=0o644
    with p.open('rb') as stream:tar.addfile(info,stream)
# Keep the report and its normal navigation accessible without extracting large oracles.
for p in files:
 rel=p.relative_to(O);parts=rel.parts
 if p.suffix in ('.md','.png','.svg') or p.name in ('assertion-index.json','measurements.json','preservation.json','installation.json','runtime-installed.json','runtime-after.json','catalog.json','handshake.json','llm-judgment.json','preserved-unsaved-work.json','calls.jsonl','SOURCE.json','LICENSE.txt') or (parts[0]=='artifacts') or (parts[0]=='tasks' and p.name in ('assertions-final.json','facts-first.json','facts-corrected.json','geometry-certificate.json','source-cross-check.json','shaping.json','existing-feature-shaping.json','export-first.json','export-corrected.json')):
  target=D/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target)
manifest=dict(archive='evidence.tar.gz',sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),bytes=archive.stat().st_size,members=len(files),uncompressedBytes=sum(p.stat().st_size for p in files),excludedUnusedPreparation=sorted(exclude),files={str(p.relative_to(O)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files})
(D/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');(O/'archive-manifest.json').write_text(json.dumps({k:v for k,v in manifest.items() if k!='files'},indent=2)+'\n')
shutil.copy2(R/'reports/v1-v2/README.md',D/'coverage-index.md')
with tarfile.open(archive,'r:gz') as tar:
 names=tar.getnames();assert len(names)==len(files)
 for member in tar:
  rel=member.name.split('/',1)[1];assert hashlib.sha256(tar.extractfile(member).read()).hexdigest()==manifest['files'][rel]
print(json.dumps({k:v for k,v in manifest.items() if k!='files'},indent=2))
