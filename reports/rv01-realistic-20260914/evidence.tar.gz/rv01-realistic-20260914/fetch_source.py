from pathlib import Path
import urllib.request,hashlib,json
O=Path(__file__).resolve().parent;D=O/'font-source';D.mkdir(exist_ok=True)
revision='67af3ce9c4ca574419e1295b6165a2eeee112e6e';base='https://raw.githubusercontent.com/googlefonts/robotoslab/'+revision+'/'
files=[]
for src in ('sources/RobotoSlab.glyphs','LICENSE.txt'):
 target=D/Path(src).name;assert not target.exists()
 url=base+src;data=urllib.request.urlopen(url,timeout=30).read();target.write_bytes(data)
 files.append(dict(sourcePath=src,url=url,local=str(target),bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
(D/'SOURCE.json').write_text(json.dumps(dict(repository='https://github.com/googlefonts/robotoslab',revision=revision,license='Apache-2.0; see LICENSE.txt',files=files),indent=2)+'\n')
print(json.dumps(files))
